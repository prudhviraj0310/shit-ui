#!/usr/bin/env node

/**
 * Transparent bridge between Claude Code CLI and CodeCraft API.
 * Maps any internal model requested by Claude Code (e.g. claude-opus-5, claude-3-5-sonnet, haiku)
 * to CodeCraft's verified model: "claude-opus-5.5" to prevent 503 channel errors.
 */

import http from 'node:http';
import https from 'node:https';

const PORT = process.env.PORT || 8088;
const API_KEY = process.env.CODECRAFT_KEY || process.env.ANTHROPIC_AUTH_TOKEN || process.env.ANTHROPIC_API_KEY || 'cc_Zu0fQjwSHtigc1y7XSa8tGclSNfPUtbIoB05Vx4iBYAPNHZp';
const TARGET_MODEL = process.env.ANTHROPIC_MODEL || 'claude-opus-4.8';
const TARGET_HOST = 'codecraftapi.com';

const server = http.createServer((req, res) => {
  let body = [];

  req.on('data', chunk => body.push(chunk));
  req.on('end', () => {
    let rawBody = Buffer.concat(body).toString('utf8');

    if (rawBody && req.headers['content-type']?.includes('application/json')) {
      try {
        const json = JSON.parse(rawBody);
        // Force model to claude-opus-5.5
        json.model = TARGET_MODEL;
        rawBody = JSON.stringify(json);
      } catch (err) {
        // pass through as-is if parsing fails
      }
    }

    const path = req.url.startsWith('/v1/') ? req.url : `/v1${req.url}`;

    const headers = {
      ...req.headers,
      host: TARGET_HOST,
      'authorization': `Bearer ${API_KEY}`,
      'x-api-key': API_KEY,
      'anthropic-version': req.headers['anthropic-version'] || '2023-06-01',
    };

    if (rawBody) {
      headers['content-length'] = Buffer.byteLength(rawBody);
    }

    delete headers['connection'];

    const proxyReq = https.request({
      hostname: TARGET_HOST,
      port: 443,
      path,
      method: req.method,
      headers,
    }, (proxyRes) => {
      res.writeHead(proxyRes.statusCode, proxyRes.headers);
      proxyRes.pipe(res);
    });

    proxyReq.on('error', (err) => {
      console.error('[Proxy Error]:', err.message);
      res.writeHead(502, { 'content-type': 'application/json' });
      res.end(JSON.stringify({ error: err.message }));
    });

    if (rawBody) {
      proxyReq.write(rawBody);
    }
    proxyReq.end();
  });
});

server.listen(PORT, '127.0.0.1', () => {
  console.log(`[CodeCraft Proxy] Active on http://127.0.0.1:${PORT} -> mapping to ${TARGET_MODEL}`);
});

process.on('SIGINT', () => process.exit(0));
process.on('SIGTERM', () => process.exit(0));
