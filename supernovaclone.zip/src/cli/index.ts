import { getDb } from '../db/index';
import { seedDatabase } from '../db/seed';
import { tokens, designSystemVersions } from '../db/schema';
import { eq, and } from 'drizzle-orm';
import { FlatToken } from '../core/tokens/types';
import { exportToCss } from '../core/exporters/css';
import { exportToJson } from '../core/exporters/json';
import { exportToTypeScript } from '../core/exporters/typescript';
import { exportToTailwind } from '../core/exporters/tailwind';
import { exportToSwift } from '../core/exporters/swift';
import { exportToKotlin } from '../core/exporters/kotlin';
import { exportToScss } from '../core/exporters/scss';
import { exportToStyleDictionary, exportStyleDictionaryConfig } from '../core/exporters/style-dictionary';
import { exportToFlutter } from '../core/exporters/flutter';
import { exportToAndroidXml } from '../core/exporters/android-xml';
import { getPulsarEngine } from '../core/pulsar/engine';
import { validateTokens } from '../core/tokens/validator';
import { TokenBranchManager } from '../core/tokens/branching';
import { AuditEngine } from '../core/audit/engine';
import { GitHubDeliveryEngine } from '../core/delivery/github';
import { runStdioServer } from '../mcp/server';
import * as fs from 'fs';
import * as path from 'path';

async function getScopedTokens(db: any, designSystemId = 'ds-nova-design'): Promise<FlatToken[]> {
  const drafts = await db
    .select({ id: designSystemVersions.id })
    .from(designSystemVersions)
    .where(and(eq(designSystemVersions.designSystemId, designSystemId), eq(designSystemVersions.isDraft, true)));
  const targetVersionId = drafts.length > 0 ? drafts[0].id : null;

  const all = await db.select().from(tokens);
  const scoped = all.filter((t: any) =>
    (!designSystemId || t.designSystemId === designSystemId) &&
    (!targetVersionId || t.versionId === targetVersionId)
  );

  return scoped.map((t: any) => ({
    name: t.name,
    path: t.path,
    category: t.category,
    type: t.type,
    rawValue: t.rawValue,
    resolvedValue: t.resolvedValue,
    isAlias: t.isAlias,
    aliasTarget: t.aliasTarget || undefined,
    isDeprecated: t.isDeprecated,
    description: t.description || undefined,
  }));
}

async function main() {
  const args = process.argv.slice(2);
  const command = args[0] || 'help';

  switch (command) {
    case 'seed': {
      console.log('Seeding NovaDesign database...');
      const res = await seedDatabase();
      console.log('Seeded successfully:', res);
      break;
    }

    case 'export': {
      const outDir = args[1] || './dist/exported-tokens';
      const formatIdx = args.indexOf('--format');
      const targetFormat = formatIdx !== -1 ? args[formatIdx + 1]?.toLowerCase() : null;

      console.log(`Exporting design tokens to ${outDir}${targetFormat ? ` (format: ${targetFormat})` : ''}...`);
      const { db } = await getDb();
      const allTokens = await db.select().from(tokens);

      if (allTokens.length === 0) {
        console.log('No tokens found. Seeding first...');
        await seedDatabase();
      }

      const flatTokens = await getScopedTokens(db);
      fs.mkdirSync(outDir, { recursive: true });

      const filesToSave: Array<{ filename: string; content: string }> = [];

      if (!targetFormat || targetFormat === 'css') {
        filesToSave.push(exportToCss(flatTokens));
      }
      if (!targetFormat || targetFormat === 'scss') {
        filesToSave.push(exportToScss(flatTokens));
      }
      if (!targetFormat || targetFormat === 'json') {
        filesToSave.push(exportToJson(flatTokens));
      }
      if (!targetFormat || targetFormat === 'typescript' || targetFormat === 'ts') {
        filesToSave.push(exportToTypeScript(flatTokens));
      }
      if (!targetFormat || targetFormat === 'tailwind') {
        filesToSave.push(exportToTailwind(flatTokens));
      }
      if (!targetFormat || targetFormat === 'swift') {
        filesToSave.push(exportToSwift(flatTokens));
      }
      if (!targetFormat || targetFormat === 'kotlin') {
        filesToSave.push(exportToKotlin(flatTokens));
      }
      if (!targetFormat || targetFormat === 'flutter' || targetFormat === 'dart') {
        filesToSave.push(exportToFlutter(flatTokens));
      }
      if (!targetFormat || targetFormat === 'style-dictionary') {
        filesToSave.push(exportToStyleDictionary(flatTokens));
        filesToSave.push(exportStyleDictionaryConfig());
      }
      if (!targetFormat || targetFormat === 'android-xml' || targetFormat === 'xml') {
        filesToSave.push(exportToAndroidXml(flatTokens));
      }

      for (const f of filesToSave) {
        fs.writeFileSync(path.join(outDir, f.filename), f.content);
        console.log(`  - ${f.filename}`);
      }

      console.log(`Successfully exported ${filesToSave.length} file(s) to ${outDir}`);
      break;
    }

    case 'pulsar': {
      const templateId = args[1];
      const outDir = args[2] || './dist/pulsar';
      const engine = getPulsarEngine();

      if (!templateId) {
        console.log('Available Pulsar Exporter Templates:');
        for (const t of engine.listTemplates()) {
          console.log(`  - ${t.id} (${t.name}): ${t.description} -> ${t.outputFileName}`);
        }
        console.log('\nUsage: npm run cli pulsar <templateId> [outDir]');
        break;
      }

      const { db } = await getDb();
      const flatTokens = await getScopedTokens(db);
      const result = engine.execute(templateId, flatTokens);

      if (!result.success) {
        console.error(`Pulsar execution failed for template "${templateId}":`, result.errors.join('; '));
        process.exit(1);
      }

      fs.mkdirSync(outDir, { recursive: true });
      const targetPath = path.join(outDir, result.fileName);
      fs.writeFileSync(targetPath, result.output);
      console.log(`Pulsar template "${templateId}" executed successfully in ${result.stats.executionMs}ms:`);
      console.log(`  File: ${targetPath}`);
      console.log(`  Tokens Processed: ${result.stats.tokensProcessed}`);
      console.log(`  Lines Generated: ${result.stats.linesGenerated}`);
      break;
    }

    case 'validate': {
      console.log('Validating design tokens...');
      const { db } = await getDb();
      const flatTokens = await getScopedTokens(db);

      const result = validateTokens(flatTokens);
      if (result.valid) {
        console.log(`All ${flatTokens.length} design tokens are strictly valid. 0 errors detected.`);
      } else {
        console.error(`Validation failed with ${result.errors.length} error(s):`);
        for (const err of result.errors) {
          console.error(`  - [${err.path}] ${err.message}`);
        }
        process.exit(1);
      }
      break;
    }

    case 'diff': {
      const sourceBranch = args[1];
      const targetBranch = args[2] || 'Draft';

      if (!sourceBranch) {
        console.error('Error: Please specify source branch name or ID. Example: npm run cli diff feature-colors Draft');
        process.exit(1);
      }

      const { db } = await getDb();
      const branchManager = new TokenBranchManager(db);

      try {
        const diff = await branchManager.diffBranches('ds-nova-design', sourceBranch, targetBranch);
        console.log(`--- Token Branch Diff: "${sourceBranch}" vs "${targetBranch}" ---`);
        console.log(`Total Changes: ${diff.totalChanges} (Added: ${diff.addedCount}, Modified: ${diff.modifiedCount}, Deleted: ${diff.deletedCount}, Unchanged: ${diff.unchangedCount})`);
        for (const ch of diff.changes) {
          console.log(`[${ch.changeType.toUpperCase()}] ${ch.path} (${ch.category})`);
          if (ch.oldValue !== undefined) console.log(`  - Old: ${ch.oldValue}`);
          if (ch.newValue !== undefined) console.log(`  + New: ${ch.newValue}`);
        }
      } catch (err: any) {
        console.error('Diff error:', err.message);
        process.exit(1);
      }
      break;
    }

    case 'audit': {
      const targetFile = args[1];
      if (!targetFile) {
        console.error('Error: Please specify a file path to audit. Example: npm run cli audit src/App.tsx');
        process.exit(1);
      }

      if (!fs.existsSync(targetFile)) {
        console.error(`Error: File "${targetFile}" not found.`);
        process.exit(1);
      }

      const content = fs.readFileSync(targetFile, 'utf-8');
      const { db } = await getDb();
      const flatTokens = await getScopedTokens(db);

      const auditEngine = new AuditEngine();
      const report = auditEngine.auditFile({
        filePath: targetFile,
        content,
        tokens: flatTokens,
      });

      console.log('--- NovaDesign Quality Audit Report ---');
      console.log(`Total Findings: ${report.totalFindings} (Errors: ${report.errorCount}, Warnings: ${report.warningCount}, Info: ${report.infoCount})`);
      for (const finding of report.findings) {
        console.log(`[${finding.severity.toUpperCase()}] Line ${finding.line} (${finding.ruleId}): ${finding.message}`);
        console.log(`  Evidence: ${finding.evidence}`);
        if (finding.suggestedFix) {
          console.log(`  Fix: ${finding.suggestedFix}`);
        }
      }
      break;
    }

    case 'mcp': {
      await runStdioServer();
      break;
    }

    case 'deliver': {
      console.log('Running automated continuous delivery pipeline to GitHub...');
      const { db } = await getDb();
      const flatTokens = await getScopedTokens(db);

      const css = exportToCss(flatTokens);
      const ts = exportToTypeScript(flatTokens);

      const delivery = new GitHubDeliveryEngine();
      const result = await delivery.deliver({
        projectId: 'proj-core-web',
        repoOwner: 'acme-corp',
        repoName: 'design-system-core',
        newBranchName: `novadesign/tokens-update-${Date.now()}`,
        commitMessage: 'chore(tokens): sync design tokens from NovaDesign source of truth',
        prTitle: 'Design Token Update: Nova Design System v1.2.0',
        prBody: 'Automated pull request generated by NovaDesign continuous delivery engine.',
        files: [css, ts],
        dryRun: true, // test fixture / dry run mode
      });

      console.log('Delivery Result:', result);
      break;
    }

    default:
      console.log(`NovaDesign Platform CLI
Usage:
  npm run cli seed                       # Seed database with workspace, project, tokens
  npm run cli export [dir] [--format f]  # Export tokens (CSS, SCSS, JSON, TS, Tailwind, Swift, Kotlin, Flutter, Style-Dictionary, XML)
  npm run cli pulsar <template> [dir]    # Execute Handlebars Pulsar template (.pr engine)
  npm run cli validate                   # Validate tokens against DTCG specs and reference graph
  npm run cli diff <branch> [base]       # Semantic token diff across branches/versions
  npm run cli audit <file>               # Run design system compliance audit on a code file
  npm run cli deliver                    # Run continuous delivery GitHub PR pipeline
  npm run cli mcp                        # Start Model Context Protocol Stdio server
`);
      break;
  }
}

main().catch((err) => {
  console.error('Fatal CLI Error:', err);
  process.exit(1);
});
