import { FlatToken } from '../tokens/types';
import { ExporterOptions, GeneratedFile } from './types';

export interface StyleDictionaryExporterOptions extends ExporterOptions {
  includeConfig?: boolean;
  version?: 'v3' | 'v4';
}

/**
 * Format token alias target into Style Dictionary reference syntax: {color.brand.primary.value}
 */
export function toStyleDictionaryAlias(aliasPath: string): string {
  const clean = aliasPath.replace(/^\{|\}$/g, '');
  return `{${clean}.value}`;
}

/**
 * Map token types to Style Dictionary standard types
 */
export function mapToStyleDictionaryType(tokenType: string, category: string): string {
  switch (tokenType) {
    case 'color':
      return 'color';
    case 'dimension':
      return category === 'typography' ? 'fontSizes' : 'dimension';
    case 'fontFamily':
      return 'fontFamilies';
    case 'fontWeight':
      return 'fontWeights';
    case 'lineHeight':
      return 'lineHeights';
    case 'letterSpacing':
      return 'letterSpacing';
    case 'shadow':
      return 'boxShadow';
    case 'border':
      return 'border';
    case 'borderRadius':
      return 'borderRadius';
    case 'duration':
      return 'time';
    default:
      return tokenType || 'other';
  }
}

/**
 * Export design tokens to Amazon Style Dictionary v3/v4 token tree
 */
export function exportToStyleDictionary(
  tokens: FlatToken[],
  options: StyleDictionaryExporterOptions = {}
): GeneratedFile {
  const tree: Record<string, any> = {};
  const indent = options.indent ?? 2;

  for (const token of tokens) {
    const parts = token.path.split('.');
    let current = tree;

    for (let i = 0; i < parts.length; i++) {
      const part = parts[i];
      if (i === parts.length - 1) {
        let value: any;
        if (token.isAlias && token.aliasTarget) {
          value = toStyleDictionaryAlias(token.aliasTarget);
        } else if (typeof token.rawValue === 'object' && token.rawValue !== null) {
          value = token.rawValue;
        } else {
          value = token.resolvedValue !== undefined ? token.resolvedValue : token.rawValue;
        }

        const leaf: Record<string, any> = {
          value,
          type: mapToStyleDictionaryType(token.type, token.category),
        };

        if (token.description) {
          leaf.comment = token.description;
        }

        if (token.isDeprecated) {
          leaf.deprecated = true;
        }

        leaf.original = {
          value: token.rawValue,
          type: token.type,
        };

        current[part] = leaf;
      } else {
        if (!current[part]) {
          current[part] = {};
        }
        current = current[part];
      }
    }
  }

  return {
    filename: 'tokens.style-dictionary.json',
    content: JSON.stringify(tree, null, indent) + '\n',
    format: 'json',
  };
}

/**
 * Export Style Dictionary configuration file (sd.config.json)
 */
export function exportStyleDictionaryConfig(options: StyleDictionaryExporterOptions = {}): GeneratedFile {
  const indent = options.indent ?? 2;
  const config = {
    source: ['tokens.style-dictionary.json'],
    platforms: {
      css: {
        transformGroup: 'css',
        buildPath: 'build/css/',
        files: [
          {
            destination: 'variables.css',
            format: 'css/variables',
            options: {
              outputReferences: true,
            },
          },
        ],
      },
      scss: {
        transformGroup: 'scss',
        buildPath: 'build/scss/',
        files: [
          {
            destination: '_variables.scss',
            format: 'scss/variables',
            options: {
              outputReferences: true,
            },
          },
        ],
      },
      javascript: {
        transformGroup: 'js',
        buildPath: 'build/js/',
        files: [
          {
            destination: 'tokens.js',
            format: 'javascript/es6',
          },
          {
            destination: 'tokens.d.ts',
            format: 'typescript/es6-declarations',
          },
        ],
      },
      'ios-swift': {
        transformGroup: 'ios-swift',
        buildPath: 'build/ios/',
        files: [
          {
            destination: 'StyleDictionaryColor.swift',
            format: 'ios-swift/class.swift',
            className: 'StyleDictionaryColor',
            filter: {
              type: 'color',
            },
          },
        ],
      },
      compose: {
        transformGroup: 'compose',
        buildPath: 'build/compose/',
        files: [
          {
            destination: 'StyleDictionaryColor.kt',
            format: 'compose/object',
            className: 'StyleDictionaryColor',
            packageName: 'com.nexus.tokens',
          },
        ],
      },
    },
  };

  return {
    filename: 'style-dictionary.config.json',
    content: JSON.stringify(config, null, indent) + '\n',
    format: 'json',
  };
}
