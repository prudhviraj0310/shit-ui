import { eq, and, sql, or } from 'drizzle-orm';
import { designSystemVersions, tokens, tokenGroups, themes, tokenOverrides } from '@/db/schema';

export interface TokenDiffItem {
  path: string;
  category: string;
  type: string;
  changeType: 'added' | 'modified' | 'deleted' | 'unchanged';
  oldValue?: string;
  newValue?: string;
  oldResolved?: string;
  newResolved?: string;
}

export interface BranchDiffResult {
  sourceBranch: string;
  targetBranch: string;
  totalChanges: number;
  addedCount: number;
  modifiedCount: number;
  deletedCount: number;
  unchangedCount: number;
  changes: TokenDiffItem[];
}

export interface BranchSummary {
  id: string;
  name: string;
  description: string | null;
  isDraft: boolean;
  isReadOnly: boolean;
  tokenCount: number;
  createdAt: Date | string;
}

export class TokenBranchManager {
  private db: any;

  constructor(db: any) {
    this.db = db;
  }

  /**
   * Lists all branches for a given design system.
   */
  public async listBranches(designSystemId: string = 'ds-nova-design'): Promise<BranchSummary[]> {
    const versions = await this.db
      .select()
      .from(designSystemVersions)
      .where(eq(designSystemVersions.designSystemId, designSystemId));

    const list: BranchSummary[] = [];
    for (const v of versions) {
      const tokRows = await this.db
        .select({ count: sql`count(*)` })
        .from(tokens)
        .where(eq(tokens.versionId, v.id));

      const count = Number(tokRows[0]?.count || 0);
      list.push({
        id: v.id,
        name: v.name,
        description: v.description,
        isDraft: v.isDraft,
        isReadOnly: v.isReadOnly,
        tokenCount: count,
        createdAt: v.createdAt,
      });
    }

    return list;
  }

  /**
   * Creates a new branch by cloning tokens and groups from the current active draft or a base version.
   */
  public async createBranch(
    designSystemId: string,
    branchName: string,
    description?: string,
    baseVersionIdOrName?: string
  ): Promise<any> {
    const sanitizedName = branchName.trim().replace(/\s+/g, '-');
    const existing = await this.db
      .select()
      .from(designSystemVersions)
      .where(
        and(
          eq(designSystemVersions.designSystemId, designSystemId),
          eq(designSystemVersions.name, sanitizedName)
        )
      );

    if (existing.length > 0) {
      throw new Error(`Branch with name "${sanitizedName}" already exists.`);
    }

    // Determine base version container to fork from
    let baseVersion: any = null;
    if (baseVersionIdOrName) {
      const res = await this.db
        .select()
        .from(designSystemVersions)
        .where(
          and(
            eq(designSystemVersions.designSystemId, designSystemId),
            or(
              eq(designSystemVersions.id, baseVersionIdOrName),
              eq(designSystemVersions.name, baseVersionIdOrName)
            )
          )
        );
      if (res.length > 0) baseVersion = res[0];
    }

    if (!baseVersion) {
      // Default to draft version
      const drafts = await this.db
        .select()
        .from(designSystemVersions)
        .where(
          and(
            eq(designSystemVersions.designSystemId, designSystemId),
            eq(designSystemVersions.isDraft, true)
          )
        );
      baseVersion = drafts[0];
    }

    const branchVersionId = `br-${sanitizedName}-${Date.now().toString(36)}`;
    const newBranchRecord = {
      id: branchVersionId,
      designSystemId,
      name: sanitizedName,
      description: description || `Feature branch ${sanitizedName} forked from ${baseVersion?.name || 'Draft'}`,
      isDraft: true,
      isReadOnly: false,
      createdAt: new Date(),
    };

    // Fork tokens from base
    const baseTokens = baseVersion
      ? await this.db.select().from(tokens).where(eq(tokens.versionId, baseVersion.id))
      : [];

    const newTokens = baseTokens.map((t: any) => ({
      id: `tok-${branchVersionId}-${t.persistentId || t.id.replace(/^tok-[^-]+-/, '')}`,
      persistentId: t.persistentId || t.id,
      designSystemId,
      versionId: branchVersionId,
      brandId: t.brandId,
      groupId: t.groupId,
      originSourceId: t.originSourceId,
      name: t.name,
      path: t.path,
      category: t.category,
      type: t.type,
      rawValue: t.rawValue,
      resolvedValue: t.resolvedValue,
      isComposite: t.isComposite,
      rawValueJson: t.rawValueJson,
      resolvedValueJson: t.resolvedValueJson,
      isAlias: t.isAlias,
      aliasTarget: t.aliasTarget,
      isDeprecated: t.isDeprecated,
      isDeleted: false,
      deletedAt: null,
      description: t.description,
      extensions: t.extensions,
      createdAt: new Date(),
    }));

    await this.db.transaction(async (tx: any) => {
      await tx.insert(designSystemVersions).values(newBranchRecord);
      for (const tok of newTokens) {
        await tx.insert(tokens).values(tok);
      }
    });

    return {
      branch: newBranchRecord,
      tokensCopied: newTokens.length,
      forkedFrom: baseVersion?.name || 'Draft',
    };
  }

  /**
   * Compares two branches and returns the additions, modifications, and deletions.
   */
  public async diffBranches(
    designSystemId: string,
    sourceBranchName: string,
    targetBranchName: string = 'Draft'
  ): Promise<BranchDiffResult> {
    const versions = await this.db
      .select()
      .from(designSystemVersions)
      .where(eq(designSystemVersions.designSystemId, designSystemId));

    const source = versions.find((v: any) => v.name === sourceBranchName || v.id === sourceBranchName);
    const target = versions.find((v: any) => v.name === targetBranchName || v.id === targetBranchName);

    if (!source) throw new Error(`Source branch "${sourceBranchName}" not found.`);
    if (!target) throw new Error(`Target branch "${targetBranchName}" not found.`);

    const sourceTokens = await this.db.select().from(tokens).where(eq(tokens.versionId, source.id));
    const targetTokens = await this.db.select().from(tokens).where(eq(tokens.versionId, target.id));

    const sourceMap = new Map<string, any>(sourceTokens.map((t: any) => [t.path, t]));
    const targetMap = new Map<string, any>(targetTokens.map((t: any) => [t.path, t]));

    const changes: TokenDiffItem[] = [];
    let addedCount = 0;
    let modifiedCount = 0;
    let deletedCount = 0;
    let unchangedCount = 0;

    // Check additions and modifications
    for (const [path, sTok] of sourceMap) {
      const tTok = targetMap.get(path);
      if (!tTok) {
        addedCount++;
        changes.push({
          path,
          category: sTok.category,
          type: sTok.type,
          changeType: 'added',
          newValue: sTok.rawValue,
          newResolved: sTok.resolvedValue,
        });
      } else if (tTok.rawValue !== sTok.rawValue || tTok.resolvedValue !== sTok.resolvedValue) {
        modifiedCount++;
        changes.push({
          path,
          category: sTok.category,
          type: sTok.type,
          changeType: 'modified',
          oldValue: tTok.rawValue,
          newValue: sTok.rawValue,
          oldResolved: tTok.resolvedValue,
          newResolved: sTok.resolvedValue,
        });
      } else {
        unchangedCount++;
      }
    }

    // Check deletions (in target but missing in source)
    for (const [path, tTok] of targetMap) {
      if (!sourceMap.has(path)) {
        deletedCount++;
        changes.push({
          path,
          category: tTok.category,
          type: tTok.type,
          changeType: 'deleted',
          oldValue: tTok.rawValue,
          oldResolved: tTok.resolvedValue,
        });
      }
    }

    return {
      sourceBranch: source.name,
      targetBranch: target.name,
      totalChanges: addedCount + modifiedCount + deletedCount,
      addedCount,
      modifiedCount,
      deletedCount,
      unchangedCount,
      changes,
    };
  }

  /**
   * Merges all tokens from source branch into target branch (e.g. into Draft).
   */
  public async mergeBranch(
    designSystemId: string,
    sourceBranchName: string,
    targetBranchName: string = 'Draft',
    deleteAfterMerge: boolean = false
  ): Promise<any> {
    const diff = await this.diffBranches(designSystemId, sourceBranchName, targetBranchName);

    const versions = await this.db
      .select()
      .from(designSystemVersions)
      .where(eq(designSystemVersions.designSystemId, designSystemId));

    const source = versions.find((v: any) => v.name === sourceBranchName || v.id === sourceBranchName);
    const target = versions.find((v: any) => v.name === targetBranchName || v.id === targetBranchName);

    const sourceTokens = await this.db.select().from(tokens).where(eq(tokens.versionId, source.id));

    await this.db.transaction(async (tx: any) => {
      // Replace target tokens with source tokens
      await tx.delete(tokens).where(eq(tokens.versionId, target.id));

      for (const t of sourceTokens) {
        await tx.insert(tokens).values({
          id: `tok-${target.id}-${t.persistentId || t.id.replace(/^tok-[^-]+-/, '')}`,
          persistentId: t.persistentId || t.id,
          designSystemId,
          versionId: target.id,
          brandId: t.brandId,
          groupId: t.groupId,
          originSourceId: t.originSourceId,
          name: t.name,
          path: t.path,
          category: t.category,
          type: t.type,
          rawValue: t.rawValue,
          resolvedValue: t.resolvedValue,
          isComposite: t.isComposite,
          rawValueJson: t.rawValueJson,
          resolvedValueJson: t.resolvedValueJson,
          isAlias: t.isAlias,
          aliasTarget: t.aliasTarget,
          isDeprecated: t.isDeprecated,
          isDeleted: false,
          deletedAt: null,
          description: t.description,
          extensions: t.extensions,
          createdAt: new Date(),
        });
      }

      if (deleteAfterMerge && !source.isDraft && source.name !== 'Draft') {
        await tx.delete(tokens).where(eq(tokens.versionId, source.id));
        await tx.delete(designSystemVersions).where(eq(designSystemVersions.id, source.id));
      }
    });

    return {
      success: true,
      mergedChanges: diff.totalChanges,
      sourceBranch: source.name,
      targetBranch: target.name,
      details: {
        added: diff.addedCount,
        modified: diff.modifiedCount,
        deleted: diff.deletedCount,
      },
    };
  }
}
