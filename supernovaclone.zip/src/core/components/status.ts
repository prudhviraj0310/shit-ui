import { eq, sql } from 'drizzle-orm';
import { components } from '@/db/schema';

export type ComponentLifecycleStatus = 'backlog' | 'in_progress' | 'ready' | 'deprecated';

export interface ComponentStatusItem {
  id: string;
  name: string;
  category: string;
  framework: string;
  status: ComponentLifecycleStatus;
  description?: string | null;
  packageName?: string | null;
  repositoryName?: string | null;
  filePath?: string | null;
  exportName?: string | null;
  isDeprecated: boolean;
  createdAt: Date | string;
}

export interface ComponentStatusBoardData {
  totalCount: number;
  columns: {
    backlog: ComponentStatusItem[];
    in_progress: ComponentStatusItem[];
    ready: ComponentStatusItem[];
    deprecated: ComponentStatusItem[];
  };
  metrics: {
    healthScore: number; // percentage of active components ready
    readyCount: number;
    inProgressCount: number;
    backlogCount: number;
    deprecatedCount: number;
  };
  frameworks: Record<string, number>;
}

export class ComponentStatusManager {
  private db: any;

  constructor(db: any) {
    this.db = db;
  }

  public async getBoardData(designSystemId: string = 'ds-nova-design'): Promise<ComponentStatusBoardData> {
    const rows = await this.db
      .select()
      .from(components)
      .where(eq(components.designSystemId, designSystemId));

    const columns: ComponentStatusBoardData['columns'] = {
      backlog: [],
      in_progress: [],
      ready: [],
      deprecated: [],
    };

    const frameworks: Record<string, number> = {};

    for (const r of rows) {
      let st: ComponentLifecycleStatus = 'ready';
      if (r.isDeprecated) {
        st = 'deprecated';
      } else if (r.status === 'backlog' || r.status === 'in_progress' || r.status === 'ready' || r.status === 'deprecated') {
        st = r.status;
      }

      const item: ComponentStatusItem = {
        id: r.id,
        name: r.name,
        category: r.category,
        framework: r.framework || 'react',
        status: st,
        description: r.description,
        packageName: r.packageName,
        repositoryName: r.repositoryName,
        filePath: r.filePath,
        exportName: r.exportName,
        isDeprecated: r.isDeprecated || st === 'deprecated',
        createdAt: r.createdAt,
      };

      columns[st].push(item);
      frameworks[item.framework] = (frameworks[item.framework] || 0) + 1;
    }

    const total = rows.length;
    const ready = columns.ready.length;
    const inProg = columns.in_progress.length;
    const backlog = columns.backlog.length;
    const deprecated = columns.deprecated.length;

    const activeTotal = ready + inProg + backlog;
    const healthScore = activeTotal > 0 ? Math.round((ready / activeTotal) * 100) : 100;

    return {
      totalCount: total,
      columns,
      metrics: {
        healthScore,
        readyCount: ready,
        inProgressCount: inProg,
        backlogCount: backlog,
        deprecatedCount: deprecated,
      },
      frameworks,
    };
  }

  public async updateStatus(
    componentId: string,
    status: ComponentLifecycleStatus
  ): Promise<any> {
    const isDeprecated = status === 'deprecated';
    const updated = await this.db
      .update(components)
      .set({
        status,
        isDeprecated,
      })
      .where(eq(components.id, componentId));

    return {
      success: true,
      componentId,
      status,
      isDeprecated,
    };
  }

  public async createComponent(data: {
    designSystemId?: string;
    name: string;
    category: string;
    framework?: string;
    status?: ComponentLifecycleStatus;
    description?: string;
  }): Promise<any> {
    const id = `cmp-${data.name.toLowerCase().replace(/[^a-z0-9]/g, '-')}-${Date.now().toString(36)}`;
    const st = data.status || 'in_progress';
    const newComponent = {
      id,
      designSystemId: data.designSystemId || 'ds-nova-design',
      name: data.name,
      category: data.category || 'General',
      framework: data.framework || 'react',
      status: st,
      description: data.description || `${data.name} component`,
      props: {},
      variants: [],
      codeSnippet: `<${data.name} />`,
      isDeprecated: st === 'deprecated',
      createdAt: new Date(),
    };

    await this.db.insert(components).values(newComponent);
    return newComponent;
  }
}
