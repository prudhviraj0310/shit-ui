import { eq } from 'drizzle-orm';
import { components } from '@/db/schema';

export interface StorybookStory {
  id: string;
  name: string;
  title: string;
  componentName: string;
  category: string;
  importPath?: string;
  tags?: string[];
  parameters?: Record<string, any>;
  args?: Record<string, any>;
  argTypes?: Record<string, any>;
  iframeUrl?: string;
}

export interface StorybookComponentGroup {
  componentName: string;
  title: string;
  category: string;
  stories: StorybookStory[];
  defaultStoryId: string;
}

export interface ParsedStorybookIndex {
  version: number | string;
  totalStories: number;
  totalComponents: number;
  components: StorybookComponentGroup[];
  stories: StorybookStory[];
}

/**
 * Extracts the component name and category from a Storybook title path.
 * e.g. "Components/Inputs/Button" -> componentName: "Button", category: "Inputs"
 * e.g. "Core/Button" -> componentName: "Button", category: "Core"
 * e.g. "Button" -> componentName: "Button", category: "General"
 */
export function extractComponentNameAndCategory(title: string): { componentName: string; category: string } {
  const parts = title.split('/').map((s) => s.trim()).filter(Boolean);
  if (parts.length === 0) {
    return { componentName: 'Component', category: 'General' };
  }
  if (parts.length === 1) {
    return { componentName: parts[0], category: 'General' };
  }
  const componentName = parts[parts.length - 1];
  const category = parts[parts.length - 2];
  return { componentName, category };
}

/**
 * Parses Storybook 7/8 CSF3 `stories.json` or `index.json` structure from URL or raw string content.
 */
export async function parseStorybookIndex(
  storiesJsonUrlOrContent: string,
  storybookBaseUrl?: string
): Promise<ParsedStorybookIndex> {
  let rawData: any;

  const trimmed = storiesJsonUrlOrContent.trim();
  if (trimmed.startsWith('http://') || trimmed.startsWith('https://')) {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 8000);
    const res = await fetch(trimmed, {
      signal: controller.signal,
      headers: { 'User-Agent': 'NexusDesign-OS/1.0.0' },
    });
    clearTimeout(timeoutId);
    if (!res.ok) {
      throw new Error(`Failed to fetch Storybook index from ${trimmed}: HTTP ${res.status}`);
    }
    rawData = await res.json();
  } else {
    try {
      rawData = JSON.parse(trimmed);
    } catch (err: any) {
      throw new Error(`Invalid Storybook JSON payload: ${err.message}`);
    }
  }

  const version = rawData.v || rawData.version || 4;
  const rawEntries = rawData.entries || rawData.stories || {};
  const storiesList: StorybookStory[] = [];
  const componentMap = new Map<string, StorybookStory[]>();

  const cleanBaseUrl = storybookBaseUrl ? storybookBaseUrl.replace(/\/+$/, '') : '';

  for (const [key, entry] of Object.entries<any>(rawEntries)) {
    // Only process stories (skip docs-only entries if type is defined)
    if (entry.type && entry.type !== 'story') {
      continue;
    }

    const storyId = entry.id || key;
    const title = entry.title || entry.kind || 'Component';
    const storyName = entry.name || entry.story || 'Default';
    const { componentName, category } = extractComponentNameAndCategory(title);

    const iframeUrl = cleanBaseUrl
      ? `${cleanBaseUrl}/iframe.html?id=${encodeURIComponent(storyId)}&viewMode=story`
      : undefined;

    const story: StorybookStory = {
      id: storyId,
      name: storyName,
      title,
      componentName,
      category,
      importPath: entry.importPath,
      tags: Array.isArray(entry.tags) ? entry.tags : [],
      parameters: entry.parameters || {},
      args: entry.args || {},
      argTypes: entry.argTypes || {},
      iframeUrl,
    };

    storiesList.push(story);

    const groupKey = title.toLowerCase();
    if (!componentMap.has(groupKey)) {
      componentMap.set(groupKey, []);
    }
    componentMap.get(groupKey)!.push(story);
  }

  const componentsGroup: StorybookComponentGroup[] = [];
  for (const [, stories] of componentMap.entries()) {
    if (stories.length === 0) continue;
    const first = stories[0];
    componentsGroup.push({
      componentName: first.componentName,
      title: first.title,
      category: first.category,
      stories,
      defaultStoryId: stories[0].id,
    });
  }

  return {
    version,
    totalStories: storiesList.length,
    totalComponents: componentsGroup.length,
    components: componentsGroup,
    stories: storiesList,
  };
}

/**
 * Links parsed Storybook stories to component catalog records in the `components` table.
 */
export async function linkStorybookToComponents(
  db: any,
  designSystemId: string,
  parsedIndex: ParsedStorybookIndex,
  storybookBaseUrl?: string
): Promise<{
  linkedCount: number;
  createdCount: number;
  components: Array<{ id: string; name: string; storyCount: number }>;
}> {
  const existingComponents = await db
    .select()
    .from(components)
    .where(eq(components.designSystemId, designSystemId));

  const existingByName = new Map<string, any>();
  for (const c of existingComponents) {
    existingByName.set(c.name.toLowerCase(), c);
  }

  let linkedCount = 0;
  let createdCount = 0;
  const resultSummary: Array<{ id: string; name: string; storyCount: number }> = [];

  for (const group of parsedIndex.components) {
    const existing = existingByName.get(group.componentName.toLowerCase());
    const primaryStory = group.stories[0];
    const previewUrl = primaryStory.iframeUrl || (storybookBaseUrl ? `${storybookBaseUrl.replace(/\/+$/, '')}/iframe.html?id=${primaryStory.id}` : null);

    if (existing) {
      // Update existing record
      await db
        .update(components)
        .set({
          category: existing.category || group.category.toLowerCase(),
          description: existing.description || `Storybook component: ${group.title}`,
          updatedAt: new Date(),
        })
        .where(eq(components.id, existing.id));

      linkedCount++;
      resultSummary.push({
        id: existing.id,
        name: existing.name,
        storyCount: group.stories.length,
      });
    } else {
      // Create new component in catalog
      const newId = `comp-${group.componentName.toLowerCase().replace(/[^a-z0-9]/g, '-')}`;
      await db.insert(components).values({
        id: newId,
        designSystemId,
        name: group.componentName,
        category: group.category.toLowerCase(),
        framework: 'react',
        status: 'ready',
        description: `Imported from Storybook: ${group.title}`,
        isDeprecated: false,
        createdAt: new Date(),
        updatedAt: new Date(),
      }).onConflictDoNothing();

      createdCount++;
      resultSummary.push({
        id: newId,
        name: group.componentName,
        storyCount: group.stories.length,
      });
    }
  }

  return {
    linkedCount,
    createdCount,
    components: resultSummary,
  };
}
