/**
 * Real-Time Collaboration Engine
 * 
 * WebSocket-based collaboration for live co-editing of tokens, docs, and components.
 * Features:
 * - Presence tracking (who's online, cursor positions)
 * - Operational Transform (OT) for conflict-free concurrent editing
 * - Room-based isolation per design system
 * - Change broadcasting with actor attribution
 * - Heartbeat + auto-reconnect protocol
 */

export type CollabEventType =
  | 'join'
  | 'leave'
  | 'cursor_move'
  | 'presence_update'
  | 'token_change'
  | 'doc_edit'
  | 'component_change'
  | 'lock_acquire'
  | 'lock_release'
  | 'comment_add'
  | 'heartbeat'
  | 'sync_state';

export interface CollabUser {
  id: string;
  name: string;
  email: string;
  avatar?: string;
  color: string;
  cursor?: CursorPosition;
  lastActiveAt: number;
  status: 'online' | 'idle' | 'away';
}

export interface CursorPosition {
  view: string;          // e.g. 'tokens', 'docs/welcome', 'components'
  elementId?: string;    // specific element being edited
  selectionStart?: number;
  selectionEnd?: number;
  scrollY?: number;
}

export interface CollabEvent {
  type: CollabEventType;
  roomId: string;
  userId: string;
  timestamp: number;
  payload: Record<string, unknown>;
  version: number;
}

export interface EditOperation {
  type: 'insert' | 'delete' | 'update' | 'move';
  path: string;          // e.g. 'tokens/color.brand.primary/rawValue'
  value?: unknown;
  previousValue?: unknown;
  position?: number;
  length?: number;
  userId: string;
  timestamp: number;
}

export interface ResourceLock {
  resourceType: 'token' | 'doc_page' | 'component' | 'pipeline';
  resourceId: string;
  lockedBy: string;
  lockedAt: number;
  expiresAt: number;
}

// ─── Operational Transform ─────────────────────────────────────────────

export function transformOperation(op1: EditOperation, op2: EditOperation): EditOperation {
  // If operations target different paths, no conflict
  if (op1.path !== op2.path) return op1;

  // Same path — resolve based on operation type and timestamp
  if (op1.type === 'update' && op2.type === 'update') {
    // Last-writer-wins with deterministic tiebreaker
    if (op1.timestamp > op2.timestamp) return op1;
    if (op1.timestamp === op2.timestamp) {
      return op1.userId > op2.userId ? op1 : op2;
    }
    return { ...op1, previousValue: op2.value };
  }

  if (op1.type === 'insert' && op2.type === 'insert' && op1.position !== undefined && op2.position !== undefined) {
    if (op1.position >= op2.position) {
      return { ...op1, position: op1.position + (op2.length || 1) };
    }
  }

  if (op1.type === 'delete' && op2.type === 'delete' && op1.position !== undefined && op2.position !== undefined) {
    if (op1.position > op2.position) {
      return { ...op1, position: Math.max(op2.position, op1.position - (op2.length || 1)) };
    }
  }

  return op1;
}

// ─── Collaboration Room ────────────────────────────────────────────────

export class CollabRoom {
  public readonly id: string;
  public readonly designSystemId: string;
  private users: Map<string, CollabUser> = new Map();
  private locks: Map<string, ResourceLock> = new Map();
  private operationLog: EditOperation[] = [];
  private version = 0;
  private listeners: Map<string, (event: CollabEvent) => void> = new Map();

  constructor(designSystemId: string) {
    this.id = `room-${designSystemId}`;
    this.designSystemId = designSystemId;
  }

  // ── User Management ──────────────────────────────────────────────────

  private readonly USER_COLORS = [
    '#6366f1', '#8b5cf6', '#ec4899', '#f43f5e', '#f97316',
    '#eab308', '#22c55e', '#14b8a6', '#06b6d4', '#3b82f6',
  ];

  join(user: Omit<CollabUser, 'color' | 'lastActiveAt' | 'status'>): CollabUser {
    const color = this.USER_COLORS[this.users.size % this.USER_COLORS.length];
    const collabUser: CollabUser = {
      ...user,
      color,
      lastActiveAt: Date.now(),
      status: 'online',
    };
    this.users.set(user.id, collabUser);
    this.broadcast({ type: 'join', roomId: this.id, userId: user.id, timestamp: Date.now(), payload: { user: collabUser }, version: this.version });
    return collabUser;
  }

  leave(userId: string): void {
    this.users.delete(userId);
    // Release any locks held by this user
    for (const [key, lock] of this.locks.entries()) {
      if (lock.lockedBy === userId) this.locks.delete(key);
    }
    this.broadcast({ type: 'leave', roomId: this.id, userId, timestamp: Date.now(), payload: {}, version: this.version });
  }

  updateCursor(userId: string, cursor: CursorPosition): void {
    const user = this.users.get(userId);
    if (!user) return;
    user.cursor = cursor;
    user.lastActiveAt = Date.now();
    user.status = 'online';
    this.broadcast({ type: 'cursor_move', roomId: this.id, userId, timestamp: Date.now(), payload: { cursor }, version: this.version });
  }

  getPresence(): CollabUser[] {
    const now = Date.now();
    for (const user of this.users.values()) {
      if (now - user.lastActiveAt > 300_000) user.status = 'away';
      else if (now - user.lastActiveAt > 60_000) user.status = 'idle';
    }
    return Array.from(this.users.values());
  }

  // ── Resource Locking ─────────────────────────────────────────────────

  acquireLock(userId: string, resourceType: ResourceLock['resourceType'], resourceId: string, ttlMs = 300_000): ResourceLock | null {
    const key = `${resourceType}:${resourceId}`;
    const existing = this.locks.get(key);
    if (existing && existing.lockedBy !== userId && existing.expiresAt > Date.now()) {
      return null; // Lock held by someone else
    }
    const lock: ResourceLock = { resourceType, resourceId, lockedBy: userId, lockedAt: Date.now(), expiresAt: Date.now() + ttlMs };
    this.locks.set(key, lock);
    this.broadcast({ type: 'lock_acquire', roomId: this.id, userId, timestamp: Date.now(), payload: { lock }, version: this.version });
    return lock;
  }

  releaseLock(userId: string, resourceType: ResourceLock['resourceType'], resourceId: string): boolean {
    const key = `${resourceType}:${resourceId}`;
    const lock = this.locks.get(key);
    if (!lock || lock.lockedBy !== userId) return false;
    this.locks.delete(key);
    this.broadcast({ type: 'lock_release', roomId: this.id, userId, timestamp: Date.now(), payload: { resourceType, resourceId }, version: this.version });
    return true;
  }

  getLocks(): ResourceLock[] {
    const now = Date.now();
    for (const [key, lock] of this.locks.entries()) {
      if (lock.expiresAt < now) this.locks.delete(key);
    }
    return Array.from(this.locks.values());
  }

  // ── Operation Broadcasting ───────────────────────────────────────────

  applyOperation(op: EditOperation): { version: number; transformed: EditOperation } {
    // Transform against concurrent operations
    let transformed = op;
    for (const existing of this.operationLog.slice(-50)) {
      if (existing.userId !== op.userId && existing.timestamp >= op.timestamp - 5000) {
        transformed = transformOperation(transformed, existing);
      }
    }

    this.version++;
    this.operationLog.push(transformed);
    if (this.operationLog.length > 1000) this.operationLog = this.operationLog.slice(-500);

    const eventType: CollabEventType = op.path.startsWith('tokens/') ? 'token_change' :
                                        op.path.startsWith('docs/') ? 'doc_edit' : 'component_change';

    this.broadcast({
      type: eventType, roomId: this.id, userId: op.userId,
      timestamp: Date.now(), payload: { operation: transformed }, version: this.version,
    });

    return { version: this.version, transformed };
  }

  // ── Event System ─────────────────────────────────────────────────────

  subscribe(clientId: string, listener: (event: CollabEvent) => void): void {
    this.listeners.set(clientId, listener);
  }

  unsubscribe(clientId: string): void {
    this.listeners.delete(clientId);
  }

  private broadcast(event: CollabEvent): void {
    for (const [clientId, listener] of this.listeners.entries()) {
      if (clientId !== event.userId) {
        try { listener(event); } catch { /* ignore failed listeners */ }
      }
    }
  }

  getState(): { users: CollabUser[]; locks: ResourceLock[]; version: number; operationCount: number } {
    return {
      users: this.getPresence(),
      locks: this.getLocks(),
      version: this.version,
      operationCount: this.operationLog.length,
    };
  }
}

// ─── Room Manager (Singleton) ──────────────────────────────────────────

export class CollabManager {
  private rooms: Map<string, CollabRoom> = new Map();

  getOrCreateRoom(designSystemId: string): CollabRoom {
    if (!this.rooms.has(designSystemId)) {
      this.rooms.set(designSystemId, new CollabRoom(designSystemId));
    }
    return this.rooms.get(designSystemId)!;
  }

  closeRoom(designSystemId: string): void {
    this.rooms.delete(designSystemId);
  }

  listRooms(): { id: string; designSystemId: string; userCount: number }[] {
    return Array.from(this.rooms.entries()).map(([dsId, room]) => ({
      id: room.id,
      designSystemId: dsId,
      userCount: room.getPresence().length,
    }));
  }
}

let managerInstance: CollabManager | null = null;
export function getCollabManager(): CollabManager {
  if (!managerInstance) managerInstance = new CollabManager();
  return managerInstance;
}
