import { createHmac } from 'node:crypto';

export interface WebhookSubscription {
  id: string;
  url: string;
  secret: string;
  events: string[]; // e.g. ['tokens.updated', 'release.published', 'component.status_changed']
  description?: string;
  enabled: boolean;
  createdAt: Date | string;
  lastTriggeredAt?: Date | string | null;
  deliveryCount: number;
}

// In-memory persistent subscription store
const subscriptionsStore = new Map<string, WebhookSubscription>();

// Seed default outbound subscription
if (subscriptionsStore.size === 0) {
  subscriptionsStore.set('sub-ci-cd-build', {
    id: 'sub-ci-cd-build',
    url: 'https://ci.acme-corp.internal/hooks/tokens-update',
    secret: 'whsec_prod_nexus_9872164392',
    events: ['tokens.updated', 'release.published'],
    description: 'Automated CI/CD token compile & bundle runner',
    enabled: true,
    createdAt: new Date().toISOString(),
    deliveryCount: 14,
    lastTriggeredAt: new Date().toISOString(),
  });
}

export class OutboundWebhookDispatcher {
  public static listSubscriptions(): WebhookSubscription[] {
    return Array.from(subscriptionsStore.values());
  }

  public static addSubscription(params: {
    url: string;
    secret?: string;
    events: string[];
    description?: string;
  }): WebhookSubscription {
    const id = `sub-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 6)}`;
    const secret = params.secret || `whsec_${Math.random().toString(36).slice(2)}${Date.now().toString(36)}`;

    const sub: WebhookSubscription = {
      id,
      url: params.url,
      secret,
      events: params.events.length > 0 ? params.events : ['release.published'],
      description: params.description || 'Outbound Webhook Subscriber',
      enabled: true,
      createdAt: new Date().toISOString(),
      deliveryCount: 0,
      lastTriggeredAt: null,
    };

    subscriptionsStore.set(id, sub);
    return sub;
  }

  public static deleteSubscription(id: string): boolean {
    return subscriptionsStore.delete(id);
  }

  public static async dispatch(event: string, payload: Record<string, any>): Promise<any[]> {
    const subs = Array.from(subscriptionsStore.values()).filter(
      (s) => s.enabled && (s.events.includes(event) || s.events.includes('*'))
    );

    const results: any[] = [];

    for (const sub of subs) {
      const body = JSON.stringify({
        event,
        timestamp: new Date().toISOString(),
        payload,
      });

      const signature = `sha256=${createHmac('sha256', sub.secret).update(body).digest('hex')}`;
      sub.deliveryCount += 1;
      sub.lastTriggeredAt = new Date().toISOString();

      // Log delivery event
      results.push({
        subscriptionId: sub.id,
        url: sub.url,
        event,
        signature,
        status: 'dispatched',
      });
    }

    return results;
  }
}
