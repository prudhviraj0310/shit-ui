export interface FigmaVariable {
  id: string;
  name: string; // e.g. "color/brand/primary" or "spacing/md"
  key: string;
  variableCollectionId: string;
  resolvedType: 'COLOR' | 'FLOAT' | 'STRING' | 'BOOLEAN';
  valuesByMode: Record<string, any>; // modeId -> RGBA object or { type: 'VARIABLE_ALIAS', id: '...' }
  description?: string;
  hiddenFromPublishing?: boolean;
}

export interface FigmaVariableCollection {
  id: string;
  name: string; // e.g. "Color Palette", "Spacing Scale"
  modes: Array<{
    modeId: string;
    name: string; // e.g. "Light", "Dark", "Default"
  }>;
  defaultModeId: string;
}

export interface FigmaVariablesResponse {
  status?: number;
  error?: boolean;
  message?: string;
  meta?: {
    variableCollections: Record<string, FigmaVariableCollection>;
    variables: Record<string, FigmaVariable>;
  };
}

export interface FigmaSyncRequest {
  fileKey: string;
  figmaToken?: string;
  selectedCollectionIds?: string[];
  modeName?: string; // e.g. "Light" or "Default"
  dryRun?: boolean;
}

export interface TokenDiffItem {
  path: string;
  status: 'added' | 'modified' | 'unchanged' | 'conflict' | 'removed';
  oldValue?: string;
  newValue?: string;
  category: string;
}

export interface FigmaSyncResult {
  success: boolean;
  totalVariablesFound: number;
  tokensImported: number;
  diff: TokenDiffItem[];
  error?: string;
}

export interface FigmaPushVariableCollectionAction {
  action: 'CREATE' | 'UPDATE' | 'DELETE';
  id: string;
  name: string;
  initialModeId?: string;
}

export interface FigmaPushVariableModeAction {
  action: 'CREATE' | 'UPDATE' | 'DELETE';
  id: string;
  name: string;
  variableCollectionId: string;
}

export interface FigmaPushVariableAction {
  action: 'CREATE' | 'UPDATE' | 'DELETE';
  id: string;
  name: string;
  variableCollectionId: string;
  resolvedType: 'COLOR' | 'FLOAT' | 'STRING' | 'BOOLEAN';
  description?: string;
  hiddenFromPublishing?: boolean;
}

export interface FigmaPushVariableModeValue {
  variableId: string;
  modeId: string;
  value: any;
}

export interface FigmaVariablePushPayload {
  variableCollections?: FigmaPushVariableCollectionAction[];
  variableModes?: FigmaPushVariableModeAction[];
  variables?: FigmaPushVariableAction[];
  variableModeValues?: FigmaPushVariableModeValue[];
}

export interface FigmaPushResult {
  success: boolean;
  pushedCount: number;
  createdCount: number;
  updatedCount: number;
  payload: FigmaVariablePushPayload;
  meta?: any;
  error?: string;
  dryRun?: boolean;
}

