import { FlatToken } from '../tokens/types';
import {
  FigmaVariablePushPayload,
  FigmaPushResult,
  FigmaPushVariableAction,
  FigmaPushVariableCollectionAction,
  FigmaPushVariableModeAction,
  FigmaPushVariableModeValue,
} from './types';

/**
 * Converts CSS / DTCG color representations into Figma 0..1 RGBA float format.
 */
export function parseColorToFigmaRgba(colorStr: string): { r: number; g: number; b: number; a: number } {
  const str = String(colorStr).trim();

  // Hex colors: #rgb, #rgba, #rrggbb, #rrggbbaa
  if (str.startsWith('#')) {
    const raw = str.slice(1);
    if (raw.length === 3) {
      const r = parseInt(raw[0] + raw[0], 16) / 255;
      const g = parseInt(raw[1] + raw[1], 16) / 255;
      const b = parseInt(raw[2] + raw[2], 16) / 255;
      return { r: Number(r.toFixed(4)), g: Number(g.toFixed(4)), b: Number(b.toFixed(4)), a: 1 };
    }
    if (raw.length === 4) {
      const r = parseInt(raw[0] + raw[0], 16) / 255;
      const g = parseInt(raw[1] + raw[1], 16) / 255;
      const b = parseInt(raw[2] + raw[2], 16) / 255;
      const a = parseInt(raw[3] + raw[3], 16) / 255;
      return { r: Number(r.toFixed(4)), g: Number(g.toFixed(4)), b: Number(b.toFixed(4)), a: Number(a.toFixed(4)) };
    }
    if (raw.length === 6) {
      const r = parseInt(raw.slice(0, 2), 16) / 255;
      const g = parseInt(raw.slice(2, 4), 16) / 255;
      const b = parseInt(raw.slice(4, 6), 16) / 255;
      return { r: Number(r.toFixed(4)), g: Number(g.toFixed(4)), b: Number(b.toFixed(4)), a: 1 };
    }
    if (raw.length === 8) {
      const r = parseInt(raw.slice(0, 2), 16) / 255;
      const g = parseInt(raw.slice(2, 4), 16) / 255;
      const b = parseInt(raw.slice(4, 6), 16) / 255;
      const a = parseInt(raw.slice(6, 8), 16) / 255;
      return { r: Number(r.toFixed(4)), g: Number(g.toFixed(4)), b: Number(b.toFixed(4)), a: Number(a.toFixed(4)) };
    }
  }

  // rgb(...) / rgba(...)
  const rgbMatch = str.match(/rgba?\s*\(\s*([\d.]+)\s*,\s*([\d.]+)\s*,\s*([\d.]+)(?:\s*,\s*([\d.]+))?\s*\)/i);
  if (rgbMatch) {
    const r = Math.min(255, Math.max(0, parseFloat(rgbMatch[1]))) / 255;
    const g = Math.min(255, Math.max(0, parseFloat(rgbMatch[2]))) / 255;
    const b = Math.min(255, Math.max(0, parseFloat(rgbMatch[3]))) / 255;
    const a = rgbMatch[4] !== undefined ? Math.min(1, Math.max(0, parseFloat(rgbMatch[4]))) : 1;
    return { r: Number(r.toFixed(4)), g: Number(g.toFixed(4)), b: Number(b.toFixed(4)), a: Number(a.toFixed(4)) };
  }

  // Fallback default
  return { r: 0, g: 0, b: 0, a: 1 };
}

/**
 * Converts CSS dimension strings into numeric float values for Figma.
 */
export function parseDimensionToFloat(dimValue: any): number {
  if (typeof dimValue === 'number') return dimValue;
  const str = String(dimValue || '').trim().toLowerCase();
  if (str.endsWith('rem')) {
    const num = parseFloat(str.replace('rem', ''));
    return Number((num * 16).toFixed(2));
  }
  if (str.endsWith('px')) {
    return parseFloat(str.replace('px', '')) || 0;
  }
  const parsed = parseFloat(str);
  return isNaN(parsed) ? 0 : parsed;
}

/**
 * Builds the Figma Variable Push payload from DTCG FlatToken array.
 */
export function buildFigmaVariablePushPayload(
  tokens: FlatToken[],
  existingData?: {
    variableCollections?: Record<string, any>;
    variables?: Record<string, any>;
  },
  collectionName: string = 'Nexus Design OS'
): {
  payload: FigmaVariablePushPayload;
  createdCount: number;
  updatedCount: number;
} {
  const variableCollections: FigmaPushVariableCollectionAction[] = [];
  const variableModes: FigmaPushVariableModeAction[] = [];
  const variables: FigmaPushVariableAction[] = [];
  const variableModeValues: FigmaPushVariableModeValue[] = [];

  // Match existing collection or create new one
  let collectionId = 'temp_collection_nexus';
  let modeId = 'temp_mode_default';
  let isCollectionNew = true;

  if (existingData?.variableCollections) {
    for (const [colId, col] of Object.entries(existingData.variableCollections)) {
      if (col.name === collectionName || !collectionId.startsWith('real_')) {
        collectionId = colId;
        modeId = col.defaultModeId || (col.modes && col.modes[0]?.modeId) || 'temp_mode_default';
        isCollectionNew = false;
        break;
      }
    }
  }

  if (isCollectionNew) {
    variableCollections.push({
      action: 'CREATE',
      id: collectionId,
      name: collectionName,
      initialModeId: modeId,
    });
  }

  // Build existing variables map by name
  const existingVarsByName = new Map<string, any>();
  if (existingData?.variables) {
    for (const [vId, v] of Object.entries(existingData.variables)) {
      existingVarsByName.set(v.name, { id: vId, ...v });
    }
  }

  // Pre-map paths to temp or existing variable IDs for alias referencing
  const pathToVarId = new Map<string, string>();
  tokens.forEach((t, index) => {
    const figmaName = t.path.replace(/\./g, '/');
    const existing = existingVarsByName.get(figmaName);
    pathToVarId.set(t.path, existing ? existing.id : `temp_var_${index + 1}`);
  });

  let createdCount = 0;
  let updatedCount = 0;

  tokens.forEach((token, index) => {
    const figmaName = token.path.replace(/\./g, '/');
    const existing = existingVarsByName.get(figmaName);
    const varId = existing ? existing.id : `temp_var_${index + 1}`;
    const action = existing ? 'UPDATE' : 'CREATE';

    if (existing) {
      updatedCount++;
    } else {
      createdCount++;
    }

    // Determine Figma Variable Type
    let resolvedType: 'COLOR' | 'FLOAT' | 'STRING' | 'BOOLEAN' = 'STRING';
    const cat = (token.category || '').toLowerCase();
    const typ = (token.type || '').toLowerCase();

    if (cat === 'color' || typ === 'color') {
      resolvedType = 'COLOR';
    } else if (
      cat === 'spacing' ||
      cat === 'dimension' ||
      cat === 'radius' ||
      cat === 'size' ||
      typ === 'dimension' ||
      typ === 'spacing' ||
      typ === 'borderradius' ||
      typ === 'borderwidth' ||
      typ === 'number'
    ) {
      resolvedType = 'FLOAT';
    } else if (typ === 'boolean') {
      resolvedType = 'BOOLEAN';
    } else {
      resolvedType = 'STRING';
    }

    variables.push({
      action,
      id: varId,
      name: figmaName,
      variableCollectionId: collectionId,
      resolvedType,
      description: token.description || `Design token for ${token.path}`,
    });

    // Determine Mode Value (handle aliases and type transformations)
    let modeValue: any;

    // Check if token value is an alias e.g. {color.brand.primary} or has aliasTarget
    const rawValStr = typeof token.rawValue === 'string' ? token.rawValue.trim() : '';
    const rawValAliasMatch = rawValStr.match(/^{([^{}]+)}$/);
    const targetAliasPath = token.aliasTarget || (rawValAliasMatch ? rawValAliasMatch[1] : null);

    if (targetAliasPath && pathToVarId.has(targetAliasPath)) {
      modeValue = {
        type: 'VARIABLE_ALIAS',
        id: pathToVarId.get(targetAliasPath),
      };
    } else {
      const rawVal = token.resolvedValue !== undefined && token.resolvedValue !== '' ? token.resolvedValue : token.rawValue;
      switch (resolvedType) {

        case 'COLOR':
          modeValue = parseColorToFigmaRgba(String(rawVal));
          break;
        case 'FLOAT':
          modeValue = parseDimensionToFloat(rawVal);
          break;
        case 'BOOLEAN':
          modeValue = String(rawVal).toLowerCase() === 'true';
          break;
        case 'STRING':
        default:
          modeValue = typeof rawVal === 'object' ? JSON.stringify(rawVal) : String(rawVal);
          break;
      }
    }

    variableModeValues.push({
      variableId: varId,
      modeId,
      value: modeValue,
    });
  });

  return {
    payload: {
      ...(variableCollections.length > 0 ? { variableCollections } : {}),
      ...(variableModes.length > 0 ? { variableModes } : {}),
      variables,
      variableModeValues,
    },
    createdCount,
    updatedCount,
  };
}

/**
 * Pushes design tokens to Figma via the official REST API `POST /v1/files/:file_key/variables`.
 */
export async function pushVariablesToFigma(
  fileKey: string,
  tokens: FlatToken[],
  tokenSecret: string,
  options?: {
    dryRun?: boolean;
    collectionName?: string;
  }
): Promise<FigmaPushResult> {
  if (!fileKey) {
    throw new Error('Figma file key is required.');
  }
  if (!tokens || tokens.length === 0) {
    throw new Error('No tokens provided to push to Figma.');
  }

  const dryRun = Boolean(options?.dryRun);
  let existingData: any = undefined;

  // Attempt to fetch existing variables for diffing & updating if token is present
  if (tokenSecret) {
    try {
      const res = await fetch(`https://api.figma.com/v1/files/${fileKey}/variables/local`, {
        headers: {
          'X-Figma-Token': tokenSecret,
          'User-Agent': 'NexusDesign-OS/1.0.0',
        },
      });
      if (res.ok) {
        const json = await res.json();
        existingData = json?.meta;
      }
    } catch {
      // Non-fatal if offline, testing, or restricted scope
    }
  }

  const { payload, createdCount, updatedCount } = buildFigmaVariablePushPayload(
    tokens,
    existingData,
    options?.collectionName || 'Nexus Design OS'
  );

  // In dryRun mode, return synthesized plan without remote mutation
  if (dryRun) {
    return {
      success: true,
      pushedCount: tokens.length,
      createdCount,
      updatedCount,
      payload,
      dryRun: true,
    };
  }

  if (!tokenSecret) {
    throw new Error('Figma API access token (X-Figma-Token or Bearer) is required for live push.');
  }

  const pushRes = await fetch(`https://api.figma.com/v1/files/${fileKey}/variables`, {
    method: 'POST',
    headers: {
      'X-Figma-Token': tokenSecret,
      'Content-Type': 'application/json',
      'User-Agent': 'NexusDesign-OS/1.0.0',
    },
    body: JSON.stringify(payload),
  });

  if (!pushRes.ok) {
    let errorDetail = pushRes.statusText;
    try {
      const errJson = await pushRes.json();
      if (errJson?.message) errorDetail = errJson.message;
    } catch {
      // ignore
    }
    throw new Error(`Figma Variables API returned HTTP ${pushRes.status}: ${errorDetail}`);
  }

  const resultMeta = await pushRes.json();

  return {
    success: true,
    pushedCount: tokens.length,
    createdCount,
    updatedCount,
    payload,
    meta: resultMeta?.meta,
    dryRun: false,
  };
}
