/**
 * Design Handoff Engine
 *
 * Generates developer-ready design specifications from tokens and components:
 * - Token-to-code mapping with copy-ready snippets
 * - Component spec sheets with props, variants, and usage examples
 * - Spacing/sizing measurement overlays
 * - Platform-specific implementation guides (Web, iOS, Android)
 * - Accessibility annotations
 * - Redline/measurement exports
 */

export interface HandoffSpec {
  id: string;
  name: string;
  description: string;
  createdAt: number;
  createdBy: string;
  components: ComponentSpec[];
  tokens: TokenSpec[];
  pages: PageSpec[];
  platforms: PlatformGuide[];
  accessibility: AccessibilityNote[];
}

export interface ComponentSpec {
  name: string;
  description: string;
  category: string;
  status: 'ready' | 'in-progress' | 'deprecated';
  props: PropSpec[];
  variants: VariantSpec[];
  tokens: string[];             // Token paths used by this component
  codeSnippets: CodeSnippet[];
  measurements: Measurement[];
  dosDonts: { do: string; dont: string }[];
}

export interface PropSpec {
  name: string;
  type: string;
  required: boolean;
  default?: string;
  description: string;
  options?: string[];
}

export interface VariantSpec {
  name: string;
  props: Record<string, string>;
  description: string;
  tokenOverrides?: Record<string, string>;
}

export interface CodeSnippet {
  platform: 'react' | 'vue' | 'angular' | 'swift' | 'kotlin' | 'flutter' | 'html';
  language: string;
  code: string;
  label: string;
}

export interface Measurement {
  property: string;
  value: string;
  tokenPath?: string;
  note?: string;
}

export interface TokenSpec {
  path: string;
  value: string;
  category: string;
  platforms: {
    web: string;     // CSS custom property
    ios: string;     // Swift code
    android: string; // Kotlin/Compose code
    flutter: string; // Dart code
  };
  usage: string;     // Description of where/how to use
}

export interface PageSpec {
  name: string;
  description: string;
  sections: {
    title: string;
    content: string;
    componentRefs: string[];
    tokenRefs: string[];
  }[];
}

export interface PlatformGuide {
  platform: 'web' | 'ios' | 'android' | 'flutter';
  setupInstructions: string;
  installCommand: string;
  importStatement: string;
  usageExample: string;
}

export interface AccessibilityNote {
  component: string;
  level: 'A' | 'AA' | 'AAA';
  criteria: string;
  notes: string;
  ariaAttributes?: Record<string, string>;
  minContrastRatio?: number;
  focusManagement?: string;
  keyboardInteraction?: string;
}

// ─── Handoff Generator ─────────────────────────────────────────────────

import type { FlatToken } from '../tokens/types';
import { toCamelCase, toPascalCase, toKebabCase, toSnakeCase } from '../pulsar/engine';

export class HandoffGenerator {

  generateTokenSpecs(tokens: FlatToken[]): TokenSpec[] {
    return tokens.map(token => ({
      path: token.path,
      value: String(typeof token.resolvedValue === 'object' ? JSON.stringify(token.resolvedValue) : (token.resolvedValue || token.rawValue || '')),
      category: token.category,
      platforms: {
        web: `var(--nova-${toKebabCase(token.path)})`,
        ios: this.generateSwiftRef(token),
        android: this.generateKotlinRef(token),
        flutter: this.generateFlutterRef(token),
      },
      usage: this.generateUsageHint(token),
    }));
  }

  generateComponentSpec(component: {
    name: string;
    description: string;
    props: PropSpec[];
    variants: VariantSpec[];
    tokens: string[];
  }, allTokens: FlatToken[]): ComponentSpec {
    const usedTokens = allTokens.filter(t => component.tokens.includes(t.path));

    return {
      ...component,
      category: this.inferCategory(component.name),
      status: 'ready',
      codeSnippets: this.generateCodeSnippets(component),
      measurements: this.generateMeasurements(usedTokens),
      dosDonts: this.generateDosDonts(component.name),
    };
  }

  generatePlatformGuides(): PlatformGuide[] {
    return [
      {
        platform: 'web',
        setupInstructions: 'Import the generated CSS custom properties into your root stylesheet.',
        installCommand: 'npm install @nexus-design/tokens',
        importStatement: "import '@nexus-design/tokens/tokens.css';",
        usageExample: `.button {\n  background: var(--nova-color-brand-primary);\n  padding: var(--nova-spacing-sm) var(--nova-spacing-md);\n  border-radius: var(--nova-borderRadius-md);\n}`,
      },
      {
        platform: 'ios',
        setupInstructions: 'Add the generated Swift package to your Xcode project via SPM.',
        installCommand: '.package(url: "https://github.com/your-org/nexus-tokens-swift", from: "1.0.0")',
        importStatement: 'import NexusTokens',
        usageExample: `Button("Submit") {\n  // action\n}\n.foregroundColor(NovaTokens.Colors.brandPrimary)\n.padding(NovaTokens.Spacing.md)`,
      },
      {
        platform: 'android',
        setupInstructions: 'Add the generated Kotlin Compose theme to your Android project.',
        installCommand: "implementation 'com.nexus-design:tokens:1.0.0'",
        importStatement: 'import com.novadesign.tokens.*',
        usageExample: `Button(\n  onClick = { },\n  colors = ButtonDefaults.buttonColors(\n    containerColor = NovaColors.BrandPrimary\n  )\n) {\n  Text("Submit")\n}`,
      },
      {
        platform: 'flutter',
        setupInstructions: 'Add the Dart token package as a dependency.',
        installCommand: 'flutter pub add nexus_tokens',
        importStatement: "import 'package:nexus_tokens/tokens.dart';",
        usageExample: `ElevatedButton(\n  style: ElevatedButton.styleFrom(\n    backgroundColor: AppTokens.colorBrandPrimary,\n    padding: EdgeInsets.all(AppTokens.spacingMd),\n  ),\n  child: Text('Submit'),\n  onPressed: () {},\n)`,
      },
    ];
  }

  generateAccessibilityNotes(componentName: string): AccessibilityNote[] {
    const notes: Record<string, AccessibilityNote> = {
      Button: {
        component: 'Button',
        level: 'AA',
        criteria: 'WCAG 2.1 — 4.5:1 contrast ratio, focusable, keyboard accessible',
        notes: 'Ensure button text meets 4.5:1 contrast ratio against background. Interactive states must be distinguishable.',
        ariaAttributes: { role: 'button', 'aria-disabled': 'false' },
        minContrastRatio: 4.5,
        focusManagement: 'Visible focus ring using --nova-color-brand-primary with 2px offset',
        keyboardInteraction: 'Enter/Space to activate. Tab to navigate.',
      },
      TextInput: {
        component: 'TextInput',
        level: 'AA',
        criteria: 'WCAG 2.1 — Labels, error states, focus management',
        notes: 'Every input must have a visible label. Error messages must be announced to screen readers.',
        ariaAttributes: { 'aria-required': 'true', 'aria-invalid': 'false', 'aria-describedby': '{id}-error' },
        minContrastRatio: 4.5,
        focusManagement: 'Auto-focus on mount if primary CTA. Visible focus ring.',
        keyboardInteraction: 'Tab to focus. Escape to clear.',
      },
      Modal: {
        component: 'Modal',
        level: 'AA',
        criteria: 'WCAG 2.1 — Focus trap, escape to close, aria-modal',
        notes: 'Modal must trap focus. Background content must be inert. First focusable element receives focus.',
        ariaAttributes: { role: 'dialog', 'aria-modal': 'true', 'aria-labelledby': '{id}-title' },
        focusManagement: 'Trap focus within modal. Return focus to trigger on close.',
        keyboardInteraction: 'Escape to close. Tab cycles within modal.',
      },
    };

    return notes[componentName] ? [notes[componentName]] : [{
      component: componentName,
      level: 'AA',
      criteria: 'WCAG 2.1 Level AA compliance required',
      notes: 'Ensure sufficient color contrast, keyboard accessibility, and screen reader support.',
    }];
  }

  generateFullHandoff(tokens: FlatToken[], components: { name: string; description: string; props: PropSpec[]; variants: VariantSpec[]; tokens: string[] }[]): HandoffSpec {
    return {
      id: `handoff-${Date.now().toString(36)}`,
      name: 'Design Handoff Package',
      description: 'Complete developer handoff specification with tokens, components, and platform guides.',
      createdAt: Date.now(),
      createdBy: 'Nexus Design OS',
      tokens: this.generateTokenSpecs(tokens),
      components: components.map(c => this.generateComponentSpec(c, tokens)),
      pages: [{
        name: 'Overview',
        description: 'Getting started with the design system',
        sections: [
          { title: 'Installation', content: 'Install the token package for your platform.', componentRefs: [], tokenRefs: [] },
          { title: 'Token Usage', content: 'All design decisions are expressed as tokens. Never hardcode values.', componentRefs: [], tokenRefs: tokens.slice(0, 5).map(t => t.path) },
        ],
      }],
      platforms: this.generatePlatformGuides(),
      accessibility: components.flatMap(c => this.generateAccessibilityNotes(c.name)),
    };
  }

  // ── Private Helpers ──────────────────────────────────────────────────

  private generateSwiftRef(token: FlatToken): string {
    if (token.category === 'color') return `NovaTokens.Colors.${toCamelCase(token.path.split('.').slice(1).join('.'))}`;
    if (token.category === 'spacing') return `NovaTokens.Spacing.${toCamelCase(token.path.split('.').pop() || '')}`;
    return `NovaTokens.${toPascalCase(token.category)}.${toCamelCase(token.path.split('.').pop() || '')}`;
  }

  private generateKotlinRef(token: FlatToken): string {
    if (token.category === 'color') return `NovaColors.${toPascalCase(token.path.split('.').slice(1).join('_'))}`;
    if (token.category === 'spacing') return `NovaSpacing.${toPascalCase(token.path.split('.').pop() || '')}`;
    return `Nova${toPascalCase(token.category)}.${toPascalCase(token.path.split('.').pop() || '')}`;
  }

  private generateFlutterRef(token: FlatToken): string {
    return `AppTokens.${toCamelCase(token.path.replace(/\./g, '_'))}`;
  }

  private generateUsageHint(token: FlatToken): string {
    const name = token.path.split('.').pop() || '';
    if (token.category === 'color') {
      if (name.includes('primary')) return 'Primary brand color for CTAs, links, and focus states.';
      if (name.includes('text')) return 'Text color for body copy and headings.';
      if (name.includes('background') || name.includes('surface')) return 'Background/surface color for cards, modals, and page backgrounds.';
      return `Color token for ${name} contexts.`;
    }
    if (token.category === 'spacing') return `Spacing value for ${name}-sized gaps, padding, and margins.`;
    if (token.category === 'typography') return `Typography value for ${name}.`;
    return `Design token for ${token.category} — ${name}.`;
  }

  private generateCodeSnippets(component: { name: string; props: PropSpec[] }): CodeSnippet[] {
    const propsStr = component.props.filter(p => p.required).map(p => `${p.name}="${p.default || '...'}" `).join('');
    return [
      { platform: 'react', language: 'tsx', label: 'React', code: `<${component.name} ${propsStr}/>` },
      { platform: 'vue', language: 'vue', label: 'Vue', code: `<${component.name} ${propsStr}/>` },
      { platform: 'html', language: 'html', label: 'HTML', code: `<div class="nexus-${toKebabCase(component.name)}">\n  <!-- ${component.name} content -->\n</div>` },
    ];
  }

  private generateMeasurements(tokens: FlatToken[]): Measurement[] {
    return tokens.slice(0, 8).map(t => ({
      property: t.category,
      value: String(typeof t.resolvedValue === 'object' ? JSON.stringify(t.resolvedValue) : (t.resolvedValue || t.rawValue || '')),
      tokenPath: t.path,
    }));
  }

  private generateDosDonts(name: string): { do: string; dont: string }[] {
    return [
      { do: `Use the ${name} component from the design system`, dont: `Create a custom ${name.toLowerCase()} with hardcoded styles` },
      { do: 'Use design tokens for all styling values', dont: 'Hardcode hex colors, pixel values, or font sizes' },
    ];
  }

  private inferCategory(name: string): string {
    if (/button|btn/i.test(name)) return 'actions';
    if (/input|text|form|select/i.test(name)) return 'inputs';
    if (/card|modal|dialog|panel/i.test(name)) return 'containers';
    if (/badge|tag|chip/i.test(name)) return 'indicators';
    return 'general';
  }
}

let handoffInstance: HandoffGenerator | null = null;
export function getHandoffGenerator(): HandoffGenerator {
  if (!handoffInstance) handoffInstance = new HandoffGenerator();
  return handoffInstance;
}
