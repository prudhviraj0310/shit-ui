/**
 * Pulsar — Supernova-Compatible Custom Exporter Scripting & AST Engine
 * 
 * Powered by Handlebars AST and custom Supernova helper registry:
 * - Handlebars AST compilation and execution (.pr files)
 * - Standard Supernova helpers (case transformers, filter-tokens, color-format, strip-unit)
 * - Exporter package manifest parsing (config.json)
 * - Multi-platform export targets (CSS, SCSS, React, TypeScript, Flutter, Kotlin, Swift)
 */

import Handlebars from 'handlebars';
import { FlatToken } from '../tokens/types';

// ─── Template & Package Types ──────────────────────────────────────────

export interface PulsarTemplate {
  id: string;
  name: string;
  description: string;
  version: string;
  author: string;
  outputFileName: string;
  template: string; // Handlebars AST or legacy template string
  helpers?: Record<string, string>;
  settings?: PulsarSetting[];
}

export interface PulsarSetting {
  key: string;
  label: string;
  type: 'string' | 'boolean' | 'number' | 'select';
  default: any;
  options?: { label: string; value: any }[];
}

export interface PulsarPackageManifest {
  id: string;
  name: string;
  version: string;
  description: string;
  author: string;
  homepage?: string;
  repository?: string;
  writer: string; // e.g. "supernova.writer.file"
  templates: {
    name: string;
    outputFileName: string;
    path: string;
  }[];
  settings?: PulsarSetting[];
}

export interface PulsarContext {
  tokens: FlatToken[];
  settings: Record<string, any>;
  metadata: {
    designSystemName: string;
    version: string;
    timestamp: string;
    totalTokens: number;
  };
}

export interface PulsarResult {
  success: boolean;
  output: string;
  fileName: string;
  errors: string[];
  warnings: string[];
  stats: {
    tokensProcessed: number;
    linesGenerated: number;
    executionMs: number;
  };
}

// ─── String Transformation Functions ───────────────────────────────────

export function toCamelCase(str: string): string {
  return str
    .replace(/[^a-zA-Z0-9]+(.)/g, (_, c) => c.toUpperCase())
    .replace(/^[A-Z]/, (c) => c.toLowerCase());
}

export function toPascalCase(str: string): string {
  return str
    .replace(/[^a-zA-Z0-9]+(.)/g, (_, c) => c.toUpperCase())
    .replace(/^[a-z]/, (c) => c.toUpperCase());
}

export function toKebabCase(str: string): string {
  return str
    .replace(/([a-z])([A-Z])/g, '$1-$2')
    .replace(/[^a-zA-Z0-9]+/g, '-')
    .toLowerCase();
}

export function toSnakeCase(str: string): string {
  return str
    .replace(/([a-z])([A-Z])/g, '$1_$2')
    .replace(/[^a-zA-Z0-9]+/g, '_')
    .toLowerCase();
}

export function toUpperSnakeCase(str: string): string {
  return toSnakeCase(str).toUpperCase();
}

export function toTokenPath(str: string): string {
  return str.replace(/[^a-zA-Z0-9.]/g, '.').replace(/\.+/g, '.');
}

export function stripUnit(str: string | number): string {
  if (typeof str === 'number') return String(str);
  return String(str).replace(/[a-zA-Z%]/g, '').trim();
}

export function remToPx(remStr: string | number, base = 16): string {
  const val = typeof remStr === 'number' ? remStr : parseFloat(remStr);
  return `${Math.round(val * base)}px`;
}

export function pxToRem(pxStr: string | number, base = 16): string {
  const val = typeof pxStr === 'number' ? pxStr : parseFloat(pxStr);
  return `${(val / base).toFixed(4).replace(/\.?0+$/, '')}rem`;
}

export function formatColor(hex: string, format: 'hex' | 'rgba' | 'hsla' | 'float' = 'hex', alpha = 1): string {
  if (!hex || typeof hex !== 'string') return '';
  const cleanHex = hex.replace('#', '');
  const r = parseInt(cleanHex.slice(0, 2), 16) || 0;
  const g = parseInt(cleanHex.slice(2, 4), 16) || 0;
  const b = parseInt(cleanHex.slice(4, 6), 16) || 0;

  switch (format) {
    case 'rgba':
      return `rgba(${r}, ${g}, ${b}, ${alpha})`;
    case 'float':
      return `r: ${(r / 255).toFixed(3)}, g: ${(g / 255).toFixed(3)}, b: ${(b / 255).toFixed(3)}, a: ${alpha}`;
    case 'hex':
    default:
      return hex.startsWith('#') ? hex : `#${hex}`;
  }
}

// ─── Create Dedicated Handlebars Environment ───────────────────────────

export function createPulsarHandlebars(): typeof Handlebars {
  const hbs = Handlebars.create();

  // 1. String Transform Helpers
  hbs.registerHelper('camelCase', (val) => toCamelCase(String(val ?? '')));
  hbs.registerHelper('kebabCase', (val) => toKebabCase(String(val ?? '')));
  hbs.registerHelper('snakeCase', (val) => toSnakeCase(String(val ?? '')));
  hbs.registerHelper('pascalCase', (val) => toPascalCase(String(val ?? '')));
  hbs.registerHelper('upperCase', (val) => String(val ?? '').toUpperCase());
  hbs.registerHelper('lowerCase', (val) => String(val ?? '').toLowerCase());
  hbs.registerHelper('stripUnit', (val) => stripUnit(val));
  hbs.registerHelper('remToPx', (val, base) => remToPx(val, typeof base === 'number' ? base : 16));
  hbs.registerHelper('pxToRem', (val, base) => pxToRem(val, typeof base === 'number' ? base : 16));
  hbs.registerHelper('formatColor', (hex, fmt, alpha) => formatColor(hex, fmt, typeof alpha === 'number' ? alpha : 1));

  // 2. Token Helpers
  hbs.registerHelper('filterTokens', (tokens: FlatToken[], category: string) => {
    if (!Array.isArray(tokens)) return [];
    return tokens.filter((t) => t.category === category || t.type === category);
  });

  hbs.registerHelper('filter-tokens', (tokens: FlatToken[], category: string) => {
    if (!Array.isArray(tokens)) return [];
    return tokens.filter((t) => t.category === category || t.type === category);
  });

  hbs.registerHelper('groupTokens', (tokens: FlatToken[]) => {
    if (!Array.isArray(tokens)) return {};
    const groups: Record<string, FlatToken[]> = {};
    for (const token of tokens) {
      if (!groups[token.category]) groups[token.category] = [];
      groups[token.category].push(token);
    }
    return groups;
  });

  hbs.registerHelper('group-tokens', (tokens: FlatToken[]) => {
    if (!Array.isArray(tokens)) return {};
    const groups: Record<string, FlatToken[]> = {};
    for (const token of tokens) {
      if (!groups[token.category]) groups[token.category] = [];
      groups[token.category].push(token);
    }
    return groups;
  });

  // 3. Logic & Conditional Helpers
  hbs.registerHelper('eq', (a, b) => a === b);
  hbs.registerHelper('ne', (a, b) => a !== b);
  hbs.registerHelper('not', (a) => !a);
  hbs.registerHelper('and', (...args) => args.slice(0, -1).every(Boolean));
  hbs.registerHelper('or', (...args) => args.slice(0, -1).some(Boolean));

  return hbs;
}

// ─── Legacy Jinja/Liquid to Handlebars Converter ───────────────────────

export function convertLegacyTemplateToHandlebars(templateStr: string): string {
  // If template is already Handlebars (contains {{#each or {{#if), return directly
  if (templateStr.includes('{{#each') || templateStr.includes('{{#if')) {
    return templateStr;
  }

  let converted = templateStr;

  // Convert {% for token in tokens|filter("...") %} -> {{#each (filter-tokens tokens "...") as |token|}}
  converted = converted.replace(
    /\{%\s*for\s+(\w+)\s+in\s+tokens\|filter\("([^"]+)"\)\s*%\}/g,
    '{{#each (filter-tokens tokens "$2") as |$1|}}'
  );

  // Convert {% for token in tokens %} -> {{#each tokens as |token|}}
  converted = converted.replace(
    /\{%\s*for\s+(\w+)\s+in\s+(\w+)\s*%\}/g,
    '{{#each $2 as |$1|}}'
  );

  // Convert {% endfor %} -> {{/each}}
  converted = converted.replace(/\{%\s*endfor\s*%\}/g, '{{/each}}');

  // Convert {% if token.category == "..." %} -> {{#if (eq token.category "...")}}
  converted = converted.replace(
    /\{%\s*if\s+([^=!\s]+)\s*==\s*"([^"]+)"\s*%\}/g,
    '{{#if (eq $1 "$2")}}'
  );

  // Convert {% if not ... %} -> {{#unless ...}}
  converted = converted.replace(/\{%\s*if\s+not\s+([^\s%]+)\s*%\}/g, '{{#unless $1}}');

  // Convert {% if ... %} -> {{#if ...}}
  converted = converted.replace(/\{%\s*if\s+([^\s%]+)\s*%\}/g, '{{#if $1}}');

  // Convert {% else %} -> {{else}}
  converted = converted.replace(/\{%\s*else\s*%\}/g, '{{else}}');

  // Convert {% endif %} -> {{/if}} or {{/unless}}
  converted = converted.replace(/\{%\s*endif\s*%\}/g, '{{/if}}');

  // Convert expression pipe chains: {{ token.path | kebabCase }} -> {{kebabCase token.path}}
  converted = converted.replace(
    /\{\{\s*([^|{}]+?)\s*\|\s*(\w+)\s*\}\}/g,
    '{{$2 $1}}'
  );

  // Convert second pipe chains if present: {{ val | fn1 | fn2 }}
  converted = converted.replace(
    /\{\{\s*(\w+)\s+([^|{}]+?)\s*\|\s*(\w+)\s*\}\}/g,
    '{{$3 ($1 $2)}}'
  );

  return converted;
}

// ─── Pulsar Engine Core Class ──────────────────────────────────────────

export class PulsarEngine {
  private templates: Map<string, PulsarTemplate> = new Map();
  private hbs: typeof Handlebars;

  constructor() {
    this.hbs = createPulsarHandlebars();
    for (const t of BUILTIN_TEMPLATES) {
      this.registerTemplate(t);
    }
  }

  public registerTemplate(template: PulsarTemplate): void {
    this.templates.set(template.id, template);
  }

  public getTemplate(id: string): PulsarTemplate | undefined {
    return this.templates.get(id);
  }

  public listTemplates(): PulsarTemplate[] {
    return Array.from(this.templates.values());
  }

  /**
   * Parse a Supernova exporter package manifest (config.json)
   */
  public parsePackageManifest(jsonContent: string): PulsarPackageManifest {
    const parsed = JSON.parse(jsonContent);
    if (!parsed.id || !parsed.name || !parsed.version) {
      throw new Error('Invalid Supernova package manifest: id, name, and version are required.');
    }
    return {
      id: parsed.id,
      name: parsed.name,
      version: parsed.version,
      description: parsed.description || '',
      author: parsed.author || 'Supernova.io Community',
      writer: parsed.writer || 'supernova.writer.file',
      templates: parsed.templates || [],
      settings: parsed.settings || [],
    };
  }

  /**
   * Execute template by ID with tokens and custom settings
   */
  public execute(templateId: string, tokens: FlatToken[], settings: Record<string, any> = {}): PulsarResult {
    const template = this.templates.get(templateId);
    if (!template) {
      return {
        success: false,
        output: '',
        fileName: 'output.txt',
        errors: [`Template with ID "${templateId}" not found.`],
        warnings: [],
        stats: { tokensProcessed: 0, linesGenerated: 0, executionMs: 0 },
      };
    }

    return this.executeRaw(template.template, tokens, settings, template.outputFileName);
  }

  /**
   * Execute raw template string (Handlebars or Liquid format)
   */
  public executeRaw(
    rawTemplateStr: string,
    tokens: FlatToken[],
    settings: Record<string, any> = {},
    outputFileName = 'output.txt'
  ): PulsarResult {
    const start = performance.now();
    const errors: string[] = [];
    const warnings: string[] = [];

    try {
      // Auto-translate Liquid/Jinja syntax to Handlebars if needed
      const hbsTemplateStr = convertLegacyTemplateToHandlebars(rawTemplateStr);

      const compiled = this.hbs.compile(hbsTemplateStr, { noEscape: true });

      // Built-in settings defaults
      const mergedSettings = { ...settings };
      const contextData = {
        tokens,
        settings: mergedSettings,
        meta: {
          designSystemName: 'Nova Design System',
          version: '1.0.0',
          totalTokens: tokens.length,
          timestamp: new Date().toISOString(),
        },
      };

      const output = compiled(contextData);
      const lines = output.split('\n').length;

      return {
        success: true,
        output,
        fileName: outputFileName,
        errors,
        warnings,
        stats: {
          tokensProcessed: tokens.length,
          linesGenerated: lines,
          executionMs: Math.round(performance.now() - start),
        },
      };
    } catch (err: any) {
      errors.push(err.message);
      return {
        success: false,
        output: '',
        fileName: outputFileName,
        errors,
        warnings,
        stats: {
          tokensProcessed: 0,
          linesGenerated: 0,
          executionMs: Math.round(performance.now() - start),
        },
      };
    }
  }
}

// ─── Built-in Supernova-Grade Exporter Templates ───────────────────────

export const BUILTIN_TEMPLATES: PulsarTemplate[] = [
  {
    id: 'scss-variables',
    name: 'SCSS Variables',
    description: 'Generate SCSS variables with category-based partials',
    version: '1.0.0',
    author: 'Nexus Design OS',
    outputFileName: '_tokens.scss',
    settings: [{ key: 'prefix', label: 'Variable Prefix', type: 'string', default: 'nexus' }],
    template: `// Design Tokens — SCSS Variables
{{#each (filter-tokens tokens "color") as |token|}}
$nexus-{{kebabCase token.path}}: {{token.rawValue}};
{{/each}}
{{#each (filter-tokens tokens "spacing") as |token|}}
$nexus-{{kebabCase token.path}}: {{token.rawValue}};
{{/each}}`,
  },
  {
    id: 'flutter-theme',
    name: 'Flutter ThemeData',
    description: 'Generate Flutter/Dart ThemeData class from tokens',
    version: '1.0.0',
    author: 'Nexus Design OS',
    outputFileName: 'design_tokens.dart',
    settings: [{ key: 'className', label: 'Class Name', type: 'string', default: 'AppTokens' }],
    template: `// Generated by Nexus Design OS Pulsar Engine
import 'package:flutter/material.dart';

class AppTokens {
  AppTokens._();

{{#each (filter-tokens tokens "color") as |token|}}
{{#unless token.isAlias}}
  static const Color {{camelCase token.path}} = Color(0xFF{{token.rawValue}});
{{/unless}}
{{/each}}

{{#each (filter-tokens tokens "spacing") as |token|}}
  static const double {{camelCase token.path}} = {{stripUnit token.rawValue}};
{{/each}}
}`,
  },
  {
    id: 'android-xml',
    name: 'Android XML Resources',
    description: 'Generate Android colors.xml and dimens.xml resources',
    version: '1.0.0',
    author: 'Nexus Design OS',
    outputFileName: 'tokens.xml',
    template: `<?xml version="1.0" encoding="utf-8"?>
<resources>
{{#each (filter-tokens tokens "color") as |token|}}
{{#unless token.isAlias}}
    <color name="{{snakeCase token.path}}">{{token.rawValue}}</color>
{{/unless}}
{{/each}}
{{#each (filter-tokens tokens "spacing") as |token|}}
    <dimen name="{{snakeCase token.path}}">{{token.rawValue}}</dimen>
{{/each}}
</resources>`,
  },
  {
    id: 'css-modules',
    name: 'CSS Modules',
    description: 'Generate CSS Modules with typed exports',
    version: '1.0.0',
    author: 'Nexus Design OS',
    outputFileName: 'tokens.module.css',
    template: `:root {
{{#each tokens as |token|}}
  --{{kebabCase token.path}}: {{token.resolvedValue}};
{{/each}}
}
{{#each (filter-tokens tokens "color") as |token|}}
.bg-{{kebabCase token.path}} { background-color: var(--{{kebabCase token.path}}); }
{{/each}}`,
  },
  {
    id: 'figma-tokens-json',
    name: 'Figma Tokens Studio JSON',
    description: 'Export tokens in Tokens Studio format for round-trip sync',
    version: '1.0.0',
    author: 'Nexus Design OS',
    outputFileName: 'tokens.json',
    template: `{
{{#each tokens as |token|}}
  "{{token.path}}": {
    "$value": "{{token.rawValue}}",
    "$type": "{{token.type}}"
  }{{#unless @last}},{{/unless}}
{{/each}}
}`,
  },
  {
    id: 'style-dictionary',
    name: 'Style Dictionary Config',
    description: 'Generate Style Dictionary compatible JSON config',
    version: '1.0.0',
    author: 'Nexus Design OS',
    outputFileName: 'tokens.style-dictionary.json',
    template: `{
{{#each tokens as |token|}}
  "{{token.path}}": {
    "value": "{{token.rawValue}}",
    "type": "{{token.type}}"
  }{{#unless @last}},{{/unless}}
{{/each}}
}`,
  },
];

// ─── Singleton ─────────────────────────────────────────────────────────

let engineInstance: PulsarEngine | null = null;

export function getPulsarEngine(): PulsarEngine {
  if (!engineInstance) engineInstance = new PulsarEngine();
  return engineInstance;
}
