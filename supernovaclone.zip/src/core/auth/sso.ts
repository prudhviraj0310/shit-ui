/**
 * SSO / OAuth / SAML Authentication Providers
 * 
 * Multi-provider enterprise authentication:
 * - OAuth 2.0 (Google, GitHub, GitLab, Microsoft Entra ID)
 * - SAML 2.0 (Okta, OneLogin, Azure AD, generic)
 * - Magic link (passwordless email)
 * - API key (machine-to-machine)
 */

export type SSOProvider = 'google' | 'github' | 'gitlab' | 'microsoft' | 'okta' | 'saml' | 'magic_link';

export interface SSOConfig {
  provider: SSOProvider;
  clientId: string;
  clientSecret: string;
  redirectUri: string;
  scopes?: string[];
  // SAML specific
  samlEntryPoint?: string;
  samlIssuer?: string;
  samlCert?: string;
  samlCallbackUrl?: string;
}

export interface SSOSession {
  id: string;
  userId: string;
  provider: SSOProvider;
  email: string;
  displayName: string;
  avatarUrl?: string;
  accessToken: string;
  refreshToken?: string;
  expiresAt: number;
  workspaceId: string;
  role: string;
  metadata: Record<string, unknown>;
}

export interface SSOProviderMetadata {
  provider: SSOProvider;
  displayName: string;
  icon: string;
  authUrl: string;
  tokenUrl: string;
  userInfoUrl: string;
  scopes: string[];
}

// ─── Provider Registry ─────────────────────────────────────────────────

export const PROVIDER_METADATA: Record<string, SSOProviderMetadata> = {
  google: {
    provider: 'google',
    displayName: 'Google',
    icon: 'google',
    authUrl: 'https://accounts.google.com/o/oauth2/v2/auth',
    tokenUrl: 'https://oauth2.googleapis.com/token',
    userInfoUrl: 'https://www.googleapis.com/oauth2/v3/userinfo',
    scopes: ['openid', 'email', 'profile'],
  },
  github: {
    provider: 'github',
    displayName: 'GitHub',
    icon: 'github',
    authUrl: 'https://github.com/login/oauth/authorize',
    tokenUrl: 'https://github.com/login/oauth/access_token',
    userInfoUrl: 'https://api.github.com/user',
    scopes: ['read:user', 'user:email'],
  },
  gitlab: {
    provider: 'gitlab',
    displayName: 'GitLab',
    icon: 'gitlab',
    authUrl: 'https://gitlab.com/oauth/authorize',
    tokenUrl: 'https://gitlab.com/oauth/token',
    userInfoUrl: 'https://gitlab.com/api/v4/user',
    scopes: ['read_user', 'openid', 'email'],
  },
  microsoft: {
    provider: 'microsoft',
    displayName: 'Microsoft',
    icon: 'microsoft',
    authUrl: 'https://login.microsoftonline.com/common/oauth2/v2.0/authorize',
    tokenUrl: 'https://login.microsoftonline.com/common/oauth2/v2.0/token',
    userInfoUrl: 'https://graph.microsoft.com/v1.0/me',
    scopes: ['openid', 'email', 'profile', 'User.Read'],
  },
};

// ─── OAuth 2.0 Flow ────────────────────────────────────────────────────

export class OAuthProvider {
  private config: SSOConfig;
  private meta: SSOProviderMetadata;

  constructor(config: SSOConfig) {
    this.config = config;
    this.meta = PROVIDER_METADATA[config.provider] || PROVIDER_METADATA.google;
  }

  /** Step 1: Generate authorization URL */
  getAuthorizationUrl(state: string): string {
    const params = new URLSearchParams({
      client_id: this.config.clientId,
      redirect_uri: this.config.redirectUri,
      response_type: 'code',
      scope: (this.config.scopes || this.meta.scopes).join(' '),
      state,
      access_type: 'offline',
      prompt: 'consent',
    });
    return `${this.meta.authUrl}?${params.toString()}`;
  }

  /** Step 2: Exchange authorization code for tokens */
  async exchangeCode(code: string): Promise<{ accessToken: string; refreshToken?: string; expiresIn: number }> {
    const body = new URLSearchParams({
      client_id: this.config.clientId,
      client_secret: this.config.clientSecret,
      code,
      redirect_uri: this.config.redirectUri,
      grant_type: 'authorization_code',
    });

    const headers: Record<string, string> = { 'Content-Type': 'application/x-www-form-urlencoded' };
    if (this.config.provider === 'github') headers['Accept'] = 'application/json';

    const response = await fetch(this.meta.tokenUrl, { method: 'POST', headers, body: body.toString() });
    if (!response.ok) throw new Error(`Token exchange failed: ${response.status}`);

    const data = await response.json();
    return {
      accessToken: data.access_token,
      refreshToken: data.refresh_token,
      expiresIn: data.expires_in || 3600,
    };
  }

  /** Step 3: Get user profile from provider */
  async getUserInfo(accessToken: string): Promise<{ email: string; name: string; avatar?: string; providerId: string }> {
    const headers: Record<string, string> = { 'Authorization': `Bearer ${accessToken}` };
    if (this.config.provider === 'github') headers['Accept'] = 'application/vnd.github+json';

    const response = await fetch(this.meta.userInfoUrl, { headers });
    if (!response.ok) throw new Error(`User info fetch failed: ${response.status}`);

    const data = await response.json();

    switch (this.config.provider) {
      case 'github':
        return { email: data.email || `${data.login}@github.com`, name: data.name || data.login, avatar: data.avatar_url, providerId: String(data.id) };
      case 'google':
        return { email: data.email, name: data.name, avatar: data.picture, providerId: data.sub };
      case 'microsoft':
        return { email: data.mail || data.userPrincipalName, name: data.displayName, providerId: data.id };
      case 'gitlab':
        return { email: data.email, name: data.name, avatar: data.avatar_url, providerId: String(data.id) };
      default:
        return { email: data.email, name: data.name || data.display_name, providerId: data.id || data.sub };
    }
  }
}

// ─── SAML 2.0 ──────────────────────────────────────────────────────────

export class SAMLProvider {
  private config: SSOConfig;

  constructor(config: SSOConfig) {
    this.config = config;
  }

  /** Generate SAML AuthnRequest URL */
  getLoginUrl(relayState: string): string {
    const samlRequest = Buffer.from(`
      <samlp:AuthnRequest
        xmlns:samlp="urn:oasis:names:tc:SAML:2.0:protocol"
        ID="_${Date.now()}"
        Version="2.0"
        IssueInstant="${new Date().toISOString()}"
        AssertionConsumerServiceURL="${this.config.samlCallbackUrl}"
        Destination="${this.config.samlEntryPoint}">
        <saml:Issuer xmlns:saml="urn:oasis:names:tc:SAML:2.0:assertion">${this.config.samlIssuer}</saml:Issuer>
      </samlp:AuthnRequest>
    `.trim()).toString('base64');

    const params = new URLSearchParams({ SAMLRequest: samlRequest, RelayState: relayState });
    return `${this.config.samlEntryPoint}?${params.toString()}`;
  }

  /** Parse SAML Response (simplified — production should use a full SAML library) */
  async parseResponse(samlResponse: string): Promise<{ email: string; name: string; nameId: string; attributes: Record<string, string> }> {
    const decoded = Buffer.from(samlResponse, 'base64').toString('utf-8');
    
    // Extract basic fields from SAML XML (simplified parser)
    const emailMatch = decoded.match(/<saml:NameID[^>]*>([^<]+)<\/saml:NameID>/);
    const nameMatch = decoded.match(/Name="displayName"[^>]*><saml:AttributeValue[^>]*>([^<]+)/);
    
    return {
      email: emailMatch?.[1] || '',
      name: nameMatch?.[1] || emailMatch?.[1] || '',
      nameId: emailMatch?.[1] || '',
      attributes: {},
    };
  }
}

// ─── Magic Link (Passwordless) ─────────────────────────────────────────

export class MagicLinkProvider {
  private secret: string;

  constructor(secret: string) {
    this.secret = secret;
  }

  /** Generate a magic link token */
  generateToken(email: string, expiresInMinutes = 15): { token: string; expiresAt: number } {
    const expiresAt = Date.now() + expiresInMinutes * 60 * 1000;
    const payload = JSON.stringify({ email, expiresAt, nonce: Math.random().toString(36).slice(2) });
    const token = Buffer.from(payload).toString('base64url');
    return { token, expiresAt };
  }

  /** Verify a magic link token */
  verifyToken(token: string): { valid: boolean; email?: string; error?: string } {
    try {
      const payload = JSON.parse(Buffer.from(token, 'base64url').toString('utf-8'));
      if (Date.now() > payload.expiresAt) return { valid: false, error: 'Token expired' };
      return { valid: true, email: payload.email };
    } catch {
      return { valid: false, error: 'Invalid token' };
    }
  }
}

// ─── Session Manager ───────────────────────────────────────────────────

export class SessionManager {
  private sessions: Map<string, SSOSession> = new Map();

  createSession(params: Omit<SSOSession, 'id'>): SSOSession {
    const session: SSOSession = {
      ...params,
      id: `sess-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`,
    };
    this.sessions.set(session.id, session);
    return session;
  }

  getSession(sessionId: string): SSOSession | null {
    const session = this.sessions.get(sessionId);
    if (!session) return null;
    if (Date.now() > session.expiresAt) {
      this.sessions.delete(sessionId);
      return null;
    }
    return session;
  }

  revokeSession(sessionId: string): void {
    this.sessions.delete(sessionId);
  }

  listActiveSessions(userId?: string): SSOSession[] {
    const now = Date.now();
    const active: SSOSession[] = [];
    for (const [id, session] of this.sessions.entries()) {
      if (now > session.expiresAt) { this.sessions.delete(id); continue; }
      if (!userId || session.userId === userId) active.push(session);
    }
    return active;
  }
}

let sessionManagerInstance: SessionManager | null = null;
export function getSessionManager(): SessionManager {
  if (!sessionManagerInstance) sessionManagerInstance = new SessionManager();
  return sessionManagerInstance;
}
