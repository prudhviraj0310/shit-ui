import { getDb } from '@/db/index';
import { docComments, docPages } from '@/db/schema';
import { eq, desc } from 'drizzle-orm';

export interface CommentThreadItem {
  id: string;
  targetType: 'token' | 'component' | 'doc' | 'general';
  targetId: string;
  targetTitle: string;
  author: string;
  authorAvatar?: string;
  body: string;
  status: 'open' | 'resolved';
  createdAt: Date | string;
  updatedAt: Date | string;
  replies: Array<{
    id: string;
    author: string;
    body: string;
    createdAt: Date | string;
  }>;
}

const threadRepliesMap = new Map<string, Array<{ id: string; author: string; body: string; createdAt: Date | string }>>();

export class CommentsManager {
  private db: any;

  constructor(db: any) {
    this.db = db;
  }

  public async listComments(targetType?: string, targetId?: string): Promise<CommentThreadItem[]> {
    const rows = await this.db
      .select()
      .from(docComments)
      .orderBy(desc(docComments.createdAt));

    const threads: CommentThreadItem[] = rows.map((r: any) => {
      const anchor = (r.anchor as any) || {};
      const tType = anchor.targetType || 'general';
      const tId = anchor.targetId || r.pageId || 'general';
      const tTitle = anchor.targetTitle || 'General Discussion';
      const author = anchor.author || r.authorUserId || 'Team Member';
      const replies = threadRepliesMap.get(r.id) || [];

      return {
        id: r.id,
        targetType: tType,
        targetId: tId,
        targetTitle: tTitle,
        author,
        body: r.body,
        status: (r.status as 'open' | 'resolved') || 'open',
        createdAt: r.createdAt,
        updatedAt: r.updatedAt,
        replies,
      };
    });

    if (targetType) {
      return threads.filter(t => t.targetType === targetType && (!targetId || t.targetId === targetId));
    }

    return threads;
  }

  public async addComment(params: {
    targetType: 'token' | 'component' | 'doc' | 'general';
    targetId: string;
    targetTitle: string;
    author: string;
    body: string;
  }): Promise<CommentThreadItem> {
    const id = `cmt-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 6)}`;
    
    // Resolve a valid pageId to satisfy foreign key constraint
    let validPageId = 'doc-welcome';
    if (params.targetType === 'doc' && params.targetId) {
      validPageId = params.targetId;
    } else {
      const pages = await this.db.select({ id: docPages.id }).from(docPages).limit(1);
      if (pages.length > 0) validPageId = pages[0].id;
    }

    const anchor = {
      targetType: params.targetType,
      targetId: params.targetId,
      targetTitle: params.targetTitle,
      author: params.author || 'Design Lead',
    };

    const newComment = {
      id,
      pageId: validPageId,
      authorUserId: null,
      body: params.body,
      status: 'open',
      anchor,
      createdAt: new Date(),
      updatedAt: new Date(),
    };

    await this.db.insert(docComments).values(newComment);
    threadRepliesMap.set(id, []);

    return {
      id,
      targetType: params.targetType,
      targetId: params.targetId,
      targetTitle: params.targetTitle,
      author: params.author,
      body: params.body,
      status: 'open',
      createdAt: newComment.createdAt,
      updatedAt: newComment.updatedAt,
      replies: [],
    };
  }

  public async addReply(commentId: string, author: string, body: string): Promise<any> {
    const replies = threadRepliesMap.get(commentId) || [];
    const newReply = {
      id: `rep-${Date.now().toString(36)}`,
      author: author || 'Collaborator',
      body,
      createdAt: new Date(),
    };
    replies.push(newReply);
    threadRepliesMap.set(commentId, replies);

    return newReply;
  }

  public async toggleResolve(commentId: string, status: 'open' | 'resolved'): Promise<any> {
    await this.db
      .update(docComments)
      .set({ status, updatedAt: new Date() })
      .where(eq(docComments.id, commentId));

    return { success: true, commentId, status };
  }
}
