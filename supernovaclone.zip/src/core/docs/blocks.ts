import {
  DocBlock,
  DocRenderContext,
  HeadingDocBlock,
  ParagraphDocBlock,
  CodeDocBlock,
  CalloutDocBlock,
  TokenListDocBlock,
  TokenChipDocBlock,
  FigmaEmbedDocBlock,
  ComponentPreviewDocBlock,
  ComponentHealthMatrixDocBlock,
  AssetGridDocBlock,
  TableDocBlock,
  DividerDocBlock,
  TabsDocBlock,
} from './types';

/**
 * Validates a list of documentation blocks.
 */
export function validateDocBlocks(blocks: DocBlock[]): { valid: boolean; errors: string[] } {
  const errors: string[] = [];

  if (!Array.isArray(blocks)) {
    return { valid: false, errors: ['Blocks must be an array.'] };
  }

  blocks.forEach((block, idx) => {
    if (!block.id) {
      errors.push(`Block at index ${idx} is missing a unique 'id'.`);
    }

    switch (block.type) {
      case 'heading':
        if (!block.text || typeof block.text !== 'string') {
          errors.push(`Heading block ${block.id || idx} requires non-empty 'text'.`);
        }
        if (![1, 2, 3, 4, 5, 6].includes(block.level)) {
          errors.push(`Heading block ${block.id || idx} level must be between 1 and 6.`);
        }
        break;

      case 'paragraph':
        if (typeof block.text !== 'string') {
          errors.push(`Paragraph block ${block.id || idx} requires a 'text' string.`);
        }
        break;

      case 'code':
        if (typeof block.code !== 'string') {
          errors.push(`Code block ${block.id || idx} requires a 'code' string.`);
        }
        break;

      case 'callout':
        if (!['info', 'warning', 'success', 'error', 'danger'].includes(block.calloutType)) {
          errors.push(`Callout block ${block.id || idx} has invalid calloutType "${block.calloutType}".`);
        }
        break;

      case 'do_dont':
        if (!block.doItem || !block.dontItem) {
          errors.push(`DoDont block ${block.id || idx} requires both 'doItem' and 'dontItem'.`);
        }
        break;

      case 'interactive_playground':
        if (!block.componentName) {
          errors.push(`InteractivePlayground block ${block.id || idx} requires a 'componentName'.`);
        }
        break;

      case 'token_table':
        break;

      case 'token_chip':
        if (!block.tokenPath) {
          errors.push(`TokenChip block ${block.id || idx} requires 'tokenPath'.`);
        }
        break;

      case 'figma_embed':
        if (!block.url) {
          errors.push(`FigmaEmbed block ${block.id || idx} requires a valid 'url'.`);
        }
        break;

      case 'table':
        if (!Array.isArray(block.headers) || !Array.isArray(block.rows)) {
          errors.push(`Table block ${block.id || idx} requires 'headers' and 'rows' arrays.`);
        }
        break;

      case 'tabs':
        if (!Array.isArray(block.tabs) || block.tabs.length === 0) {
          errors.push(`Tabs block ${block.id || idx} requires a non-empty 'tabs' array.`);
        } else {
          for (const tab of block.tabs) {
            if (!tab.title) errors.push(`Tabs block ${block.id || idx} has a tab without a title.`);
            const childValidation = validateDocBlocks(tab.blocks || []);
            if (!childValidation.valid) {
              errors.push(...childValidation.errors);
            }
          }
        }
        break;

      case 'prompt_template':
        if (!block.prompt || typeof block.prompt !== 'string') {
          errors.push(`PromptTemplate block ${block.id || idx} requires a 'prompt' string.`);
        }
        break;

      case 'props_table':
        if (!Array.isArray(block.props)) {
          errors.push(`PropsTable block ${block.id || idx} requires a 'props' array.`);
        }
        break;

      case 'storybook_embed':
        if (!block.url) {
          errors.push(`StorybookEmbed block ${block.id || idx} requires a valid 'url'.`);
        }
        break;

      case 'version_diff':
        if (!Array.isArray(block.changes)) {
          errors.push(`VersionDiff block ${block.id || idx} requires a 'changes' array.`);
        }
        break;
    }
  });

  return { valid: errors.length === 0, errors };
}

/**
 * Converts markdown text into structured documentation blocks AST.
 */
export function markdownToBlocks(markdown: string): DocBlock[] {
  if (!markdown || markdown.trim() === '') return [];

  const lines = markdown.split(/\r?\n/);
  const blocks: DocBlock[] = [];
  let currentParagraphLines: string[] = [];
  let inCodeBlock = false;
  let codeLang = '';
  let codeLines: string[] = [];
  let codeTitle = '';
  let inTable = false;
  let tableHeaders: string[] = [];
  let tableRows: string[][] = [];

  const flushParagraph = () => {
    if (currentParagraphLines.length > 0) {
      const text = currentParagraphLines.join('\n').trim();
      if (text) {
        // Check for special embedded directives like ::token[path] or ::token-list
        if (text.startsWith('::token-list')) {
          const catMatch = text.match(/category=["']?([a-zA-Z0-9_.-]+)["']?/);
          const groupMatch = text.match(/group=["']?([a-zA-Z0-9_./-]+)["']?/);
          blocks.push({
            id: `blk-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
            type: 'token_list',
            category: catMatch ? catMatch[1] : undefined,
            groupPath: groupMatch ? groupMatch[1] : undefined,
            showValues: true,
          });
        } else if (text.startsWith('::figma')) {
          const urlMatch = text.match(/url=["']?([^"'\s]+)["']?/);
          blocks.push({
            id: `blk-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
            type: 'figma_embed',
            url: urlMatch ? urlMatch[1] : '',
          });
        } else {
          blocks.push({
            id: `blk-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
            type: 'paragraph',
            text,
          });
        }
      }
      currentParagraphLines = [];
    }
  };

  const flushTable = () => {
    if (inTable && tableHeaders.length > 0) {
      blocks.push({
        id: `blk-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
        type: 'table',
        headers: tableHeaders,
        rows: tableRows,
      });
      inTable = false;
      tableHeaders = [];
      tableRows = [];
    }
  };

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];

    // 1. Code blocks fence
    if (line.trim().startsWith('```')) {
      if (!inCodeBlock) {
        flushParagraph();
        flushTable();
        inCodeBlock = true;
        const tag = line.trim().slice(3).trim();
        const parts = tag.split(':');
        codeLang = parts[0] || 'text';
        codeTitle = parts[1] || '';
        codeLines = [];
      } else {
        inCodeBlock = false;
        blocks.push({
          id: `blk-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
          type: 'code',
          language: codeLang,
          code: codeLines.join('\n'),
          title: codeTitle || undefined,
        });
      }
      continue;
    }

    if (inCodeBlock) {
      codeLines.push(line);
      continue;
    }

    // 2. Horizontal divider
    if (/^(---|___|\*\*\*)$/.test(line.trim())) {
      flushParagraph();
      flushTable();
      blocks.push({
        id: `blk-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
        type: 'divider',
      });
      continue;
    }

    // 3. Headings
    const headingMatch = line.match(/^(#{1,6})\s+(.*)$/);
    if (headingMatch) {
      flushParagraph();
      flushTable();
      blocks.push({
        id: `blk-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
        type: 'heading',
        level: headingMatch[1].length as any,
        text: headingMatch[2].trim(),
      });
      continue;
    }

    // 4. Callout / Alert (> [!NOTE] or > [!WARNING])
    const calloutMatch = line.match(/^>\s*\[!(NOTE|TIP|IMPORTANT|WARNING|CAUTION)\]\s*(.*)$/i);
    if (calloutMatch) {
      flushParagraph();
      flushTable();
      const rawType = calloutMatch[1].toUpperCase();
      let calloutType: 'info' | 'warning' | 'success' | 'error' = 'info';
      if (rawType === 'WARNING' || rawType === 'CAUTION') calloutType = 'warning';
      else if (rawType === 'TIP') calloutType = 'success';

      const title = calloutMatch[2].trim() || rawType;
      // Slurp remaining lines in blockquote
      const contentLines: string[] = [];
      while (i + 1 < lines.length && lines[i + 1].trim().startsWith('>')) {
        i++;
        contentLines.push(lines[i].replace(/^>\s?/, ''));
      }

      blocks.push({
        id: `blk-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
        type: 'callout',
        calloutType,
        title,
        text: contentLines.join('\n').trim(),
      });
      continue;
    }

    // 5. Tables
    if (line.trim().startsWith('|') && line.trim().endsWith('|')) {
      flushParagraph();
      const cells = line
        .split('|')
        .slice(1, -1)
        .map((c) => c.trim());

      // If next line is separator, this is header
      if (!inTable) {
        if (i + 1 < lines.length && /^\|\s*[-:]+/.test(lines[i + 1].trim())) {
          inTable = true;
          tableHeaders = cells;
          i++; // skip separator
          tableRows = [];
          continue;
        }
      } else {
        tableRows.push(cells);
        continue;
      }
    } else if (inTable) {
      flushTable();
    }

    // 6. Blank line flushes paragraph
    if (line.trim() === '') {
      flushParagraph();
      flushTable();
      continue;
    }

    // 7. Regular paragraph line
    currentParagraphLines.push(line);
  }

  flushParagraph();
  flushTable();

  return blocks;
}

/**
 * Converts structured documentation blocks back to markdown.
 */
export function blocksToMarkdown(blocks: DocBlock[]): string {
  if (!Array.isArray(blocks) || blocks.length === 0) return '';

  const chunks: string[] = [];

  for (const block of blocks) {
    switch (block.type) {
      case 'heading': {
        const hashes = '#'.repeat(block.level);
        chunks.push(`${hashes} ${block.text}`);
        break;
      }

      case 'paragraph': {
        chunks.push(block.text);
        break;
      }

      case 'code': {
        const header = block.title ? `${block.language}:${block.title}` : block.language;
        chunks.push(`\`\`\`${header}\n${block.code}\n\`\`\``);
        break;
      }

      case 'callout': {
        const tag = block.calloutType === 'warning' ? 'WARNING' : block.calloutType === 'success' ? 'TIP' : 'NOTE';
        const titlePart = block.title ? ` ${block.title}` : '';
        const bodyLines = block.text.split('\n').map((l) => `> ${l}`).join('\n');
        chunks.push(`> [!${tag}]${titlePart}\n${bodyLines}`);
        break;
      }

      case 'token_list': {
        const cat = block.category ? ` category="${block.category}"` : '';
        const grp = block.groupPath ? ` group="${block.groupPath}"` : '';
        chunks.push(`::token-list{${cat}${grp}}`);
        break;
      }

      case 'token_chip': {
        chunks.push(`\`$${block.tokenPath}\``);
        break;
      }

      case 'figma_embed': {
        chunks.push(`::figma{url="${block.url}"}`);
        break;
      }

      case 'table': {
        const headerLine = `| ${block.headers.join(' | ')} |`;
        const sepLine = `| ${block.headers.map(() => '---').join(' | ')} |`;
        const rowLines = block.rows.map((r) => `| ${r.join(' | ')} |`);
        chunks.push([headerLine, sepLine, ...rowLines].join('\n'));
        break;
      }

      case 'divider': {
        chunks.push('---');
        break;
      }

      case 'tabs': {
        const tabTexts: string[] = [];
        for (const tab of block.tabs) {
          tabTexts.push(`### Tab: ${tab.title}\n\n${blocksToMarkdown(tab.blocks)}`);
        }
        chunks.push(tabTexts.join('\n\n'));
        break;
      }

      default:
        break;
    }
  }

  return chunks.join('\n\n');
}

/**
 * Renders structured documentation blocks to HTML for living documentation portals.
 */
export function renderDocBlocksToHtml(blocks: DocBlock[], context?: DocRenderContext): string {
  if (!Array.isArray(blocks) || blocks.length === 0) return '';

  const tokenMap = new Map<string, any>(
    (context?.tokens || []).map((t) => [t.path, t])
  );

  const htmlParts: string[] = [];

  for (const block of blocks) {
    switch (block.type) {
      case 'heading': {
        htmlParts.push(`<h${block.level} class="doc-heading doc-h${block.level}">${escapeHtml(block.text)}</h${block.level}>`);
        break;
      }

      case 'paragraph': {
        htmlParts.push(`<p class="doc-paragraph">${escapeHtml(block.text)}</p>`);
        break;
      }

      case 'code': {
        const titleHtml = block.title ? `<div class="doc-code-title">${escapeHtml(block.title)}</div>` : '';
        htmlParts.push(
          `<div class="doc-code-block">${titleHtml}<pre><code class="language-${block.language}">${escapeHtml(block.code)}</code></pre></div>`
        );
        break;
      }

      case 'callout': {
        const titleHtml = block.title ? `<strong class="doc-callout-title">${escapeHtml(block.title)}</strong>` : '';
        htmlParts.push(
          `<div class="doc-callout doc-callout-${block.calloutType}">${titleHtml}<p>${escapeHtml(block.text)}</p></div>`
        );
        break;
      }

      case 'token_chip': {
        const tok = tokenMap.get(block.tokenPath);
        const swatch = tok ? `<span class="doc-token-swatch" style="background:${tok.resolvedValue};"></span>` : '';
        const val = tok ? `<span class="doc-token-val">${escapeHtml(tok.resolvedValue)}</span>` : '';
        htmlParts.push(
          `<span class="doc-token-chip">${swatch}<code class="doc-token-name">${escapeHtml(block.tokenPath)}</code>${val}</span>`
        );
        break;
      }

      case 'token_list': {
        const matchingTokens = (context?.tokens || []).filter(
          (t) => (!block.category || t.type === block.category)
        );
        const listItems = matchingTokens
          .map(
            (t) =>
              `<div class="doc-token-list-item"><span class="doc-token-swatch" style="background:${t.resolvedValue};"></span><code>${escapeHtml(t.path)}</code><span>${escapeHtml(t.resolvedValue)}</span></div>`
          )
          .join('');
        htmlParts.push(`<div class="doc-token-list">${listItems}</div>`);
        break;
      }

      case 'figma_embed': {
        htmlParts.push(
          `<div class="doc-figma-embed"><iframe src="${escapeHtml(block.url)}" width="100%" height="${block.height || 450}" allowfullscreen></iframe></div>`
        );
        break;
      }

      case 'table': {
        const ths = block.headers.map((h) => `<th>${escapeHtml(h)}</th>`).join('');
        const trs = block.rows
          .map((r) => `<tr>${r.map((c) => `<td>${escapeHtml(c)}</td>`).join('')}</tr>`)
          .join('');
        htmlParts.push(`<table class="doc-table"><thead><tr>${ths}</tr></thead><tbody>${trs}</tbody></table>`);
        break;
      }

      case 'divider': {
        htmlParts.push('<hr class="doc-divider" />');
        break;
      }

      case 'do_dont': {
        const doItem = block.doItem;
        const dontItem = block.dontItem;
        const doCodeHtml = doItem.code ? `<pre class="doc-dodont-code"><code>${escapeHtml(doItem.code)}</code></pre>` : '';
        const dontCodeHtml = dontItem.code ? `<pre class="doc-dodont-code"><code>${escapeHtml(dontItem.code)}</code></pre>` : '';
        const doSwatchHtml = doItem.tokenValue ? `<div class="doc-dodont-swatch" style="background:${escapeHtml(doItem.tokenValue)}"></div>` : '';
        const dontSwatchHtml = dontItem.tokenValue ? `<div class="doc-dodont-swatch" style="background:${escapeHtml(dontItem.tokenValue)}"></div>` : '';
        const doMediaHtml = doItem.mediaUrl ? `<img src="${escapeHtml(doItem.mediaUrl)}" alt="Do example" class="doc-dodont-media" />` : '';
        const dontMediaHtml = dontItem.mediaUrl ? `<img src="${escapeHtml(dontItem.mediaUrl)}" alt="Don't example" class="doc-dodont-media" />` : '';

        htmlParts.push(`
<div class="doc-dodont-container">
  ${block.title ? `<h4 class="doc-dodont-heading">${escapeHtml(block.title)}</h4>` : ''}
  <div class="doc-dodont-grid">
    <div class="doc-dodont-card doc-do">
      <div class="doc-dodont-badge do"><span class="doc-icon">✓</span> DO</div>
      <div class="doc-dodont-content">
        ${doMediaHtml}${doSwatchHtml}${doCodeHtml}
        <div class="doc-dodont-rationale">
          ${doItem.title ? `<strong>${escapeHtml(doItem.title)}</strong>` : ''}
          <p>${escapeHtml(doItem.text)}</p>
        </div>
      </div>
    </div>
    <div class="doc-dodont-card doc-dont">
      <div class="doc-dodont-badge dont"><span class="doc-icon">✕</span> DON'T</div>
      <div class="doc-dodont-content">
        ${dontMediaHtml}${dontSwatchHtml}${dontCodeHtml}
        <div class="doc-dodont-rationale">
          ${dontItem.title ? `<strong>${escapeHtml(dontItem.title)}</strong>` : ''}
          <p>${escapeHtml(dontItem.text)}</p>
        </div>
      </div>
    </div>
  </div>
</div>`);
        break;
      }

      case 'interactive_playground': {
        const componentName = block.componentName || 'Component';
        const defaultProps = block.defaultProps || {};
        const propsJson = escapeHtml(JSON.stringify(defaultProps));
        htmlParts.push(`
<div class="doc-interactive-playground" data-component="${escapeHtml(componentName)}" data-props="${propsJson}">
  <div class="doc-playground-header">
    <div class="doc-playground-title">Interactive Playground: ${escapeHtml(componentName)}</div>
    <div class="doc-playground-badge">React &bull; CSF3</div>
  </div>
  <div class="doc-playground-canvas">
    <div class="doc-canvas-preview">
      <button class="doc-live-btn" style="padding: 10px 20px; border-radius: 8px; font-weight: 600; background: linear-gradient(135deg, #06b6d4, #0284c7); color: white; border: none; cursor: pointer;">
        ${escapeHtml(defaultProps.label || defaultProps.children || componentName)}
      </button>
    </div>
  </div>
  <div class="doc-playground-controls">
    <div class="doc-controls-header">Dynamic Prop Controls</div>
    <div class="doc-controls-grid">
      <div class="doc-prop-row"><label>variant:</label> <code>primary</code></div>
      <div class="doc-prop-row"><label>size:</label> <code>medium</code></div>
      <div class="doc-prop-row"><label>disabled:</label> <code>false</code></div>
    </div>
  </div>
</div>`);
        break;
      }

      case 'token_table': {
        const matchingTokens = (context?.tokens || []).filter(
          (t) => (!block.category || t.type === block.category)
        );
        const rowsHtml = matchingTokens
          .map((t) => {
            const isColor = t.type === 'color' || t.resolvedValue.startsWith('#') || t.resolvedValue.startsWith('rgb');
            const swatch = isColor ? `<span class="doc-swatch-preview" style="background:${t.resolvedValue};"></span>` : '';
            return `<tr>
              <td><code>${escapeHtml(t.path)}</code></td>
              <td><span class="doc-token-val">${swatch}${escapeHtml(t.resolvedValue)}</span></td>
              <td><span class="doc-tag">${escapeHtml(t.type || 'token')}</span></td>
              <td><button class="doc-copy-btn" onclick="navigator.clipboard.writeText('${escapeHtml(t.resolvedValue)}')">Copy</button></td>
            </tr>`;
          })
          .join('');

        htmlParts.push(`
<div class="doc-token-table-wrapper">
  ${block.title ? `<h4 class="doc-table-title">${escapeHtml(block.title)}</h4>` : ''}
  <table class="doc-token-table">
    <thead>
      <tr><th>Token Name</th><th>Value</th><th>Type</th><th>Action</th></tr>
    </thead>
    <tbody>${rowsHtml || '<tr><td colspan="4">No tokens found.</td></tr>'}</tbody>
  </table>
</div>`);
        break;
      }

      case 'asset_grid': {
        const assets = context?.assets || [
          { id: 'icon-arrow', name: 'ArrowRight', svgContent: '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12h14M12 5l7 7-7 7"/></svg>' },
          { id: 'icon-check', name: 'CheckCircle', svgContent: '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>' },
          { id: 'icon-search', name: 'Search', svgContent: '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></svg>' },
        ];
        const gridItems = assets.map((a) => `
<div class="doc-asset-card" data-name="${escapeHtml(a.name)}">
  <div class="doc-asset-icon">${a.svgContent}</div>
  <div class="doc-asset-name">${escapeHtml(a.name)}</div>
  <div class="doc-asset-actions">
    <button class="doc-btn-xs" title="Copy SVG">SVG</button>
    <button class="doc-btn-xs" title="Copy JSX">JSX</button>
  </div>
</div>`).join('');

        htmlParts.push(`
<div class="doc-asset-grid-container">
  <div class="doc-asset-search-bar">
    <input type="text" placeholder="Search vector assets..." class="doc-asset-search-input" />
  </div>
  <div class="doc-asset-grid">${gridItems}</div>
</div>`);
        break;
      }

      case 'tabs': {
        const tabButtons = block.tabs.map((t, idx) => `<button class="doc-tab-btn ${idx === 0 ? 'active' : ''}">${escapeHtml(t.title)}</button>`).join('');
        const tabPanels = block.tabs.map((t, idx) => `<div class="doc-tab-panel ${idx === 0 ? 'active' : ''}">${renderDocBlocksToHtml(t.blocks, context)}</div>`).join('');
        htmlParts.push(`<div class="doc-tabs"><div class="doc-tab-bar">${tabButtons}</div><div class="doc-tab-content">${tabPanels}</div></div>`);
        break;
      }


      case 'context_mcp': {
        const title = block.title || 'Model Context Protocol (MCP)';
        const mcpUrl = block.mcpUrl || 'http://localhost:3000/api/mcp';
        htmlParts.push(`
<div class="doc-mcp-card">
  <div class="doc-mcp-header">
    <div class="doc-mcp-title">🤖 ${escapeHtml(title)}</div>
    <div class="doc-mcp-badge">Live Agent Gateway</div>
  </div>
  <div class="doc-mcp-desc">${escapeHtml(block.description || 'Connect AI coding agents directly to this living design system.')}</div>
  <div class="doc-mcp-code"><code>${escapeHtml(mcpUrl)}</code></div>
</div>`);
        break;
      }

      case 'component_health_matrix': {
        const title = block.title || 'Component Health & Parity Matrix';
        htmlParts.push(`
<div class="doc-health-matrix">
  <div class="doc-health-header">🛡️ ${escapeHtml(title)}</div>
  <div class="doc-health-badge">100% System Parity</div>
</div>`);
        break;
      }

      case 'prompt_template': {
        const title = block.title || 'AI System Prompt Template';
        htmlParts.push(`
<div class="doc-prompt-template-card">
  <div class="doc-prompt-header">
    <div class="doc-prompt-title">✨ ${escapeHtml(title)}</div>
    <div class="doc-prompt-badge">AI Assistant Prompt</div>
  </div>
  <div class="doc-prompt-content"><pre><code>${escapeHtml(block.prompt)}</code></pre></div>
</div>`);
        break;
      }

      case 'props_table': {
        const title = block.title || `${block.componentName || 'Component'} API Props`;
        const propRows = (block.props || []).map((p) => `
<tr>
  <td><code>${escapeHtml(p.name)}</code>${p.required ? ' <span class="badge-required">*</span>' : ''}</td>
  <td><code>${escapeHtml(p.type)}</code></td>
  <td>${p.defaultValue ? `<code>${escapeHtml(p.defaultValue)}</code>` : '-'}</td>
  <td>${escapeHtml(p.description)}</td>
</tr>`).join('');

        htmlParts.push(`
<div class="doc-props-table-card">
  <div class="doc-props-header">${escapeHtml(title)}</div>
  <table class="doc-props-table">
    <thead><tr><th>Prop</th><th>Type</th><th>Default</th><th>Description</th></tr></thead>
    <tbody>${propRows}</tbody>
  </table>
</div>`);
        break;
      }

      case 'storybook_embed': {
        htmlParts.push(`
<div class="doc-storybook-embed">
  <div class="doc-storybook-header">📕 Storybook: ${escapeHtml(block.title || block.storyId || 'Preview')}</div>
  <iframe src="${escapeHtml(block.url)}" width="100%" height="${block.height || 360}" allowfullscreen></iframe>
</div>`);
        break;
      }

      case 'version_diff': {
        const diffRows = (block.changes || []).map((ch) => `
<div class="doc-diff-row diff-${ch.changeType}">
  <span class="diff-tag">${escapeHtml(ch.changeType)}</span>
  <code>${escapeHtml(ch.path)}</code>
  <span class="diff-vals">${ch.oldValue ? `<s>${escapeHtml(ch.oldValue)}</s> &rarr; ` : ''}${ch.newValue ? escapeHtml(ch.newValue) : ''}</span>
</div>`).join('');

        htmlParts.push(`
<div class="doc-version-diff">
  <div class="doc-diff-header">${escapeHtml(block.title || 'Version Diff')} (${escapeHtml(block.fromVersion || 'v1')} &rarr; ${escapeHtml(block.toVersion || 'v2')})</div>
  <div class="doc-diff-list">${diffRows}</div>
</div>`);
        break;
      }

      default:
        break;
    }
  }

  return htmlParts.join('\n');
}

function escapeHtml(str: string): string {
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}
