/**
 * Rich Document Editor — Block-Based Engine
 * 
 * Notion-like block editor for design system documentation:
 * - Block types: heading, paragraph, code, image, callout, divider, table, embed, token-swatch
 * - Slash commands (/) for quick block insertion
 * - Drag-and-drop reordering
 * - Markdown import/export
 * - Real-time collaboration integration
 */

export type BlockType =
  | 'heading1'
  | 'heading2'
  | 'heading3'
  | 'paragraph'
  | 'code'
  | 'image'
  | 'callout'
  | 'divider'
  | 'table'
  | 'bullet_list'
  | 'numbered_list'
  | 'toggle'
  | 'quote'
  | 'embed'
  | 'token_swatch'
  | 'component_preview'
  | 'color_palette'
  | 'spacing_scale'
  | 'typography_specimen';

export interface DocBlock {
  id: string;
  type: BlockType;
  content: string;
  properties: Record<string, unknown>;
  children?: DocBlock[];
  createdAt: number;
  updatedAt: number;
  createdBy?: string;
}

export interface DocPage {
  id: string;
  title: string;
  slug: string;
  icon?: string;
  coverImage?: string;
  blocks: DocBlock[];
  parentId?: string;
  order: number;
  status: 'draft' | 'published' | 'archived';
  createdAt: number;
  updatedAt: number;
  createdBy: string;
  lastEditedBy: string;
  designSystemId: string;
  tags: string[];
}

export interface SlashCommand {
  id: string;
  label: string;
  icon: string;
  description: string;
  blockType: BlockType;
  defaultContent: string;
  defaultProperties: Record<string, unknown>;
  keywords: string[];
}

// ─── Block Factory ─────────────────────────────────────────────────────

export function createBlock(type: BlockType, content = '', properties: Record<string, unknown> = {}): DocBlock {
  return {
    id: `blk-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 6)}`,
    type,
    content,
    properties,
    createdAt: Date.now(),
    updatedAt: Date.now(),
  };
}

export function createPage(params: { title: string; designSystemId: string; createdBy: string; parentId?: string }): DocPage {
  return {
    id: `page-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 6)}`,
    title: params.title,
    slug: params.title.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, ''),
    blocks: [createBlock('heading1', params.title)],
    order: 0,
    status: 'draft',
    createdAt: Date.now(),
    updatedAt: Date.now(),
    createdBy: params.createdBy,
    lastEditedBy: params.createdBy,
    designSystemId: params.designSystemId,
    parentId: params.parentId,
    tags: [],
  };
}

// ─── Slash Commands Registry ───────────────────────────────────────────

export const SLASH_COMMANDS: SlashCommand[] = [
  { id: 'h1', label: 'Heading 1', icon: 'H1', description: 'Large section heading', blockType: 'heading1', defaultContent: '', defaultProperties: {}, keywords: ['h1', 'heading', 'title'] },
  { id: 'h2', label: 'Heading 2', icon: 'H2', description: 'Medium section heading', blockType: 'heading2', defaultContent: '', defaultProperties: {}, keywords: ['h2', 'heading', 'subtitle'] },
  { id: 'h3', label: 'Heading 3', icon: 'H3', description: 'Small section heading', blockType: 'heading3', defaultContent: '', defaultProperties: {}, keywords: ['h3', 'heading'] },
  { id: 'para', label: 'Text', icon: 'T', description: 'Plain text paragraph', blockType: 'paragraph', defaultContent: '', defaultProperties: {}, keywords: ['text', 'paragraph', 'p'] },
  { id: 'code', label: 'Code Block', icon: '</>', description: 'Code with syntax highlighting', blockType: 'code', defaultContent: '', defaultProperties: { language: 'typescript' }, keywords: ['code', 'snippet', 'pre'] },
  { id: 'image', label: 'Image', icon: '🖼', description: 'Upload or embed an image', blockType: 'image', defaultContent: '', defaultProperties: { src: '', alt: '', caption: '' }, keywords: ['image', 'img', 'picture', 'photo'] },
  { id: 'callout', label: 'Callout', icon: '💡', description: 'Highlighted note or warning', blockType: 'callout', defaultContent: '', defaultProperties: { variant: 'info', icon: '💡' }, keywords: ['callout', 'note', 'warning', 'tip', 'alert'] },
  { id: 'divider', label: 'Divider', icon: '—', description: 'Horizontal divider', blockType: 'divider', defaultContent: '', defaultProperties: {}, keywords: ['divider', 'hr', 'line', 'separator'] },
  { id: 'table', label: 'Table', icon: '▦', description: 'Data table', blockType: 'table', defaultContent: '', defaultProperties: { rows: 3, cols: 3, data: [['']] }, keywords: ['table', 'grid', 'data'] },
  { id: 'bullet', label: 'Bullet List', icon: '•', description: 'Unordered list', blockType: 'bullet_list', defaultContent: '', defaultProperties: { items: [''] }, keywords: ['bullet', 'list', 'ul', 'unordered'] },
  { id: 'number', label: 'Numbered List', icon: '1.', description: 'Ordered list', blockType: 'numbered_list', defaultContent: '', defaultProperties: { items: [''] }, keywords: ['number', 'ordered', 'ol'] },
  { id: 'toggle', label: 'Toggle', icon: '▸', description: 'Collapsible content', blockType: 'toggle', defaultContent: 'Toggle title', defaultProperties: { isOpen: false }, keywords: ['toggle', 'collapse', 'accordion', 'expand'] },
  { id: 'quote', label: 'Quote', icon: '❝', description: 'Block quote', blockType: 'quote', defaultContent: '', defaultProperties: { author: '' }, keywords: ['quote', 'blockquote', 'citation'] },
  { id: 'embed', label: 'Embed', icon: '🔗', description: 'Embed external content', blockType: 'embed', defaultContent: '', defaultProperties: { url: '', type: 'iframe' }, keywords: ['embed', 'iframe', 'url', 'link'] },
  // Design-system specific blocks
  { id: 'token-swatch', label: 'Token Swatch', icon: '🎨', description: 'Display a design token with visual preview', blockType: 'token_swatch', defaultContent: '', defaultProperties: { tokenPath: '', showValue: true, showCopyButton: true }, keywords: ['token', 'swatch', 'color', 'variable'] },
  { id: 'component-preview', label: 'Component Preview', icon: '🧩', description: 'Live component preview with code', blockType: 'component_preview', defaultContent: '', defaultProperties: { componentName: '', showCode: true, showProps: true, variant: 'default' }, keywords: ['component', 'preview', 'demo', 'live'] },
  { id: 'color-palette', label: 'Color Palette', icon: '🌈', description: 'Display a color palette from tokens', blockType: 'color_palette', defaultContent: '', defaultProperties: { tokenPrefix: 'color.brand', layout: 'grid' }, keywords: ['palette', 'colors', 'swatches'] },
  { id: 'spacing-scale', label: 'Spacing Scale', icon: '📏', description: 'Visual spacing scale display', blockType: 'spacing_scale', defaultContent: '', defaultProperties: { tokenPrefix: 'spacing' }, keywords: ['spacing', 'scale', 'sizes'] },
  { id: 'typography-specimen', label: 'Typography Specimen', icon: 'Aa', description: 'Typography preview with all font styles', blockType: 'typography_specimen', defaultContent: 'The quick brown fox jumps over the lazy dog', defaultProperties: { tokenPrefix: 'typography' }, keywords: ['typography', 'font', 'text', 'specimen'] },
];

// ─── Block Operations ──────────────────────────────────────────────────

export class DocEngine {
  private pages: Map<string, DocPage> = new Map();

  // ── Page CRUD ────────────────────────────────────────────────────────

  createPage(params: { title: string; designSystemId: string; createdBy: string; parentId?: string }): DocPage {
    const page = createPage(params);
    this.pages.set(page.id, page);
    return page;
  }

  getPage(pageId: string): DocPage | undefined {
    return this.pages.get(pageId);
  }

  getPageBySlug(slug: string, designSystemId: string): DocPage | undefined {
    for (const page of this.pages.values()) {
      if (page.slug === slug && page.designSystemId === designSystemId) return page;
    }
    return undefined;
  }

  listPages(designSystemId: string): DocPage[] {
    return Array.from(this.pages.values())
      .filter(p => p.designSystemId === designSystemId)
      .sort((a, b) => a.order - b.order);
  }

  updatePage(pageId: string, updates: Partial<Pick<DocPage, 'title' | 'slug' | 'icon' | 'coverImage' | 'status' | 'tags' | 'order'>>): DocPage | undefined {
    const page = this.pages.get(pageId);
    if (!page) return undefined;
    Object.assign(page, updates, { updatedAt: Date.now() });
    return page;
  }

  deletePage(pageId: string): boolean {
    return this.pages.delete(pageId);
  }

  // ── Block CRUD ───────────────────────────────────────────────────────

  addBlock(pageId: string, type: BlockType, content = '', properties: Record<string, unknown> = {}, afterBlockId?: string): DocBlock | undefined {
    const page = this.pages.get(pageId);
    if (!page) return undefined;

    const block = createBlock(type, content, properties);

    if (afterBlockId) {
      const idx = page.blocks.findIndex(b => b.id === afterBlockId);
      if (idx >= 0) {
        page.blocks.splice(idx + 1, 0, block);
      } else {
        page.blocks.push(block);
      }
    } else {
      page.blocks.push(block);
    }

    page.updatedAt = Date.now();
    return block;
  }

  updateBlock(pageId: string, blockId: string, updates: Partial<Pick<DocBlock, 'content' | 'properties' | 'type'>>): DocBlock | undefined {
    const page = this.pages.get(pageId);
    if (!page) return undefined;

    const block = page.blocks.find(b => b.id === blockId);
    if (!block) return undefined;

    Object.assign(block, updates, { updatedAt: Date.now() });
    page.updatedAt = Date.now();
    return block;
  }

  deleteBlock(pageId: string, blockId: string): boolean {
    const page = this.pages.get(pageId);
    if (!page) return false;

    const idx = page.blocks.findIndex(b => b.id === blockId);
    if (idx < 0) return false;

    page.blocks.splice(idx, 1);
    page.updatedAt = Date.now();
    return true;
  }

  moveBlock(pageId: string, blockId: string, newIndex: number): boolean {
    const page = this.pages.get(pageId);
    if (!page) return false;

    const idx = page.blocks.findIndex(b => b.id === blockId);
    if (idx < 0) return false;

    const [block] = page.blocks.splice(idx, 1);
    page.blocks.splice(Math.min(newIndex, page.blocks.length), 0, block);
    page.updatedAt = Date.now();
    return true;
  }

  // ── Slash Command Search ─────────────────────────────────────────────

  searchCommands(query: string): SlashCommand[] {
    const q = query.toLowerCase().replace(/^\//, '');
    if (!q) return SLASH_COMMANDS;
    return SLASH_COMMANDS.filter(cmd =>
      cmd.label.toLowerCase().includes(q) ||
      cmd.keywords.some(k => k.includes(q))
    );
  }

  // ── Markdown Conversion ──────────────────────────────────────────────

  pageToMarkdown(pageId: string): string {
    const page = this.pages.get(pageId);
    if (!page) return '';

    return page.blocks.map(block => {
      switch (block.type) {
        case 'heading1': return `# ${block.content}\n`;
        case 'heading2': return `## ${block.content}\n`;
        case 'heading3': return `### ${block.content}\n`;
        case 'paragraph': return `${block.content}\n`;
        case 'code': return `\`\`\`${block.properties.language || ''}\n${block.content}\n\`\`\`\n`;
        case 'image': return `![${block.properties.alt || ''}](${block.properties.src})\n`;
        case 'callout': return `> **${block.properties.icon || '💡'}** ${block.content}\n`;
        case 'divider': return `---\n`;
        case 'quote': return `> ${block.content}\n${block.properties.author ? `> — ${block.properties.author}\n` : ''}`;
        case 'bullet_list': return (block.properties.items as string[] || []).map(i => `- ${i}`).join('\n') + '\n';
        case 'numbered_list': return (block.properties.items as string[] || []).map((i, idx) => `${idx + 1}. ${i}`).join('\n') + '\n';
        case 'toggle': return `<details>\n<summary>${block.content}</summary>\n\n${(block.children || []).map(c => c.content).join('\n')}\n</details>\n`;
        case 'token_swatch': return `**Token:** \`${block.properties.tokenPath}\`\n`;
        case 'component_preview': return `**Component:** \`${block.properties.componentName}\`\n`;
        default: return block.content ? `${block.content}\n` : '';
      }
    }).join('\n');
  }

  markdownToPage(markdown: string, designSystemId: string, createdBy: string): DocPage {
    const lines = markdown.split('\n');
    const blocks: DocBlock[] = [];
    let title = 'Untitled';

    let i = 0;
    while (i < lines.length) {
      const line = lines[i];

      // Headings
      if (line.startsWith('### ')) {
        blocks.push(createBlock('heading3', line.slice(4)));
      } else if (line.startsWith('## ')) {
        blocks.push(createBlock('heading2', line.slice(3)));
      } else if (line.startsWith('# ')) {
        const h = line.slice(2);
        if (blocks.length === 0) title = h;
        blocks.push(createBlock('heading1', h));
      }
      // Code blocks
      else if (line.startsWith('```')) {
        const lang = line.slice(3).trim();
        const codeLines: string[] = [];
        i++;
        while (i < lines.length && !lines[i].startsWith('```')) {
          codeLines.push(lines[i]);
          i++;
        }
        blocks.push(createBlock('code', codeLines.join('\n'), { language: lang || 'text' }));
      }
      // Divider
      else if (line.match(/^---+$/)) {
        blocks.push(createBlock('divider'));
      }
      // Quote
      else if (line.startsWith('> ')) {
        blocks.push(createBlock('quote', line.slice(2)));
      }
      // Bullet list
      else if (line.startsWith('- ') || line.startsWith('* ')) {
        const items: string[] = [line.slice(2)];
        while (i + 1 < lines.length && (lines[i + 1].startsWith('- ') || lines[i + 1].startsWith('* '))) {
          i++;
          items.push(lines[i].slice(2));
        }
        blocks.push(createBlock('bullet_list', '', { items }));
      }
      // Image
      else if (line.match(/^!\[.*\]\(.*\)$/)) {
        const match = line.match(/^!\[(.*)\]\((.*)\)$/);
        if (match) blocks.push(createBlock('image', '', { alt: match[1], src: match[2] }));
      }
      // Paragraph
      else if (line.trim()) {
        blocks.push(createBlock('paragraph', line));
      }

      i++;
    }

    const page = createPage({ title, designSystemId, createdBy });
    page.blocks = blocks.length > 0 ? blocks : page.blocks;
    this.pages.set(page.id, page);
    return page;
  }

  // ── Seed with default design system docs ─────────────────────────────

  seedDefaultDocs(designSystemId: string): DocPage[] {
    const pages: DocPage[] = [];

    // Getting Started page
    const gettingStarted = this.createPage({ title: 'Getting Started', designSystemId, createdBy: 'system' });
    gettingStarted.icon = '🚀';
    gettingStarted.status = 'published';
    gettingStarted.blocks = [
      createBlock('heading1', 'Getting Started'),
      createBlock('callout', 'Welcome to the design system! This guide will help you get up and running.', { variant: 'info', icon: '👋' }),
      createBlock('heading2', 'Installation'),
      createBlock('code', 'npm install @nexus-design/tokens', { language: 'bash' }),
      createBlock('heading2', 'Quick Start'),
      createBlock('paragraph', 'Import the token stylesheet into your application entry point:'),
      createBlock('code', "import '@nexus-design/tokens/tokens.css';\n\n// Now use CSS custom properties\nconst styles = {\n  color: 'var(--nova-color-brand-primary)',\n  padding: 'var(--nova-spacing-md)',\n};", { language: 'typescript' }),
      createBlock('heading2', 'Color Palette'),
      createBlock('color_palette', '', { tokenPrefix: 'color.brand', layout: 'grid' }),
      createBlock('heading2', 'Spacing Scale'),
      createBlock('spacing_scale', '', { tokenPrefix: 'spacing' }),
    ];

    // Component Guidelines page
    const guidelines = this.createPage({ title: 'Component Guidelines', designSystemId, createdBy: 'system' });
    guidelines.icon = '🧩';
    guidelines.status = 'published';
    guidelines.blocks = [
      createBlock('heading1', 'Component Guidelines'),
      createBlock('paragraph', 'Follow these guidelines when building components to ensure consistency across the design system.'),
      createBlock('heading2', 'Button'),
      createBlock('component_preview', '', { componentName: 'Button', showCode: true, variant: 'default' }),
      createBlock('callout', 'Always use the Button component for interactive actions. Never style raw anchor tags to look like buttons.', { variant: 'warning', icon: '⚠️' }),
      createBlock('heading2', 'Typography'),
      createBlock('typography_specimen', 'The quick brown fox jumps over the lazy dog', { tokenPrefix: 'typography' }),
      createBlock('heading2', 'Best Practices'),
      createBlock('bullet_list', '', { items: [
        'Use design tokens for all color, spacing, and typography values',
        'Never hardcode hex colors or pixel values',
        'Use semantic token names (e.g., color.text.primary) over primitive tokens',
        'Test all components for accessibility (WCAG AA minimum)',
        'Document all component props with TypeScript interfaces',
      ]}),
    ];

    pages.push(gettingStarted, guidelines);
    return pages;
  }
}

let docEngineInstance: DocEngine | null = null;
export function getDocEngine(): DocEngine {
  if (!docEngineInstance) docEngineInstance = new DocEngine();
  return docEngineInstance;
}
