export type DocBlockType =
  | 'heading'
  | 'paragraph'
  | 'code'
  | 'callout'
  | 'token_list'
  | 'token_chip'
  | 'token_table'
  | 'figma_embed'
  | 'component_preview'
  | 'interactive_playground'
  | 'component_health_matrix'
  | 'asset_grid'
  | 'do_dont'
  | 'table'
  | 'divider'
  | 'tabs'
  | 'context_mcp'
  | 'prompt_template'
  | 'props_table'
  | 'storybook_embed'
  | 'version_diff';

export interface BaseDocBlock {
  id: string;
  type: DocBlockType;
}


export interface HeadingDocBlock extends BaseDocBlock {
  type: 'heading';
  level: 1 | 2 | 3 | 4 | 5 | 6;
  text: string;
}

export interface ParagraphDocBlock extends BaseDocBlock {
  type: 'paragraph';
  text: string;
}

export interface CodeDocBlock extends BaseDocBlock {
  type: 'code';
  language: string;
  code: string;
  title?: string;
  showLineNumbers?: boolean;
}

export interface CalloutDocBlock extends BaseDocBlock {
  type: 'callout';
  calloutType: 'info' | 'warning' | 'success' | 'error';
  title?: string;
  text: string;
}

export interface TokenListDocBlock extends BaseDocBlock {
  type: 'token_list';
  category?: string;
  groupPath?: string;
  tokenPersistentIds?: string[];
  showValues?: boolean;
}

export interface TokenChipDocBlock extends BaseDocBlock {
  type: 'token_chip';
  tokenPath: string;
  tokenPersistentId?: string;
  label?: string;
}

export interface FigmaEmbedDocBlock extends BaseDocBlock {
  type: 'figma_embed';
  url: string;
  title?: string;
  height?: number;
}

export interface ComponentPreviewDocBlock extends BaseDocBlock {
  type: 'component_preview';
  componentId: string;
  framework?: 'react' | 'vue' | 'html';
  variant?: string;
  interactive?: boolean;
}

export interface ComponentHealthMatrixDocBlock extends BaseDocBlock {
  type: 'component_health_matrix';
  title?: string;
  componentIds?: string[];
}

export interface AssetGridDocBlock extends BaseDocBlock {
  type: 'asset_grid';
  category?: 'icons' | 'logos' | 'illustrations';
  filterTag?: string;
  iconSize?: number;
}

export interface TableDocBlock extends BaseDocBlock {
  type: 'table';
  headers: string[];
  rows: string[][];
}

export interface DividerDocBlock extends BaseDocBlock {
  type: 'divider';
}

export interface TabsDocBlock extends BaseDocBlock {
  type: 'tabs';
  tabs: Array<{
    title: string;
    blocks: DocBlock[];
  }>;
}

export interface DoDontItem {
  title?: string;
  text: string;
  code?: string;
  tokenPath?: string;
  tokenValue?: string;
  mediaUrl?: string;
  caption?: string;
}

export interface DoDontDocBlock extends BaseDocBlock {
  type: 'do_dont';
  title?: string;
  doItem: DoDontItem;
  dontItem: DoDontItem;
}

export interface InteractivePlaygroundDocBlock extends BaseDocBlock {
  type: 'interactive_playground';
  componentName: string;
  title?: string;
  description?: string;
  defaultProps?: Record<string, any>;
  supportedProps?: Array<{
    name: string;
    type: 'string' | 'boolean' | 'select' | 'number';
    options?: string[];
    defaultValue?: any;
    description?: string;
  }>;
  codeSnippet?: string;
  framework?: 'react' | 'html' | 'vue';
}

export interface TokenTableDocBlock extends BaseDocBlock {
  type: 'token_table';
  title?: string;
  category?: string;
  showSearch?: boolean;
  showCopy?: boolean;
  filterPath?: string;
  columns?: string[];
}

export interface ContextMcpDocBlock extends BaseDocBlock {
  type: 'context_mcp';
  title?: string;
  description?: string;
  connections?: Array<'cursor' | 'claudeCode' | 'vsCode' | 'codex'>;
  mcpUrl?: string;
  showCodeSnippet?: boolean;
}

export interface PromptTemplateDocBlock extends BaseDocBlock {
  type: 'prompt_template';
  title?: string;
  description?: string;
  prompt: string;
  systemPrompt?: string;
  targetTools?: Array<'cursor' | 'claude' | 'copilot' | 'chatgpt'>;
  variables?: Record<string, string>;
}

export interface PropsTableRow {
  name: string;
  type: string;
  defaultValue?: string;
  required?: boolean;
  description: string;
}

export interface PropsTableDocBlock extends BaseDocBlock {
  type: 'props_table';
  componentName?: string;
  title?: string;
  props: PropsTableRow[];
}

export interface StorybookEmbedDocBlock extends BaseDocBlock {
  type: 'storybook_embed';
  url: string;
  storyId?: string;
  title?: string;
  height?: number;
}

export interface VersionDiffItem {
  path: string;
  changeType: 'added' | 'changed' | 'removed';
  oldValue?: string;
  newValue?: string;
  type?: string;
}

export interface VersionDiffDocBlock extends BaseDocBlock {
  type: 'version_diff';
  title?: string;
  fromVersion?: string;
  toVersion?: string;
  changes: VersionDiffItem[];
}

export type DocBlock =
  | HeadingDocBlock
  | ParagraphDocBlock
  | CodeDocBlock
  | CalloutDocBlock
  | TokenListDocBlock
  | TokenChipDocBlock
  | TokenTableDocBlock
  | FigmaEmbedDocBlock
  | ComponentPreviewDocBlock
  | InteractivePlaygroundDocBlock
  | ComponentHealthMatrixDocBlock
  | AssetGridDocBlock
  | DoDontDocBlock
  | TableDocBlock
  | DividerDocBlock
  | TabsDocBlock
  | ContextMcpDocBlock
  | PromptTemplateDocBlock
  | PropsTableDocBlock
  | StorybookEmbedDocBlock
  | VersionDiffDocBlock;

export interface DocRenderContext {
  tokens?: Array<{ path: string; resolvedValue: string; type: string }>;
  components?: Array<{ id: string; name: string; category: string }>;
  assets?: Array<{ id: string; name: string; svgContent: string }>;
}

