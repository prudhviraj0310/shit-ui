import { getDb } from '@/db/index';
import { tokens, components, docPages, releases } from '@/db/schema';
import { eq, or, sql } from 'drizzle-orm';

export interface SearchResultItem {
  id: string;
  title: string;
  subtitle?: string;
  category: 'token' | 'component' | 'doc' | 'exporter' | 'release';
  badge?: string;
  metadata?: Record<string, any>;
  urlPath?: string;
}

export class UniversalSearchEngine {
  private db: any;

  constructor(db: any) {
    this.db = db;
  }

  public async search(query: string, limit = 20): Promise<SearchResultItem[]> {
    const q = (query || '').trim().toLowerCase();
    if (!q) return this.getDefaultSuggestions();

    const results: SearchResultItem[] = [];

    // 1. Search Tokens
    const allTokens = await this.db.select().from(tokens).limit(100);
    for (const t of allTokens) {
      if (
        t.name.toLowerCase().includes(q) ||
        t.path.toLowerCase().includes(q) ||
        (t.resolvedValue || '').toLowerCase().includes(q) ||
        t.category.toLowerCase().includes(q)
      ) {
        results.push({
          id: t.id,
          title: t.name,
          subtitle: `${t.path} • ${t.resolvedValue}`,
          category: 'token',
          badge: t.type,
          metadata: {
            rawValue: t.rawValue,
            resolvedValue: t.resolvedValue,
            category: t.category,
            path: t.path,
          },
          urlPath: `tokens#${t.name}`,
        });
      }
    }

    // 2. Search Components
    const allComponents = await this.db.select().from(components);
    for (const c of allComponents) {
      if (
        c.name.toLowerCase().includes(q) ||
        (c.description || '').toLowerCase().includes(q) ||
        c.category.toLowerCase().includes(q)
      ) {
        results.push({
          id: c.id,
          title: c.name,
          subtitle: c.description || `${c.framework} UI component`,
          category: 'component',
          badge: c.status || 'ready',
          metadata: {
            framework: c.framework,
            category: c.category,
          },
          urlPath: `components-board#${c.name}`,
        });
      }
    }

    // 3. Search Documentation Pages
    const allDocs = await this.db.select().from(docPages);
    for (const d of allDocs) {
      if (
        d.title.toLowerCase().includes(q) ||
        d.slug.toLowerCase().includes(q) ||
        d.category.toLowerCase().includes(q) ||
        d.content.toLowerCase().includes(q)
      ) {
        results.push({
          id: d.id,
          title: d.title,
          subtitle: `${d.category} documentation`,
          category: 'doc',
          badge: 'Documentation',
          urlPath: `docs#${d.slug}`,
        });
      }
    }

    // 4. Search Releases
    const allReleases = await this.db.select().from(releases);
    for (const r of allReleases) {
      if (
        r.version.toLowerCase().includes(q) ||
        r.title.toLowerCase().includes(q) ||
        (r.description || '').toLowerCase().includes(q)
      ) {
        results.push({
          id: r.id,
          title: `Release ${r.version}: ${r.title}`,
          subtitle: r.description || `Released with ${r.tokensCount} tokens`,
          category: 'release',
          badge: 'Snapshot',
          urlPath: `releases#${r.version}`,
        });
      }
    }

    // 5. Exporters static list
    const exporters = [
      { id: 'exp-css', title: 'CSS Custom Properties', subtitle: 'Modern CSS :root variables exporter', category: 'exporter' as const, badge: 'CSS' },
      { id: 'exp-scss', title: 'SCSS Variables & Mixins', subtitle: 'Sass design system token definitions', category: 'exporter' as const, badge: 'SCSS' },
      { id: 'exp-swift', title: 'iOS Swift & SwiftUI', subtitle: 'Swift Color & CGFloat token extensions', category: 'exporter' as const, badge: 'Swift' },
      { id: 'exp-flutter', title: 'Flutter Dart Classes', subtitle: 'Dart ThemeData & Color constants', category: 'exporter' as const, badge: 'Flutter' },
      { id: 'exp-kotlin', title: 'Android Kotlin & Compose', subtitle: 'Jetpack Compose Color & Dp definitions', category: 'exporter' as const, badge: 'Kotlin' },
      { id: 'exp-pulsar', title: 'Pulsar Custom Template Engine', subtitle: 'Custom Jinja2-style code generation blueprints', category: 'exporter' as const, badge: 'Pulsar' },
    ];

    for (const exp of exporters) {
      if (exp.title.toLowerCase().includes(q) || exp.subtitle.toLowerCase().includes(q)) {
        results.push({
          ...exp,
          urlPath: `export#${exp.id}`,
        });
      }
    }

    return results.slice(0, limit);
  }

  private getDefaultSuggestions(): SearchResultItem[] {
    return [
      { id: 'sug-tokens', title: 'Design Tokens', subtitle: 'Browse colors, typography, spacing & radii', category: 'token', badge: 'Core', urlPath: 'tokens' },
      { id: 'sug-components', title: 'Component Lifecycle Board', subtitle: 'Kanban view of production-ready components', category: 'component', badge: 'Board', urlPath: 'components-board' },
      { id: 'sug-branching', title: 'Token Branching & Merging', subtitle: 'Compare token branches with visual diffs', category: 'token', badge: 'Git', urlPath: 'branching' },
      { id: 'sug-docs', title: 'Living Documentation', subtitle: 'Read design system block documentation', category: 'doc', badge: 'Docs', urlPath: 'docs' },
      { id: 'sug-pulsar', title: 'Pulsar Template Blueprints', subtitle: 'Execute custom code generator templates', category: 'exporter', badge: 'Pulsar', urlPath: 'pulsar' },
    ];
  }
}
