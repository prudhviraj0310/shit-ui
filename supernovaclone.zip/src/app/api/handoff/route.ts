import { NextResponse } from 'next/server';
import { validateApiAuth } from '@/server/auth';
import { getDb } from '@/db/index';
import { tokens } from '@/db/schema';
import { getHandoffGenerator } from '@/core/handoff/generator';
import type { FlatToken } from '@/core/tokens/types';

export async function GET(request: Request) {
  try {
    const auth = validateApiAuth(request);
    if (!auth.authorized) return auth.errorResponse!;

    const { searchParams } = new URL(request.url);
    const dsId = searchParams.get('designSystemId') || 'ds-nova-design';
    const view = searchParams.get('view') || 'full';

    const { db } = await getDb();
    const allTokens = await db.select().from(tokens);
    const seenPaths = new Set<string>();
    // Prioritize draft version tokens, then release versions
    const dsTokens = allTokens.filter((t: any) => t.designSystemId === dsId);
    const draftTokens = dsTokens.filter((t: any) => t.versionId?.includes('draft'));
    const sourceTokens = draftTokens.length > 0 ? draftTokens : dsTokens;

    const flatTokens: FlatToken[] = [];
    for (const t of sourceTokens) {
      if (!seenPaths.has(t.path)) {
        seenPaths.add(t.path);
        flatTokens.push({
          name: t.name, path: t.path, category: t.category, type: t.type,
          rawValue: t.rawValue, resolvedValue: t.resolvedValue || t.rawValue,
          isAlias: t.isAlias || false, aliasTarget: t.aliasTarget || undefined,
          description: t.description || undefined,
        });
      }
    }

    const handoff = getHandoffGenerator();

    switch (view) {
      case 'tokens':
        return NextResponse.json({ success: true, data: handoff.generateTokenSpecs(flatTokens) });
      case 'platforms':
        return NextResponse.json({ success: true, data: handoff.generatePlatformGuides() });
      case 'accessibility':
        const component = searchParams.get('component') || 'Button';
        return NextResponse.json({ success: true, data: handoff.generateAccessibilityNotes(component) });
      case 'full':
      default:
        const spec = handoff.generateFullHandoff(flatTokens, [
          { name: 'Button', description: 'Primary action button', props: [{ name: 'variant', type: 'string', required: false, default: 'primary', description: 'Visual variant', options: ['primary', 'secondary', 'ghost'] }], variants: [{ name: 'Primary', props: { variant: 'primary' }, description: 'Default CTA button' }], tokens: ['color.brand.primary', 'spacing.md', 'borderRadius.md'] },
          { name: 'TextInput', description: 'Form text input', props: [{ name: 'placeholder', type: 'string', required: false, description: 'Placeholder text' }], variants: [], tokens: ['color.text.primary', 'spacing.sm', 'borderRadius.sm'] },
        ]);
        return NextResponse.json({ success: true, data: spec });
    }
  } catch (err: any) {
    return NextResponse.json({ success: false, error: err.message }, { status: 500 });
  }
}
