import { NextResponse } from 'next/server';
import { getDb } from '@/db/index';
import { ComplianceManager } from '@/core/audit/compliance';
import { validateApiAuth } from '@/server/auth';

export async function GET(request: Request) {
  const auth = validateApiAuth(request);
  if (!auth.authorized) {
    return auth.errorResponse || NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  try {
    const url = new URL(request.url);
    const format = url.searchParams.get('format');

    const { db } = await getDb();
    const manager = new ComplianceManager(db);

    if (format === 'csv' || format === 'json') {
      const exported = await manager.exportLogs(format);
      return new NextResponse(exported.data, {
        headers: {
          'Content-Type': exported.contentType,
          'Content-Disposition': `attachment; filename="${exported.filename}"`,
        },
      });
    }

    const report = await manager.getReport();
    return NextResponse.json({ success: true, ...report });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}
