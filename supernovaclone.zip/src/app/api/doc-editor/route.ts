import { NextResponse } from 'next/server';
import { validateApiAuth } from '@/server/auth';
import { getDocEngine, SLASH_COMMANDS } from '@/core/docs/editor';

export async function GET(request: Request) {
  const auth = validateApiAuth(request);
  if (!auth.authorized) return auth.errorResponse!;

  const { searchParams } = new URL(request.url);
  const dsId = searchParams.get('designSystemId') || 'ds-nova-design';
  const pageId = searchParams.get('pageId');
  const slug = searchParams.get('slug');
  const action = searchParams.get('action');

  const engine = getDocEngine();

  if (action === 'slash-commands') {
    const query = searchParams.get('q') || '';
    return NextResponse.json({ success: true, commands: engine.searchCommands(query) });
  }

  if (pageId) {
    const page = engine.getPage(pageId);
    if (!page) return NextResponse.json({ success: false, error: 'Page not found' }, { status: 404 });
    return NextResponse.json({ success: true, page });
  }

  if (slug) {
    const page = engine.getPageBySlug(slug, dsId);
    if (!page) return NextResponse.json({ success: false, error: 'Page not found' }, { status: 404 });
    return NextResponse.json({ success: true, page });
  }

  let pages = engine.listPages(dsId);
  if (pages.length === 0) {
    engine.seedDefaultDocs(dsId);
    pages = engine.listPages(dsId);
  }

  return NextResponse.json({
    success: true,
    pages: pages.map(p => ({ id: p.id, title: p.title, slug: p.slug, icon: p.icon, status: p.status, blockCount: p.blocks.length, updatedAt: p.updatedAt })),
    totalCommands: SLASH_COMMANDS.length,
  });
}

export async function POST(request: Request) {
  try {
    const auth = validateApiAuth(request);
    if (!auth.authorized) return auth.errorResponse!;

    const body = await request.json();
    const { action, designSystemId = 'ds-nova-design' } = body;

    const engine = getDocEngine();

    switch (action) {
      case 'create-page': {
        const page = engine.createPage({ title: body.title || 'Untitled', designSystemId, createdBy: auth.userId || 'system', parentId: body.parentId });
        return NextResponse.json({ success: true, page });
      }
      case 'update-page': {
        const page = engine.updatePage(body.pageId, body.updates || {});
        if (!page) return NextResponse.json({ success: false, error: 'Page not found' }, { status: 404 });
        return NextResponse.json({ success: true, page });
      }
      case 'delete-page': {
        const deleted = engine.deletePage(body.pageId);
        return NextResponse.json({ success: deleted, deletedId: body.pageId });
      }
      case 'add-block': {
        const block = engine.addBlock(body.pageId, body.blockType, body.content || '', body.properties || {}, body.afterBlockId);
        if (!block) return NextResponse.json({ success: false, error: 'Page not found' }, { status: 404 });
        return NextResponse.json({ success: true, block });
      }
      case 'update-block': {
        const block = engine.updateBlock(body.pageId, body.blockId, { content: body.content, properties: body.properties, type: body.blockType });
        if (!block) return NextResponse.json({ success: false, error: 'Block not found' }, { status: 404 });
        return NextResponse.json({ success: true, block });
      }
      case 'delete-block': {
        const deleted = engine.deleteBlock(body.pageId, body.blockId);
        return NextResponse.json({ success: deleted });
      }
      case 'move-block': {
        const moved = engine.moveBlock(body.pageId, body.blockId, body.newIndex);
        return NextResponse.json({ success: moved });
      }
      case 'export-markdown': {
        const md = engine.pageToMarkdown(body.pageId);
        return NextResponse.json({ success: true, markdown: md });
      }
      case 'import-markdown': {
        const page = engine.markdownToPage(body.markdown, designSystemId, auth.userId || 'system');
        return NextResponse.json({ success: true, page });
      }
      default:
        return NextResponse.json({ success: false, error: `Unknown action: ${action}` }, { status: 400 });
    }
  } catch (err: any) {
    return NextResponse.json({ success: false, error: err.message }, { status: 500 });
  }
}
