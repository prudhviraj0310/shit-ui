import { NextResponse } from 'next/server';
import { OutboundWebhookDispatcher } from '@/core/webhooks/dispatcher';
import { validateApiAuth } from '@/server/auth';

export async function GET(request: Request) {
  const auth = validateApiAuth(request);
  if (!auth.authorized) {
    return auth.errorResponse || NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  try {
    const subs = OutboundWebhookDispatcher.listSubscriptions();
    return NextResponse.json({ success: true, count: subs.length, subscriptions: subs });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}

export async function POST(request: Request) {
  const auth = validateApiAuth(request);
  if (!auth.authorized) {
    return auth.errorResponse || NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  try {
    const body = await request.json().catch(() => ({}));
    const { action, url, events, description, secret, event, payload, subscriptionId } = body;

    if (action === 'dispatch' || (event && payload)) {
      const results = await OutboundWebhookDispatcher.dispatch(event || 'tokens.updated', payload || {});
      return NextResponse.json({ success: true, count: results.length, dispatched: results });
    }

    if (action === 'delete' || subscriptionId) {
      const deleted = OutboundWebhookDispatcher.deleteSubscription(subscriptionId);
      return NextResponse.json({ success: true, deleted });
    }

    if (!url) {
      return NextResponse.json({ success: false, error: 'url is required to subscribe.' }, { status: 400 });
    }

    const sub = OutboundWebhookDispatcher.addSubscription({
      url,
      events: Array.isArray(events) ? events : ['tokens.updated', 'release.published'],
      description,
      secret,
    });

    return NextResponse.json({ success: true, subscription: sub }, { status: 201 });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}
