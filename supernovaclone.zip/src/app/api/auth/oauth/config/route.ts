import { NextResponse } from 'next/server';

/**
 * Supernova AWS Cognito OAuth PKCE Discovery Configuration
 * Extracted via REA from Supernova production network trace (Evidence: ev_ce48d21bfbf303eed1f4c6959e49e9e17a9cced9aaa2c175e0d92c86b706aea1)
 */
export async function GET() {
  return NextResponse.json({
    clientId: '7n7icqdn6k338k14u2hm19ca99',
    userPoolPasswordClientId: '10gekqg01kcq7ct83rbd5lrutq',
    redirectUri: '/api/auth/callback/supernovaauth',
    responseType: 'code',
    challengeMethod: 'S256',
    tokenEndpoint: '/api/auth/token',
    userinfoEndpoint: '/api/auth/userinfo',
  });
}
