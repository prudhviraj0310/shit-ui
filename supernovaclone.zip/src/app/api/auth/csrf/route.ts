import { NextResponse } from 'next/server';
import crypto from 'crypto';

/**
 * Supernova Auth CSRF Handshake Endpoint
 * Extracted via REA from Supernova production network trace (Evidence: ev_ce48d21bfbf303eed1f4c6959e49e9e17a9cced9aaa2c175e0d92c86b706aea1)
 */
export async function GET() {
  const token = crypto.randomBytes(32).toString('hex');
  const response = NextResponse.json({
    csrfToken: token,
  });

  response.cookies.set('nexus.csrf-token', token, {
    path: '/',
    httpOnly: true,
    sameSite: 'lax',
    secure: process.env.NODE_ENV === 'production',
  });

  return response;
}
