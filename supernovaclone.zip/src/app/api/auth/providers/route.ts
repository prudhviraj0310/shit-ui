import { NextResponse } from 'next/server';

/**
 * Supernova Auth Providers Discovery Endpoint
 * Extracted via REA from Supernova production network trace (Evidence: ev_ce48d21bfbf303eed1f4c6959e49e9e17a9cced9aaa2c175e0d92c86b706aea1)
 */
export async function GET() {
  return NextResponse.json({
    supernovaauth: {
      id: 'supernovaauth',
      name: 'Supernova Auth',
      type: 'oauth',
      signinUrl: '/api/auth/signin/supernovaauth',
      callbackUrl: '/api/auth/callback/supernovaauth',
    },
    google: {
      id: 'google',
      name: 'Google Workspace',
      type: 'oauth',
      signinUrl: '/api/auth/signin/google',
      callbackUrl: '/api/auth/callback/google',
    },
    saml: {
      id: 'saml',
      name: 'Enterprise SAML 2.0 SSO',
      type: 'oauth',
      signinUrl: '/api/auth/signin/saml',
      callbackUrl: '/api/auth/callback/saml',
    },
  });
}
