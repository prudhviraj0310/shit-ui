import { NextResponse } from 'next/server';
import { validateApiAuth } from '@/server/auth';
import { getCollabManager } from '@/core/collaboration/realtime';

export async function GET(request: Request) {
  const auth = validateApiAuth(request);
  if (!auth.authorized) return auth.errorResponse!;

  const { searchParams } = new URL(request.url);
  const dsId = searchParams.get('designSystemId') || 'ds-nova-design';

  const manager = getCollabManager();
  const room = manager.getOrCreateRoom(dsId);
  const state = room.getState();

  return NextResponse.json({
    success: true,
    room: { id: room.id, designSystemId: room.designSystemId },
    ...state,
    rooms: manager.listRooms(),
  });
}

export async function POST(request: Request) {
  try {
    const auth = validateApiAuth(request);
    if (!auth.authorized) return auth.errorResponse!;

    const body = await request.json();
    const { action, designSystemId = 'ds-nova-design', userId, ...payload } = body;

    const manager = getCollabManager();
    const room = manager.getOrCreateRoom(designSystemId);

    switch (action) {
      case 'join': {
        const user = room.join({ id: userId || auth.userId, name: payload.name || 'User', email: payload.email || '' });
        return NextResponse.json({ success: true, user, state: room.getState() });
      }
      case 'leave': {
        room.leave(userId || auth.userId);
        return NextResponse.json({ success: true, state: room.getState() });
      }
      case 'cursor': {
        room.updateCursor(userId || auth.userId, payload.cursor);
        return NextResponse.json({ success: true });
      }
      case 'operation': {
        const result = room.applyOperation({
          type: payload.operationType || 'update',
          path: payload.path,
          value: payload.value,
          previousValue: payload.previousValue,
          userId: userId || auth.userId,
          timestamp: Date.now(),
        });
        return NextResponse.json({ success: true, version: result.version, transformed: result.transformed });
      }
      case 'lock': {
        const lock = room.acquireLock(userId || auth.userId, payload.resourceType, payload.resourceId, payload.ttlMs);
        return NextResponse.json({ success: !!lock, lock });
      }
      case 'unlock': {
        const released = room.releaseLock(userId || auth.userId, payload.resourceType, payload.resourceId);
        return NextResponse.json({ success: released });
      }
      default:
        return NextResponse.json({ success: false, error: `Unknown action: ${action}` }, { status: 400 });
    }
  } catch (err: any) {
    return NextResponse.json({ success: false, error: err.message }, { status: 500 });
  }
}
