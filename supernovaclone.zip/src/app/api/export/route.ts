import { NextResponse } from 'next/server';
import { getDb } from '@/db/index';
import { tokens, designSystemVersions } from '@/db/schema';
import { FlatToken } from '@/core/tokens/types';
import { exportToCss } from '@/core/exporters/css';
import { exportToJson } from '@/core/exporters/json';
import { exportToTypeScript } from '@/core/exporters/typescript';
import { exportToTailwind, exportToTailwindV4 } from '@/core/exporters/tailwind';
import { exportToSwift } from '@/core/exporters/swift';
import { exportToKotlin } from '@/core/exporters/kotlin';
import { validateApiAuth } from '@/server/auth';
import { authorizeDesignSystem } from '@/server/governance';
import { createHash } from 'node:crypto';
import { eq, and, desc } from 'drizzle-orm';

function fileManifest(file: { filename: string; content: string; format: string; warnings?: string[] }) {
  return {
    filename: file.filename,
    format: file.format,
    sha256: createHash('sha256').update(file.content).digest('hex'),
    bytes: Buffer.byteLength(file.content, 'utf8'),
    warnings: file.warnings || [],
  };
}

/**
 * Resolves the target versionId for export: uses explicit versionId param,
 * falls back to latest draft, then falls back to latest version by creation date.
 */
async function resolveExportVersionId(db: any, designSystemId: string, explicitVersionId?: string | null): Promise<string | null> {
  if (explicitVersionId) return explicitVersionId;

  // Prefer draft version
  const drafts = await db
    .select({ id: designSystemVersions.id })
    .from(designSystemVersions)
    .where(
      and(
        eq(designSystemVersions.designSystemId, designSystemId),
        eq(designSystemVersions.isDraft, true)
      )
    );
  if (drafts.length > 0) return drafts[0].id;

  // Fallback: latest version by creation date
  const latest = await db
    .select({ id: designSystemVersions.id })
    .from(designSystemVersions)
    .where(eq(designSystemVersions.designSystemId, designSystemId))
    .orderBy(desc(designSystemVersions.createdAt))
    .limit(1);
  if (latest.length > 0) return latest[0].id;

  return null;
}

export async function GET(request: Request) {
  try {
    const auth = validateApiAuth(request);
    if (!auth.authorized) return auth.errorResponse!;
    const { searchParams } = new URL(request.url);
    const format = searchParams.get('format') || 'all';
    const prefix = searchParams.get('prefix') || 'nova';
    const themeMode = (searchParams.get('themeMode') as any) || 'both';

    const { db } = await getDb();
    const designSystemId = searchParams.get('designSystemId') || 'ds-nova-design';
    await authorizeDesignSystem(db, auth.userId, designSystemId);

    const versionId = await resolveExportVersionId(db, designSystemId, searchParams.get('versionId'));
    const dbTokens = await db.select().from(tokens);
    const scopedTokens = dbTokens.filter((token: any) =>
      token.designSystemId === designSystemId &&
      (!versionId || token.versionId === versionId)
    );

    const flatTokens: FlatToken[] = scopedTokens.map((t: any) => ({
      name: t.name,
      path: t.path,
      category: t.category,
      type: t.type,
      rawValue: t.rawValue,
      resolvedValue: t.resolvedValue,
      isAlias: t.isAlias,
      aliasTarget: t.aliasTarget || undefined,
      isDeprecated: t.isDeprecated,
      description: t.description || undefined,
    }));

    const css = exportToCss(flatTokens, { prefix, themeMode });
    const json = exportToJson(flatTokens);
    const ts = exportToTypeScript(flatTokens);
    const tw = exportToTailwind(flatTokens, { prefix });
    const tw4 = exportToTailwindV4(flatTokens, { prefix });
    const swift = exportToSwift(flatTokens);
    const kotlin = exportToKotlin(flatTokens);

    if (format === 'css') return NextResponse.json(css);
    if (format === 'json') return NextResponse.json(json);
    if (format === 'typescript') return NextResponse.json(ts);
    if (format === 'tailwind' || format === 'tailwind-v3') return NextResponse.json(tw);
    if (format === 'tailwind4' || format === 'tailwind-v4') return NextResponse.json(tw4);
    if (format === 'swift') return NextResponse.json(swift);
    if (format === 'kotlin') return NextResponse.json(kotlin);

    return NextResponse.json({
      success: true,
      designSystemId,
      generatedAt: new Date().toISOString(),
      sourceTokenCount: flatTokens.length,
      mobile: {
        status: 'generated',
        warnings: [],
      },
      files: {
        css,
        json,
        typescript: ts,
        tailwind: tw,
        tailwindV4: tw4,
        swift,
        kotlin,
      },
      manifest: [
        fileManifest(css),
        fileManifest(json),
        fileManifest(ts),
        fileManifest(tw),
        fileManifest(tw4),
        fileManifest(swift),
        fileManifest(kotlin),
      ],
    });
  } catch (err: any) {
    return NextResponse.json({ success: false, error: err.message }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const auth = validateApiAuth(request);
    if (!auth.authorized) return auth.errorResponse!;

    const body = await request.json().catch(() => ({}));
    const { searchParams } = new URL(request.url);

    const format = body.format || searchParams.get('format') || 'all';
    const prefix = body.prefix || searchParams.get('prefix') || 'nova';
    const themeMode = (body.themeMode || searchParams.get('themeMode') as any) || 'both';
    const designSystemId = body.designSystemId || searchParams.get('designSystemId') || 'ds-nova-design';

    const { db } = await getDb();
    await authorizeDesignSystem(db, auth.userId, designSystemId);

    let flatTokens: FlatToken[];
    if (Array.isArray(body.tokens) && body.tokens.length > 0) {
      flatTokens = body.tokens;
    } else {
      const versionId = await resolveExportVersionId(db, designSystemId, body.versionId || searchParams.get('versionId'));
      const dbTokens = await db.select().from(tokens);
      const scopedTokens = dbTokens.filter((token: any) =>
        token.designSystemId === designSystemId &&
        (!versionId || token.versionId === versionId)
      );
      flatTokens = scopedTokens.map((t: any) => ({
        name: t.name,
        path: t.path,
        category: t.category,
        type: t.type,
        rawValue: t.rawValue,
        resolvedValue: t.resolvedValue,
        isAlias: t.isAlias,
        aliasTarget: t.aliasTarget || undefined,
        isDeprecated: t.isDeprecated,
        description: t.description || undefined,
      }));
    }

    const css = exportToCss(flatTokens, { prefix, themeMode });
    const json = exportToJson(flatTokens);
    const ts = exportToTypeScript(flatTokens);
    const tw = exportToTailwind(flatTokens, { prefix });
    const tw4 = exportToTailwindV4(flatTokens, { prefix });
    const swift = exportToSwift(flatTokens);
    const kotlin = exportToKotlin(flatTokens);

    if (format === 'css') return NextResponse.json(css);
    if (format === 'json') return NextResponse.json(json);
    if (format === 'typescript') return NextResponse.json(ts);
    if (format === 'tailwind' || format === 'tailwind-v3') return NextResponse.json(tw);
    if (format === 'tailwind4' || format === 'tailwind-v4') return NextResponse.json(tw4);
    if (format === 'swift') return NextResponse.json(swift);
    if (format === 'kotlin') return NextResponse.json(kotlin);

    return NextResponse.json({
      success: true,
      designSystemId,
      generatedAt: new Date().toISOString(),
      sourceTokenCount: flatTokens.length,
      mobile: {
        status: 'generated',
        warnings: [],
      },
      files: {
        css,
        json,
        typescript: ts,
        tailwind: tw,
        tailwindV4: tw4,
        swift,
        kotlin,
      },
      manifest: [
        fileManifest(css),
        fileManifest(json),
        fileManifest(ts),
        fileManifest(tw),
        fileManifest(tw4),
        fileManifest(swift),
        fileManifest(kotlin),
      ],
    });
  } catch (err: any) {
    return NextResponse.json({ success: false, error: err.message }, { status: 500 });
  }
}

