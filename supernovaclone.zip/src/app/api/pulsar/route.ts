import { NextResponse } from 'next/server';
import { validateApiAuth } from '@/server/auth';
import { getDb } from '@/db/index';
import { tokens } from '@/db/schema';
import { getPulsarEngine } from '@/core/pulsar/engine';
import type { FlatToken } from '@/core/tokens/types';

export async function GET(request: Request) {
  const auth = validateApiAuth(request);
  if (!auth.authorized) return auth.errorResponse!;

  const engine = getPulsarEngine();
  return NextResponse.json({
    success: true,
    templates: engine.listTemplates().map(t => ({
      id: t.id,
      name: t.name,
      description: t.description,
      version: t.version,
      author: t.author,
      outputFileName: t.outputFileName,
      settings: t.settings || [],
    })),
  });
}

export async function POST(request: Request) {
  try {
    const auth = validateApiAuth(request);
    if (!auth.authorized) return auth.errorResponse!;

    const body = await request.json();
    const { templateId, rawTemplate, settings = {} } = body;

    // Fetch tokens from database
    const { db } = await getDb();
    const allTokens = await db.select().from(tokens);
    const flatTokens: FlatToken[] = allTokens.map((t: any) => ({
      name: t.name,
      path: t.path,
      category: t.category,
      type: t.type,
      rawValue: t.rawValue,
      resolvedValue: t.resolvedValue || t.rawValue,
      isAlias: t.isAlias || false,
      aliasTarget: t.aliasTarget || undefined,
      description: t.description || undefined,
    }));

    const engine = getPulsarEngine();

    let result;
    if (rawTemplate) {
      result = engine.executeRaw(rawTemplate, flatTokens, settings);
    } else if (templateId) {
      result = engine.execute(templateId, flatTokens, settings);
    } else {
      return NextResponse.json({ success: false, error: 'Provide either templateId or rawTemplate' }, { status: 400 });
    }

    return NextResponse.json({
      success: result.success,
      output: result.output,
      fileName: result.fileName,
      errors: result.errors,
      warnings: result.warnings,
      stats: result.stats,
    });
  } catch (err: any) {
    return NextResponse.json({ success: false, error: err.message }, { status: 500 });
  }
}
