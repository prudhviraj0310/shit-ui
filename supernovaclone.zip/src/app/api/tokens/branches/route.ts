import { NextResponse } from 'next/server';
import { getDb } from '@/db/index';
import { TokenBranchManager } from '@/core/tokens/branching';
import { validateApiAuth } from '@/server/auth';

export async function GET(request: Request) {
  const auth = validateApiAuth(request);
  if (!auth.authorized) {
    return auth.errorResponse || NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  try {
    const url = new URL(request.url);
    const designSystemId = url.searchParams.get('designSystemId') || 'ds-nova-design';

    const { db } = await getDb();
    const manager = new TokenBranchManager(db);
    const branches = await manager.listBranches(designSystemId);

    return NextResponse.json({ success: true, branches });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}

export async function POST(request: Request) {
  const auth = validateApiAuth(request);
  if (!auth.authorized) {
    return auth.errorResponse || NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  try {
    const body = await request.json().catch(() => ({}));
    const { designSystemId = 'ds-nova-design', branchName, description, baseVersion } = body;

    if (!branchName) {
      return NextResponse.json({ success: false, error: 'branchName is required.' }, { status: 400 });
    }

    const { db } = await getDb();
    const manager = new TokenBranchManager(db);
    const result = await manager.createBranch(designSystemId, branchName, description, baseVersion);

    return NextResponse.json({ success: true, ...result }, { status: 201 });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}
