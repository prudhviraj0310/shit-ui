import { NextResponse } from 'next/server';
import { getDb } from '@/db/index';
import { TokenBranchManager } from '@/core/tokens/branching';
import { validateApiAuth } from '@/server/auth';

export async function GET(request: Request) {
  const auth = validateApiAuth(request);
  if (!auth.authorized) {
    return auth.errorResponse || NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  try {
    const url = new URL(request.url);
    const designSystemId = url.searchParams.get('designSystemId') || 'ds-nova-design';
    const source = url.searchParams.get('source');
    const target = url.searchParams.get('target') || 'Draft';

    if (!source) {
      return NextResponse.json({ success: false, error: 'source branch name is required for diff.' }, { status: 400 });
    }

    const { db } = await getDb();
    const manager = new TokenBranchManager(db);
    const diff = await manager.diffBranches(designSystemId, source, target);

    return NextResponse.json({ success: true, diff });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}

export async function POST(request: Request) {
  const auth = validateApiAuth(request);
  if (!auth.authorized) {
    return auth.errorResponse || NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  try {
    const body = await request.json().catch(() => ({}));
    const { designSystemId = 'ds-nova-design', source, target = 'Draft', deleteAfterMerge = false } = body;

    if (!source) {
      return NextResponse.json({ success: false, error: 'source branch is required to merge.' }, { status: 400 });
    }

    const { db } = await getDb();
    const manager = new TokenBranchManager(db);
    const result = await manager.mergeBranch(designSystemId, source, target, deleteAfterMerge);

    return NextResponse.json({ success: true, ...result });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}
