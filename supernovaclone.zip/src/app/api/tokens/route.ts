import { NextResponse } from 'next/server';
import { getDb } from '@/db/index';
import { tokens, designSystemVersions } from '@/db/schema';
import { seedDatabase } from '@/db/seed';
import { eq, and, desc } from 'drizzle-orm';
import { validateTokens } from '@/core/tokens/validator';
import { FlatToken } from '@/core/tokens/types';
import { validateApiAuth } from '@/server/auth';
import { authorizeDesignSystem } from '@/server/governance';

async function resolveVersionId(db: any, designSystemId: string, explicit?: string | null): Promise<string | null> {
  if (explicit) return explicit;
  const drafts = await db
    .select({ id: designSystemVersions.id })
    .from(designSystemVersions)
    .where(and(eq(designSystemVersions.designSystemId, designSystemId), eq(designSystemVersions.isDraft, true)));
  if (drafts.length > 0) return drafts[0].id;
  const latest = await db
    .select({ id: designSystemVersions.id })
    .from(designSystemVersions)
    .where(eq(designSystemVersions.designSystemId, designSystemId))
    .orderBy(desc(designSystemVersions.createdAt))
    .limit(1);
  return latest.length > 0 ? latest[0].id : null;
}

export async function GET(request: Request) {
  try {
    const auth = validateApiAuth(request);
    if (!auth.authorized) return auth.errorResponse!;
    const { searchParams } = new URL(request.url);
    const category = searchParams.get('category');
    const dsId = searchParams.get('designSystemId') || searchParams.get('ds');

    const { db } = await getDb();
    const targetDs = dsId || 'ds-nova-design';
    await authorizeDesignSystem(db, auth.userId, targetDs);
    let allTokens = await db.select().from(tokens);

    if (allTokens.length === 0) {
      await seedDatabase();
      allTokens = await db.select().from(tokens);
    }

    const versionId = await resolveVersionId(db, targetDs, searchParams.get('versionId'));
    let filtered = allTokens;
    filtered = filtered.filter((t: any) =>
      t.designSystemId === targetDs &&
      (!versionId || t.versionId === versionId)
    );
    if (category && category !== 'all') {
      filtered = filtered.filter((t: any) => t.category === category);
    }

    return NextResponse.json({
      success: true,
      totalCount: allTokens.length,
      filteredCount: filtered.length,
      versionId: versionId || 'all',
      tokens: filtered,
    });
  } catch (err: any) {
    return NextResponse.json({ success: false, error: err.message }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const auth = validateApiAuth(request);
    if (!auth.authorized) return auth.errorResponse!;

    const body = await request.json();
    const {
      path,
      name,
      category,
      type = 'color',
      rawValue,
      description,
      isDeprecated = false,
      designSystemId = 'ds-nova-design',
    } = body;

    if (!path || !rawValue || !category) {
      return NextResponse.json(
        { success: false, error: 'path, rawValue, and category are required' },
        { status: 400 }
      );
    }

    const isAlias = rawValue.startsWith('{') && rawValue.endsWith('}');
    const aliasTarget = isAlias ? rawValue.slice(1, -1).trim() : null;

    const { db } = await getDb();
    await authorizeDesignSystem(db, auth.userId, designSystemId);
    const tokenId = `tok-${path.replace(/\./g, '-')}`;

    // Validate token format
    const tempToken: FlatToken = {
      name: name || path.split('.').pop() || path,
      path,
      category,
      type,
      rawValue,
      resolvedValue: rawValue,
      isAlias,
      aliasTarget: aliasTarget || undefined,
    };

    const validation = validateTokens([tempToken]);
    if (!validation.valid && !isAlias) {
      return NextResponse.json(
        { success: false, error: validation.errors[0].message },
        { status: 400 }
      );
    }

    const persistentId = body.persistentId || `pid-${path.replace(/\./g, '-')}`;
    const versionId = body.versionId || `ver-draft-${designSystemId}`;
    const brandId = body.brandId || `brand-default-${designSystemId}`;
    const originSourceId = body.originSourceId || null;

    await db
      .insert(tokens)
      .values({
        id: tokenId,
        persistentId,
        designSystemId,
        versionId,
        brandId,
        originSourceId,
        name: tempToken.name,
        path,
        category,
        type,
        rawValue,
        resolvedValue: rawValue,
        isAlias,
        aliasTarget,
        isDeprecated,
        description: description || null,
      })
      .onConflictDoUpdate({
        target: tokens.id,
        set: {
          rawValue,
          resolvedValue: rawValue,
          isAlias,
          aliasTarget,
          category,
          type,
          isDeprecated,
          description: description || null,
        },
      });

    return NextResponse.json({
      success: true,
      token: tempToken,
    });
  } catch (err: any) {
    return NextResponse.json({ success: false, error: err.message }, { status: 500 });
  }
}

export async function DELETE(request: Request) {
  try {
    const auth = validateApiAuth(request);
    if (!auth.authorized) return auth.errorResponse!;

    const { searchParams } = new URL(request.url);
    const tokenId = searchParams.get('id');

    if (!tokenId) {
      return NextResponse.json({ success: false, error: 'Token ID required' }, { status: 400 });
    }

    const { db } = await getDb();
    const target = await db.select().from(tokens).where(eq(tokens.id, tokenId)).limit(1);
    if (!target[0]) return NextResponse.json({ success: false, error: 'Token not found' }, { status: 404 });
    await authorizeDesignSystem(db, auth.userId, target[0].designSystemId);
    await db.delete(tokens).where(eq(tokens.id, tokenId));

    return NextResponse.json({ success: true, deletedId: tokenId });
  } catch (err: any) {
    return NextResponse.json({ success: false, error: err.message }, { status: 500 });
  }
}
