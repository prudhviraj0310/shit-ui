import { NextResponse } from 'next/server';
import { getDb } from '@/db/index';
import { UniversalSearchEngine } from '@/core/search/engine';
import { validateApiAuth } from '@/server/auth';

export async function GET(request: Request) {
  const auth = validateApiAuth(request);
  if (!auth.authorized) {
    return auth.errorResponse || NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  try {
    const url = new URL(request.url);
    const query = url.searchParams.get('q') || '';
    const limit = Number(url.searchParams.get('limit') || 25);

    const { db } = await getDb();
    const searchEngine = new UniversalSearchEngine(db);
    const results = await searchEngine.search(query, limit);

    return NextResponse.json({ success: true, count: results.length, results });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}
