import { NextResponse } from 'next/server';
import { getDb } from '@/db/index';
import { CommentsManager } from '@/core/comments/engine';
import { validateApiAuth } from '@/server/auth';

export async function GET(request: Request) {
  const auth = validateApiAuth(request);
  if (!auth.authorized) {
    return auth.errorResponse || NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  try {
    const url = new URL(request.url);
    const targetType = url.searchParams.get('targetType') || undefined;
    const targetId = url.searchParams.get('targetId') || undefined;

    const { db } = await getDb();
    const manager = new CommentsManager(db);
    const comments = await manager.listComments(targetType, targetId);

    return NextResponse.json({ success: true, count: comments.length, comments });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}

export async function POST(request: Request) {
  const auth = validateApiAuth(request);
  if (!auth.authorized) {
    return auth.errorResponse || NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  try {
    const body = await request.json().catch(() => ({}));
    const { action, commentId, author, body: commentBody, targetType, targetId, targetTitle, status } = body;

    const { db } = await getDb();
    const manager = new CommentsManager(db);

    if (action === 'reply') {
      if (!commentId || !commentBody) {
        return NextResponse.json({ success: false, error: 'commentId and body are required for reply.' }, { status: 400 });
      }
      const reply = await manager.addReply(commentId, author || 'Team Member', commentBody);
      return NextResponse.json({ success: true, reply });
    }

    if (action === 'resolve' || status) {
      if (!commentId) {
        return NextResponse.json({ success: false, error: 'commentId is required.' }, { status: 400 });
      }
      const res = await manager.toggleResolve(commentId, status || 'resolved');
      return NextResponse.json({ success: true, ...res });
    }

    // Default: create new comment thread
    if (!commentBody) {
      return NextResponse.json({ success: false, error: 'body is required for comment.' }, { status: 400 });
    }

    const created = await manager.addComment({
      targetType: targetType || 'general',
      targetId: targetId || 'general',
      targetTitle: targetTitle || 'General Feedback',
      author: author || 'Design Lead',
      body: commentBody,
    });

    return NextResponse.json({ success: true, comment: created }, { status: 201 });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}
