import { NextResponse } from 'next/server';
import { validateApiAuth } from '@/server/auth';
import { OAuthProvider, SAMLProvider, MagicLinkProvider, PROVIDER_METADATA, getSessionManager } from '@/core/auth/sso';

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const action = searchParams.get('action');

  // Public: List available SSO providers
  if (action === 'providers') {
    return NextResponse.json({
      success: true,
      providers: Object.values(PROVIDER_METADATA).map(p => ({
        id: p.provider,
        name: p.displayName,
        icon: p.icon,
      })),
    });
  }

  // Public: OAuth callback handler
  if (action === 'callback') {
    const provider = searchParams.get('provider');
    const code = searchParams.get('code');
    const state = searchParams.get('state');

    if (!code || !provider) {
      return NextResponse.json({ success: false, error: 'Missing code or provider' }, { status: 400 });
    }

    try {
      const config = {
        provider: provider as any,
        clientId: process.env[`${provider.toUpperCase()}_CLIENT_ID`] || '',
        clientSecret: process.env[`${provider.toUpperCase()}_CLIENT_SECRET`] || '',
        redirectUri: `${process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000'}/api/sso?action=callback&provider=${provider}`,
      };

      const oauth = new OAuthProvider(config);
      const tokenData = await oauth.exchangeCode(code);
      const userInfo = await oauth.getUserInfo(tokenData.accessToken);

      const sessionMgr = getSessionManager();
      const session = sessionMgr.createSession({
        userId: `user-${userInfo.providerId}`,
        provider: provider as any,
        email: userInfo.email,
        displayName: userInfo.name,
        avatarUrl: userInfo.avatar,
        accessToken: tokenData.accessToken,
        refreshToken: tokenData.refreshToken,
        expiresAt: Date.now() + tokenData.expiresIn * 1000,
        workspaceId: 'ws-default',
        role: 'member',
        metadata: { state },
      });

      // Redirect to app with session token
      const redirectUrl = `${process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000'}/?session=${session.id}`;
      return NextResponse.redirect(redirectUrl);
    } catch (err: any) {
      return NextResponse.json({ success: false, error: err.message }, { status: 500 });
    }
  }

  // Authenticated: List active sessions
  const auth = validateApiAuth(request);
  if (!auth.authorized) return auth.errorResponse!;

  const sessionMgr = getSessionManager();
  return NextResponse.json({
    success: true,
    sessions: sessionMgr.listActiveSessions(auth.userId),
  });
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { action, provider, email } = body;

    switch (action) {
      case 'initiate': {
        // Generate OAuth authorization URL
        if (!provider) return NextResponse.json({ success: false, error: 'Provider required' }, { status: 400 });

        const config = {
          provider,
          clientId: process.env[`${provider.toUpperCase()}_CLIENT_ID`] || 'placeholder',
          clientSecret: process.env[`${provider.toUpperCase()}_CLIENT_SECRET`] || '',
          redirectUri: `${process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000'}/api/sso?action=callback&provider=${provider}`,
        };

        const oauth = new OAuthProvider(config);
        const state = Math.random().toString(36).slice(2);
        const authUrl = oauth.getAuthorizationUrl(state);

        return NextResponse.json({ success: true, authUrl, state });
      }

      case 'magic-link': {
        // Generate magic link
        if (!email) return NextResponse.json({ success: false, error: 'Email required' }, { status: 400 });

        const secret = process.env.AUTH_SECRET || 'nexus-magic-link-secret';
        const magic = new MagicLinkProvider(secret);
        const { token, expiresAt } = magic.generateToken(email);
        const magicUrl = `${process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000'}/api/sso?action=callback&provider=magic_link&code=${token}`;

        return NextResponse.json({ success: true, magicUrl, expiresAt, message: 'Magic link generated (in production, this would be emailed)' });
      }

      case 'verify-magic': {
        const { token } = body;
        if (!token) return NextResponse.json({ success: false, error: 'Token required' }, { status: 400 });

        const secret = process.env.AUTH_SECRET || 'nexus-magic-link-secret';
        const magic = new MagicLinkProvider(secret);
        const result = magic.verifyToken(token);

        if (!result.valid) return NextResponse.json({ success: false, error: result.error }, { status: 401 });

        const sessionMgr = getSessionManager();
        const session = sessionMgr.createSession({
          userId: `user-${result.email}`,
          provider: 'magic_link',
          email: result.email!,
          displayName: result.email!.split('@')[0],
          accessToken: token,
          expiresAt: Date.now() + 24 * 60 * 60 * 1000,
          workspaceId: 'ws-default',
          role: 'member',
          metadata: {},
        });

        return NextResponse.json({ success: true, session: { id: session.id, email: session.email } });
      }

      case 'logout': {
        const auth = validateApiAuth(request);
        if (!auth.authorized) return auth.errorResponse!;

        const { sessionId } = body;
        if (sessionId) {
          getSessionManager().revokeSession(sessionId);
        }
        return NextResponse.json({ success: true });
      }

      default:
        return NextResponse.json({ success: false, error: `Unknown action: ${action}` }, { status: 400 });
    }
  } catch (err: any) {
    return NextResponse.json({ success: false, error: err.message }, { status: 500 });
  }
}
