import { NextResponse } from 'next/server';
import { getDb } from '@/db/index';
import { auditEvents, designSystems, tokens } from '@/db/schema';
import { eq } from 'drizzle-orm';
import { pushVariablesToFigma } from '@/core/figma/push';
import { FlatToken } from '@/core/tokens/types';
import { validateApiAuth } from '@/server/auth';
import { authorizeDesignSystem } from '@/server/governance';
import crypto from 'crypto';

export async function POST(request: Request) {
  try {
    const auth = validateApiAuth(request);
    if (!auth.authorized) return auth.errorResponse!;

    const body = await request.json();
    const fileKey = body.fileKey || 'figma-sample-file-key';
    const figmaToken = body.figmaToken || body.personalAccessToken || process.env.FIGMA_TOKEN || '';
    const designSystemId = body.designSystemId || 'ds-nova-design';
    const dryRun = Boolean(body.dryRun);
    const collectionName = body.collectionName || 'Nexus Design OS';

    const { db } = await getDb();

    // Authorize access to design system
    const [designSystem] = await db
      .select({ id: designSystems.id })
      .from(designSystems)
      .where(eq(designSystems.id, designSystemId))
      .limit(1);

    if (designSystem) {
      await authorizeDesignSystem(db, auth.userId, designSystemId);
    }

    // Determine tokens to push: either provided in body or fetched from database draft
    let tokensToPush: FlatToken[] = [];
    if (Array.isArray(body.tokens) && body.tokens.length > 0) {
      tokensToPush = body.tokens;
    } else {
      const dbTokens = await db
        .select()
        .from(tokens)
        .where(eq(tokens.designSystemId, designSystemId));

      tokensToPush = dbTokens.map((t: any) => ({
        id: t.id,
        persistentId: t.persistentId || t.id,
        name: t.name,
        path: t.path,
        category: t.category,
        type: t.type,
        rawValue: t.rawValue,
        resolvedValue: t.resolvedValue ?? t.rawValue,
        description: t.description || undefined,
      }));
    }

    if (tokensToPush.length === 0) {
      return NextResponse.json(
        {
          success: false,
          error: 'No tokens found to push to Figma. Please ensure the design system has tokens.',
        },
        { status: 400 }
      );
    }

    // Execute Figma Variables Push
    const result = await pushVariablesToFigma(fileKey, tokensToPush, figmaToken, {
      dryRun,
      collectionName,
    });

    // Record Audit Event in database
    try {
      await db.insert(auditEvents).values({
        id: `audit-${crypto.randomUUID()}`,
        workspaceId: 'ws-default',
        actorUserId: auth.userId || 'usr-anonymous',
        action: dryRun ? 'figma.variables.push.dry_run' : 'figma.variables.push',

        resourceType: 'figma_file',
        resourceId: fileKey,
        metadata: {
          designSystemId,
          fileKey,
          tokensCount: tokensToPush.length,
          createdCount: result.createdCount,
          updatedCount: result.updatedCount,
          dryRun,
          timestamp: new Date().toISOString(),
        },
        createdAt: new Date(),
      });
    } catch {
      // Non-fatal if audit logging fails
    }

    return NextResponse.json({
      success: true,
      fileKey,
      designSystemId,
      pushedCount: result.pushedCount,
      createdCount: result.createdCount,
      updatedCount: result.updatedCount,
      dryRun,
      payloadSummary: {
        collections: result.payload.variableCollections?.length || 0,
        modes: result.payload.variableModes?.length || 0,
        variables: result.payload.variables?.length || 0,
        modeValues: result.payload.variableModeValues?.length || 0,
      },
      meta: result.meta,
    });
  } catch (error: any) {
    return NextResponse.json(
      {
        success: false,
        error: error.message || 'Failed to push variables to Figma.',
      },
      { status: 500 }
    );
  }
}
