import { NextResponse } from 'next/server';
import { getDb } from '@/db/index';
import { VersionManager } from '@/core/versions/version-manager';
import { validateApiAuth } from '@/server/auth';

export async function POST(request: Request) {
  const auth = validateApiAuth(request);
  if (!auth.authorized) {
    return auth.errorResponse || NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  try {
    const body = await request.json().catch(() => ({}));
    const { designSystemId = 'ds-nova-design', targetVersionIdOrName } = body;

    if (!targetVersionIdOrName) {
      return NextResponse.json(
        { success: false, error: 'targetVersionIdOrName is required (e.g., "1.0.0" or version ID).' },
        { status: 400 }
      );
    }

    const { db } = await getDb();
    const versionManager = new VersionManager(db);
    const result = await versionManager.rollbackToVersion(designSystemId, targetVersionIdOrName);

    return NextResponse.json({
      success: true,
      message: `Successfully rolled back active draft to version "${targetVersionIdOrName}"`,
      ...result,
    });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}
