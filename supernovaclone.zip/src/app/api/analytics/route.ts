import { NextResponse } from 'next/server';
import { validateApiAuth } from '@/server/auth';
import { getAnalyticsEngine } from '@/core/analytics/engine';

export async function GET(request: Request) {
  const auth = validateApiAuth(request);
  if (!auth.authorized) return auth.errorResponse!;

  const { searchParams } = new URL(request.url);
  const dsId = searchParams.get('designSystemId') || 'ds-nova-design';
  const wsId = searchParams.get('workspaceId') || 'ws-acme-corp';
  const view = searchParams.get('view') || 'dashboard';

  const engine = getAnalyticsEngine();

  switch (view) {
    case 'dashboard':
      return NextResponse.json({ success: true, data: engine.getDashboard(wsId, dsId) });
    case 'adoption':
      return NextResponse.json({ success: true, data: engine.getAdoptionMetrics(wsId, dsId) });
    case 'exports':
      return NextResponse.json({ success: true, data: engine.getTimeSeries(dsId, 'export_generated') });
    case 'tokens':
      return NextResponse.json({ success: true, data: engine.getTimeSeries(dsId, 'token_created') });
    case 'compliance':
      return NextResponse.json({ success: true, data: engine.getTimeSeries(dsId, 'compliance_check') });
    default:
      return NextResponse.json({ success: true, data: engine.getDashboard(wsId, dsId) });
  }
}

export async function POST(request: Request) {
  try {
    const auth = validateApiAuth(request);
    if (!auth.authorized) return auth.errorResponse!;

    const body = await request.json();
    const { type, workspaceId = 'ws-acme-corp', designSystemId = 'ds-nova-design', metadata = {} } = body;

    if (!type) {
      return NextResponse.json({ success: false, error: 'Event type required' }, { status: 400 });
    }

    const engine = getAnalyticsEngine();
    engine.track(type, { userId: auth.userId, workspaceId, designSystemId, metadata });

    return NextResponse.json({
      success: true,
      tracked: true,
      totalEvents: engine.getEventCount(),
    });
  } catch (err: any) {
    return NextResponse.json({ success: false, error: err.message }, { status: 500 });
  }
}
