import { NextResponse } from 'next/server';
import { getDb } from '@/db/index';
import { validateApiAuth } from '@/server/auth';
import { parseStorybookIndex, linkStorybookToComponents } from '@/core/components/storybook';

// Sample fixture Storybook CSF3 index for demonstration and testing
export const sampleStorybookCSF3Index = {
  v: 4,
  entries: {
    'components-button--primary': {
      id: 'components-button--primary',
      title: 'Components/Button',
      name: 'Primary',
      importPath: './src/components/Button.stories.tsx',
      type: 'story',
      tags: ['autodocs', 'story'],
      args: {
        variant: 'primary',
        size: 'medium',
        label: 'Primary Button',
        disabled: false,
      },
      argTypes: {
        variant: { control: { type: 'select' }, options: ['primary', 'secondary', 'destructive', 'ghost'] },
        size: { control: { type: 'radio' }, options: ['small', 'medium', 'large'] },
        disabled: { control: { type: 'boolean' } },
        label: { control: { type: 'text' } },
      },
      parameters: {
        docs: { description: { story: 'The primary call to action button in Nexus Design OS.' } },
      },
    },
    'components-button--secondary': {
      id: 'components-button--secondary',
      title: 'Components/Button',
      name: 'Secondary',
      importPath: './src/components/Button.stories.tsx',
      type: 'story',
      tags: ['story'],
      args: {
        variant: 'secondary',
        size: 'medium',
        label: 'Secondary Action',
        disabled: false,
      },
    },
    'components-badge--status': {
      id: 'components-badge--status',
      title: 'Components/Badge',
      name: 'Status Badge',
      importPath: './src/components/Badge.stories.tsx',
      type: 'story',
      tags: ['story'],
      args: {
        variant: 'success',
        text: 'Live in Production',
      },
    },
    'components-card--elevated': {
      id: 'components-card--elevated',
      title: 'Components/Card',
      name: 'Elevated Card',
      importPath: './src/components/Card.stories.tsx',
      type: 'story',
      tags: ['story'],
      args: {
        elevation: 'high',
        title: 'Nexus Card Title',
        bordered: true,
      },
    },
  },
};

export async function GET(request: Request) {
  const auth = validateApiAuth(request);
  if (!auth.authorized) return auth.errorResponse!;

  const url = new URL(request.url);
  const baseUrl = url.searchParams.get('baseUrl') || 'https://storybook.nexusdesign.dev';

  const parsed = await parseStorybookIndex(JSON.stringify(sampleStorybookCSF3Index), baseUrl);
  return NextResponse.json({
    success: true,
    data: parsed,
  });
}

export async function POST(request: Request) {
  try {
    const auth = validateApiAuth(request);
    if (!auth.authorized) return auth.errorResponse!;

    const body = await request.json();
    const content = body.storiesJsonUrlOrContent || JSON.stringify(sampleStorybookCSF3Index);
    const storybookBaseUrl = body.storybookBaseUrl || body.baseUrl;
    const designSystemId = body.designSystemId || 'ds-nova-design';
    const linkToCatalog = Boolean(body.linkToCatalog !== false);

    const parsed = await parseStorybookIndex(content, storybookBaseUrl);

    let linkResult = null;
    if (linkToCatalog) {
      const { db } = await getDb();
      linkResult = await linkStorybookToComponents(db, designSystemId, parsed, storybookBaseUrl);
    }

    return NextResponse.json({
      success: true,
      totalStories: parsed.totalStories,
      totalComponents: parsed.totalComponents,
      components: parsed.components,
      stories: parsed.stories,
      linkResult,
    });
  } catch (error: any) {
    return NextResponse.json(
      {
        success: false,
        error: error.message || 'Failed to process Storybook index.',
      },
      { status: 500 }
    );
  }
}
