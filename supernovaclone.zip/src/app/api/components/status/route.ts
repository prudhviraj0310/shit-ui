import { NextResponse } from 'next/server';
import { getDb } from '@/db/index';
import { ComponentStatusManager, ComponentLifecycleStatus } from '@/core/components/status';
import { validateApiAuth } from '@/server/auth';

export async function GET(request: Request) {
  const auth = validateApiAuth(request);
  if (!auth.authorized) {
    return auth.errorResponse || NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  try {
    const url = new URL(request.url);
    const designSystemId = url.searchParams.get('designSystemId') || 'ds-nova-design';

    const { db } = await getDb();
    const manager = new ComponentStatusManager(db);
    const data = await manager.getBoardData(designSystemId);

    return NextResponse.json({ success: true, ...data });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}

export async function POST(request: Request) {
  const auth = validateApiAuth(request);
  if (!auth.authorized) {
    return auth.errorResponse || NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  try {
    const body = await request.json().catch(() => ({}));
    const { action, componentId, status, name, category, framework, description, designSystemId } = body;

    const { db } = await getDb();
    const manager = new ComponentStatusManager(db);

    if (action === 'update' || status && componentId) {
      if (!componentId || !status) {
        return NextResponse.json({ success: false, error: 'componentId and status are required.' }, { status: 400 });
      }
      const result = await manager.updateStatus(componentId, status as ComponentLifecycleStatus);
      return NextResponse.json({ success: true, ...result });
    }

    if (action === 'create' || name) {
      if (!name) {
        return NextResponse.json({ success: false, error: 'name is required to create component.' }, { status: 400 });
      }
      const result = await manager.createComponent({
        designSystemId,
        name,
        category: category || 'UI Elements',
        framework,
        status,
        description,
      });
      return NextResponse.json({ success: true, component: result }, { status: 201 });
    }

    return NextResponse.json({ success: false, error: 'Invalid action or missing parameters.' }, { status: 400 });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}
