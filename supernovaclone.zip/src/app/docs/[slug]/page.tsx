'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { useParams } from 'next/navigation';
import {
  Layers,
  Sun,
  Moon,
  ChevronDown,
  BookOpen,
  ArrowLeft,
  Share2,
  ExternalLink,
  Sparkles,
  Check,
  Tag,
  GitBranch,
} from 'lucide-react';
import { BlockCanvasRenderer } from '@/components/doc-blocks/BlockCanvasRenderer';
import { DocBlock } from '@/core/docs/types';

export default function DynamicDocPage() {
  const params = useParams();
  const slug = (params?.slug as string) || 'overview';

  const [theme, setTheme] = useState<'dark' | 'light'>('light');
  const [selectedVersion, setSelectedVersion] = useState<'Draft' | '1.0.0' | '2.0.0'>('1.0.0');
  const [copiedLink, setCopiedLink] = useState(false);

  // Sample or loaded block document content
  const [docTitle, setDocTitle] = useState<string>('Component Guidelines & Specifications');
  const [blocks, setBlocks] = useState<DocBlock[]>([
    {
      id: 'h1',
      type: 'heading',
      level: 1,
      text: slug.charAt(0).toUpperCase() + slug.slice(1).replace(/-/g, ' ') + ' Documentation',
    },
    {
      id: 'p1',
      type: 'paragraph',
      text: 'Official living documentation and interactive specifications for Nexus Design OS. All tokens and components rendered on this page are verified against active DTCG definitions and CSF3 Storybook contracts.',
    },
    {
      id: 'c1',
      type: 'callout',
      calloutType: 'info',
      title: 'Living Contract',
      text: 'Changes made to tokens in draft branches or pushed to Figma will automatically update the interactive blocks on this page in real time.',
    },
    {
      id: 'h-dodont',
      type: 'heading',
      level: 2,
      text: 'Usage Guidelines & Best Practices',
    },
    {
      id: 'dodont1',
      type: 'do_dont',
      title: 'Color Contrast & Token Application',
      doItem: {
        title: 'Use Semantic Color Tokens',
        text: 'Always bind UI backgrounds to semantic tokens such as color.brand.primary to ensure automatic theme switching.',
        tokenPath: 'color.brand.primary',
        tokenValue: '#06b6d4',
        code: 'const btnStyle = { background: tokens.color.brand.primary };',
      },
      dontItem: {
        title: 'Avoid Hardcoded Hex Strings',
        text: 'Do not use ad-hoc color hex codes (#00ffea) that bypass design system governance and audit checks.',
        tokenValue: '#ff0055',
        code: '<button style={{ background: "#ff0055" }} />',
      },
    },
    {
      id: 'h-playground',
      type: 'heading',
      level: 2,
      text: 'Interactive Component Canvas',
    },
    {
      id: 'play1',
      type: 'interactive_playground',
      componentName: slug.includes('button') ? 'Button' : 'InteractiveComponent',
      title: 'Live Interactive Canvas',
      defaultProps: {
        variant: 'primary',
        size: 'medium',
        disabled: false,
        children: 'Primary Action',
      },
      supportedProps: [
        { name: 'variant', type: 'select', options: ['primary', 'secondary', 'destructive', 'ghost'] },
        { name: 'size', type: 'select', options: ['small', 'medium', 'large'] },
        { name: 'disabled', type: 'boolean' },
        { name: 'children', type: 'string' },
      ],
    },
    {
      id: 'h-tokens',
      type: 'heading',
      level: 2,
      text: 'Associated Design Tokens',
    },
    {
      id: 'tok-table1',
      type: 'token_table',
      title: 'Foundation Tokens Grid',
      showSearch: true,
      showCopy: true,
    },
    {
      id: 'c-warning',
      type: 'callout',
      calloutType: 'warning',
      title: 'Accessibility Compliance',
      text: 'Ensure interactive elements maintain at least 4.5:1 contrast against the background surface under WCAG 2.1 Level AA.',
    },
    {
      id: 'h-assets',
      type: 'heading',
      level: 2,
      text: 'Vector Iconography & Assets',
    },
    {
      id: 'h-health',
      type: 'heading',
      level: 2,
      text: 'Component Parity & Quality Gates',
    },
    {
      id: 'health1',
      type: 'component_health_matrix',
      title: 'Figma vs Code Production Parity Matrix',
    },
    {
      id: 'h-mcp',
      type: 'heading',
      level: 2,
      text: 'AI Agent Context Gateway (MCP)',
    },
    {
      id: 'mcp1',
      type: 'context_mcp',
      title: 'Model Context Protocol — Agent Configuration',
      description: 'Ingest this page and associated design tokens directly into Cursor, Claude Code, or VS Code.',
      mcpUrl: 'http://localhost:3000/api/mcp',
      showCodeSnippet: true,
    },
  ]);

  // Extract table of contents from headings
  const toc = blocks
    .filter((b) => b.type === 'heading')
    .map((b: any) => ({
      id: b.text.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, ''),
      text: b.text,
      level: b.level,
    }));

  const copyPageLink = () => {
    if (typeof window !== 'undefined') {
      navigator.clipboard.writeText(window.location.href);
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2000);
    }
  };

  const isLight = theme === 'light';

  return (
    <div
      style={{
        minHeight: '100vh',
        background: isLight ? '#f8fafc' : '#030712',
        color: isLight ? '#0f172a' : '#f8fafc',
        fontFamily: 'Inter, system-ui, sans-serif',
        transition: 'background 0.2s ease, color 0.2s ease',
      }}
    >
      {/* Top Navigation Bar */}
      <header
        style={{
          position: 'sticky',
          top: 0,
          zIndex: 40,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          padding: '0 24px',
          height: 60,
          background: isLight ? 'rgba(255, 255, 255, 0.85)' : 'rgba(3, 7, 18, 0.85)',
          backdropFilter: 'blur(12px)',
          borderBottom: `1px solid ${isLight ? '#e2e8f0' : 'rgba(255, 255, 255, 0.08)'}`,
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
          <Link
            href="/docs"
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: 6,
              color: isLight ? '#64748b' : '#94a3b8',
              textDecoration: 'none',
              fontSize: 13,
              fontWeight: 600,
            }}
          >
            <ArrowLeft size={16} />
            <span>All Docs</span>
          </Link>

          <div style={{ width: 1, height: 18, background: isLight ? '#cbd5e1' : 'rgba(255,255,255,0.1)' }} />

          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <span style={{ fontSize: 14, fontWeight: 700 }}>Nexus Living Docs</span>
            <span
              style={{
                fontSize: 11,
                padding: '2px 8px',
                borderRadius: 12,
                background: 'rgba(6,182,212,0.15)',
                color: '#06b6d4',
                fontWeight: 600,
              }}
            >
              Block Canvas
            </span>
          </div>
        </div>

        {/* Right Header Controls: Version Switcher, Theme Switcher, Share */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          {/* Release Version Selector */}
          <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
            <GitBranch size={13} style={{ color: isLight ? '#64748b' : '#94a3b8' }} />
            <select
              value={selectedVersion}
              onChange={(e) => setSelectedVersion(e.target.value as any)}
              style={{
                padding: '6px 10px',
                borderRadius: 8,
                background: isLight ? '#ffffff' : 'rgba(255,255,255,0.06)',
                border: `1px solid ${isLight ? '#cbd5e1' : 'rgba(255,255,255,0.12)'}`,
                color: isLight ? '#0f172a' : '#f8fafc',
                fontSize: 12,
                fontWeight: 600,
                outline: 'none',
                cursor: 'pointer',
              }}
            >
              <option value="Draft">Draft (In Review)</option>
              <option value="1.0.0">v1.0.0 (Latest)</option>
              <option value="2.0.0">v2.0.0 (Next / Alpha)</option>
            </select>
          </div>

          {/* Theme Switcher Toggle */}
          <button
            onClick={() => setTheme(isLight ? 'dark' : 'light')}
            title="Toggle theme"
            style={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              width: 34,
              height: 34,
              borderRadius: 8,
              border: `1px solid ${isLight ? '#cbd5e1' : 'rgba(255,255,255,0.12)'}`,
              background: isLight ? '#ffffff' : 'rgba(255,255,255,0.06)',
              color: isLight ? '#0f172a' : '#f8fafc',
              cursor: 'pointer',
            }}
          >
            {isLight ? <Moon size={15} /> : <Sun size={15} />}
          </button>

          {/* Share Link */}
          <button
            onClick={copyPageLink}
            title="Copy link to page"
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: 5,
              padding: '6px 12px',
              borderRadius: 8,
              border: `1px solid ${isLight ? '#cbd5e1' : 'rgba(255,255,255,0.12)'}`,
              background: isLight ? '#ffffff' : 'rgba(255,255,255,0.06)',
              color: copiedLink ? '#10b981' : isLight ? '#0f172a' : '#f8fafc',
              fontSize: 12,
              fontWeight: 600,
              cursor: 'pointer',
            }}
          >
            {copiedLink ? <Check size={13} /> : <Share2 size={13} />}
            <span>{copiedLink ? 'Copied' : 'Share'}</span>
          </button>
        </div>
      </header>

      {/* Main Container with Sidebar TOC */}
      <div
        style={{
          maxWidth: 1280,
          margin: '0 auto',
          padding: '40px 24px 80px',
          display: 'grid',
          gridTemplateColumns: '1fr 240px',
          gap: 48,
        }}
      >
        {/* Living Documentation Content Area */}
        <main style={{ minWidth: 0 }}>
          <div style={{ marginBottom: 20 }}>
            <span
              style={{
                fontSize: 11,
                fontFamily: 'monospace',
                textTransform: 'uppercase',
                letterSpacing: '0.06em',
                color: '#06b6d4',
              }}
            >
              Release: {selectedVersion} &bull; Mode: {theme.toUpperCase()}
            </span>
          </div>

          {/* Render Block Canvas */}
          <BlockCanvasRenderer blocks={blocks} theme={theme} />
        </main>

        {/* Sticky Table of Contents Navigation */}
        <aside
          style={{
            position: 'sticky',
            top: 84,
            height: 'fit-content',
            display: 'flex',
            flexDirection: 'column',
            gap: 12,
            borderLeft: `1px solid ${isLight ? '#e2e8f0' : 'rgba(255,255,255,0.08)'}`,
            paddingLeft: 20,
          }}
        >
          <span
            style={{
              fontSize: 11,
              fontWeight: 700,
              textTransform: 'uppercase',
              letterSpacing: '0.05em',
              color: isLight ? '#64748b' : '#94a3b8',
            }}
          >
            On this page
          </span>

          <nav style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {toc.map((item) => (
              <a
                key={item.id}
                href={`#${item.id}`}
                style={{
                  fontSize: 13,
                  color: isLight ? '#475569' : '#94a3b8',
                  textDecoration: 'none',
                  paddingLeft: item.level === 2 ? 8 : item.level > 2 ? 16 : 0,
                  transition: 'color 0.15s ease',
                  lineHeight: 1.4,
                }}
                onMouseEnter={(e) => (e.currentTarget.style.color = '#06b6d4')}
                onMouseLeave={(e) => (e.currentTarget.style.color = isLight ? '#475569' : '#94a3b8')}
              >
                {item.text}
              </a>
            ))}
          </nav>
        </aside>
      </div>
    </div>
  );
}
