import { NextResponse } from 'next/server';
import { getDb } from '@/db';
import { tokens, components, designSystems } from '@/db/schema';

export async function GET() {
  const { db } = await getDb();

  const dsList = await db.select().from(designSystems);
  const ds = dsList[0] || { name: 'Nova Design System', description: 'Enterprise Design System' };

  const allTokens = await db.select().from(tokens);
  const allComponents = await db.select().from(components);

  // Group tokens by category
  const categories: Record<string, number> = {};
  for (const t of allTokens) {
    categories[t.category] = (categories[t.category] || 0) + 1;
  }

  const categoryLines = Object.entries(categories)
    .map(([cat, count]) => `- **${cat}**: ${count} tokens`)
    .join('\n');

  const componentLines = allComponents
    .map((c: any) => `- **${c.name}** (\`${c.category}\`): ${c.description || 'Core design system component'}`)
    .join('\n');

  const content = `# ${ds.name} — LLMs & AI Coding Agents Index
> ${ds.description || 'Central Design System Tokens, Code Components, and AI Context Engine'}
> Generated according to the /llms.txt specification for AI Agents (Cursor, Claude Code, Copilot, Codex).

## 1. System Overview
- **Platform**: Nexus Design OS (Supernova.io Enterprise Parity Platform)
- **Total Design Tokens**: ${allTokens.length}
- **Total Components**: ${allComponents.length}
- **Model Context Protocol (MCP)**: Supported via stdio and SSE

## 2. Model Context Protocol (MCP) Setup
To connect Claude Desktop, Cursor, or VS Code directly to this design system:

### Cursor (\`.cursor/mcp.json\`):
\`\`\`json
{
  "mcpServers": {
    "nexus-design-os": {
      "command": "npx",
      "args": ["nexus-design-os", "mcp"]
    }
  }
}
\`\`\`

### Claude Desktop (\`claude_desktop_config.json\`):
\`\`\`json
{
  "mcpServers": {
    "nexus-design-system": {
      "command": "node",
      "args": ["dist/cli/index.js", "mcp"]
    }
  }
}
\`\`\`

### HTTP Server-Sent Events (SSE):
- **URL**: \`http://localhost:3000/api/mcp\`

## 3. Design Tokens Summary
${categoryLines || '- No tokens indexed yet.'}

### Fetch Raw Tokens API:
- **Endpoint**: \`GET /api/tokens\`
- **Formats**: DTCG JSON, Flat JSON, CSS, SCSS, TypeScript, Tailwind, Swift, Kotlin, Flutter, Style Dictionary, Android XML
- **Query**: \`GET /api/export?format=css\` (or \`format=scss\`, \`format=typescript\`, \`format=flutter\`, \`format=style-dictionary\`)

## 4. Component Catalog
${componentLines || '- No components registered yet.'}

### Component Discovery API:
- **Endpoint**: \`GET /api/components\`
- **Storybook CSF3 Endpoint**: \`GET /api/components/storybook\`

## 5. Exporters Available
1. **CSS Custom Properties**: \`:root { --prefix-token: value; }\`
2. **SCSS Variables & Mixins**: \`_tokens.scss\` with \`$nexus-*\`, Sass maps, and typography mixins
3. **TypeScript Dictionary**: Typed nested constants with full autocomplete
4. **Tailwind CSS v3 / v4**: Tailwind \`@theme\` rules and config plugins
5. **iOS Swift / SwiftUI**: Native \`Color\` and \`TextStyle\` structs
6. **Android Jetpack Compose**: Compose \`Color\` and \`Dp\` objects
7. **Flutter / Dart**: Material 3 \`ThemeData\`, \`AppColors\`, \`AppTypography\`
8. **Amazon Style Dictionary (v3/v4)**: Hierarchical JSON token trees and \`style-dictionary.config.json\`
9. **Android XML**: \`colors.xml\`, \`dimens.xml\`, \`styles.xml\`
10. **W3C DTCG Token JSON**: Standard \`$value\` and \`$type\` specification

## 6. Living Documentation Portal
- **Documentation Hub**: \`/docs\`
- **Dynamic Guides**: \`/docs/[slug]\`
- **Living Canvas Blocks**: Do/Don't Comparisons, Interactive Sandboxes, Live Token Tables, Asset Grids, ContextMcp AI integration blocks

---
*Maintained by Nexus Design OS — The Single Source of Truth for Human Designers and AI Coding Agents.*
`;

  return new NextResponse(content, {
    status: 200,
    headers: {
      'Content-Type': 'text/plain; charset=utf-8',
      'Cache-Control': 'public, max-age=300, stale-while-revalidate=3600',
    },
  });
}
