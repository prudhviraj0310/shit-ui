import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';

export interface MultiTenantRouteInfo {
  subdomain: string | null;
  isCustomDomain: boolean;
  tenantId?: string;
  isSealedRelease: boolean;
}

/**
 * Inspects request headers and hostnames to resolve multi-tenant routing,
 * password protection, and edge cache directives.
 */
export function resolveMultiTenantRouting(request: NextRequest): MultiTenantRouteInfo {
  const host = request.headers.get('host') || '';
  const customHeaderDomain = request.headers.get('x-custom-domain') || request.headers.get('x-design-system');
  const pathname = request.nextUrl.pathname;
  const versionParam = request.nextUrl.searchParams.get('version');

  // Match *.designsystem.local or custom subdomain pattern
  const subdomainMatch = host.match(/^([a-zA-Z0-9_-]+)\.designsystem\.local/i);
  let subdomain: string | null = null;
  let isCustomDomain = false;

  if (subdomainMatch) {
    subdomain = subdomainMatch[1];
    isCustomDomain = true;
  } else if (customHeaderDomain) {
    subdomain = customHeaderDomain;
    isCustomDomain = true;
  }

  // Detect sealed release documentation requests (e.g. version=1.0.0, /api/releases/, /docs/1.0.0)
  const isSealedRelease =
    Boolean(versionParam && versionParam !== 'Draft') ||
    pathname.includes('/api/releases') ||
    pathname.includes('/docs/releases') ||
    /^\/docs\/(v?\d+\.\d+\.\d+)/.test(pathname);

  return {
    subdomain,
    isCustomDomain,
    tenantId: subdomain ? `ds-${subdomain}` : undefined,
    isSealedRelease,
  };
}

export function proxy(request: NextRequest) {
  const { subdomain, isCustomDomain, isSealedRelease } = resolveMultiTenantRouting(request);
  const pathname = request.nextUrl.pathname;

  // Handle password-protected or private doc access
  const docPasswordRequired = request.headers.get('x-require-doc-password') === 'true';
  const providedPassword = request.headers.get('x-docs-password') || request.cookies.get('nexus_doc_auth')?.value;

  if (docPasswordRequired && !providedPassword && pathname.startsWith('/docs')) {
    return NextResponse.json(
      {
        error: 'Unauthorized',
        message: 'This design system documentation is password-protected. Please provide valid documentation credentials.',
      },
      {
        status: 401,
        headers: { 'WWW-Authenticate': 'Basic realm="Design System Documentation"' },
      }
    );
  }

  // Handle multi-tenant custom subdomain routing
  let response: NextResponse;
  if (isCustomDomain && subdomain && pathname === '/') {
    // Route root requests on *.designsystem.local to the tenant's living docs
    const url = request.nextUrl.clone();
    url.pathname = `/docs`;
    url.searchParams.set('tenant', subdomain);
    response = NextResponse.rewrite(url);
  } else {
    response = NextResponse.next();
  }

  // Production Security Headers
  response.headers.set('X-Content-Type-Options', 'nosniff');
  response.headers.set('X-Frame-Options', 'SAMEORIGIN');
  response.headers.set('Referrer-Policy', 'strict-origin-when-cross-origin');
  response.headers.set('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');

  // Multi-tenant metadata headers
  if (subdomain) {
    response.headers.set('X-Nexus-Tenant', subdomain);
  }

  // Edge CDN Caching for Sealed Releases
  if (isSealedRelease) {
    response.headers.set('Cache-Control', 'public, s-maxage=3600, stale-while-revalidate=86400');
  }

  return response;
}

export const config = {
  matcher: [
    // Apply to all routes except Next.js internals and static assets
    '/((?!_next/static|_next/image|favicon.ico).*)',
  ],
};
