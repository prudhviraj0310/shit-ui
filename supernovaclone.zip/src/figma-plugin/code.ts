/**
 * Nexus Design OS — Figma Plugin Code
 * 
 * Runs in the Figma plugin sandbox. Handles:
 * - Reading Figma local variables and pushing to Nexus API
 * - Pulling tokens from Nexus API and creating/updating Figma variables
 * - Token inspection overlay on selected nodes
 * - Bidirectional sync with conflict resolution
 */

// ─── Types ─────────────────────────────────────────────────────────────

interface NexusToken {
  path: string;
  name: string;
  category: string;
  type: string;
  rawValue: string;
  resolvedValue: string;
  isAlias: boolean;
  aliasTarget?: string;
  description?: string;
}

interface SyncResult {
  pushed: number;
  pulled: number;
  conflicts: { path: string; figmaValue: string; nexusValue: string }[];
  errors: string[];
}

interface PluginSettings {
  apiUrl: string;
  apiKey: string;
  designSystemId: string;
  autoSync: boolean;
  syncInterval: number; // minutes
}

// ─── Default Settings ──────────────────────────────────────────────────

const DEFAULT_SETTINGS: PluginSettings = {
  apiUrl: 'http://localhost:3000/api',
  apiKey: '',
  designSystemId: 'ds-nova-design',
  autoSync: false,
  syncInterval: 30,
};

// ─── Plugin Main ───────────────────────────────────────────────────────

figma.showUI(__html__, { width: 420, height: 600, themeColors: true });

figma.ui.onmessage = async (msg: { type: string; payload?: any }) => {
  switch (msg.type) {
    case 'sync-push':
      await handleSyncPush(msg.payload);
      break;
    case 'sync-pull':
      await handleSyncPull(msg.payload);
      break;
    case 'inspect':
      await handleInspect();
      break;
    case 'save-settings':
      await figma.clientStorage.setAsync('nexus-settings', msg.payload);
      figma.ui.postMessage({ type: 'settings-saved' });
      break;
    case 'load-settings':
      const settings = await figma.clientStorage.getAsync('nexus-settings');
      figma.ui.postMessage({ type: 'settings-loaded', payload: settings || DEFAULT_SETTINGS });
      break;
    case 'get-local-variables':
      const variables = await getLocalVariables();
      figma.ui.postMessage({ type: 'local-variables', payload: variables });
      break;
  }
};

// Also handle menu commands
figma.on('run', ({ command }: RunEvent) => {
  figma.ui.postMessage({ type: 'command', payload: command });
});

// ─── Read Figma Variables ──────────────────────────────────────────────

async function getLocalVariables(): Promise<NexusToken[]> {
  const collections = await figma.variables.getLocalVariableCollectionsAsync();
  const tokens: NexusToken[] = [];

  for (const collection of collections) {
    for (const varId of collection.variableIds) {
      const variable = await figma.variables.getVariableByIdAsync(varId);
      if (!variable) continue;

      const modeId = collection.modes[0]?.modeId;
      if (!modeId) continue;

      const value = variable.valuesByMode[modeId];
      const resolvedValue = resolveVariableValue(value, variable.resolvedType);

      tokens.push({
        path: variable.name.replace(/\//g, '.'),
        name: variable.name.split('/').pop() || variable.name,
        category: mapResolvedType(variable.resolvedType),
        type: mapResolvedType(variable.resolvedType),
        rawValue: resolvedValue,
        resolvedValue: resolvedValue,
        isAlias: typeof value === 'object' && value !== null && 'type' in value && (value as any).type === 'VARIABLE_ALIAS',
        aliasTarget: typeof value === 'object' && value !== null && 'id' in value ? String((value as any).id) : undefined,
        description: variable.description || undefined,
      });
    }
  }

  return tokens;
}

function resolveVariableValue(value: any, resolvedType: string): string {
  if (value === null || value === undefined) return '';

  // Alias reference
  if (typeof value === 'object' && value.type === 'VARIABLE_ALIAS') {
    return `{${value.id}}`;
  }

  // Color (RGBA)
  if (resolvedType === 'COLOR' && typeof value === 'object') {
    const r = Math.round((value.r || 0) * 255);
    const g = Math.round((value.g || 0) * 255);
    const b = Math.round((value.b || 0) * 255);
    const a = value.a !== undefined ? value.a : 1;
    if (a < 1) return `rgba(${r}, ${g}, ${b}, ${a.toFixed(2)})`;
    return `#${r.toString(16).padStart(2, '0')}${g.toString(16).padStart(2, '0')}${b.toString(16).padStart(2, '0')}`;
  }

  // Float (spacing, sizing)
  if (resolvedType === 'FLOAT') return `${value}px`;

  // String
  if (resolvedType === 'STRING') return String(value);

  // Boolean
  if (resolvedType === 'BOOLEAN') return String(value);

  return String(value);
}

function mapResolvedType(type: string): string {
  switch (type) {
    case 'COLOR': return 'color';
    case 'FLOAT': return 'spacing';
    case 'STRING': return 'typography';
    case 'BOOLEAN': return 'other';
    default: return 'other';
  }
}

// ─── Push to Nexus ─────────────────────────────────────────────────────

async function handleSyncPush(payload?: { apiUrl?: string; apiKey?: string }) {
  try {
    const settings = { ...DEFAULT_SETTINGS, ...(await figma.clientStorage.getAsync('nexus-settings')), ...payload };
    const variables = await getLocalVariables();

    figma.ui.postMessage({ type: 'sync-status', payload: { stage: 'pushing', total: variables.length, current: 0 } });

    let pushed = 0;
    const errors: string[] = [];

    for (const token of variables) {
      try {
        const response = await fetch(`${settings.apiUrl}/tokens`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'x-api-key': settings.apiKey },
          body: JSON.stringify({
            path: token.path,
            name: token.name,
            category: token.category,
            type: token.type,
            rawValue: token.rawValue,
            description: token.description,
            designSystemId: settings.designSystemId,
            originSourceId: 'figma-plugin',
          }),
        });

        if (response.ok) {
          pushed++;
        } else {
          const err = await response.json();
          errors.push(`${token.path}: ${err.error}`);
        }
      } catch (e: any) {
        errors.push(`${token.path}: ${e.message}`);
      }

      figma.ui.postMessage({ type: 'sync-status', payload: { stage: 'pushing', total: variables.length, current: pushed } });
    }

    figma.ui.postMessage({
      type: 'sync-complete',
      payload: { pushed, pulled: 0, conflicts: [], errors } as SyncResult,
    });

    figma.notify(`✅ Pushed ${pushed} tokens to Nexus Design OS`, { timeout: 3000 });
  } catch (err: any) {
    figma.ui.postMessage({ type: 'sync-error', payload: err.message });
    figma.notify(`❌ Sync failed: ${err.message}`, { error: true });
  }
}

// ─── Pull from Nexus ───────────────────────────────────────────────────

async function handleSyncPull(payload?: { apiUrl?: string; apiKey?: string }) {
  try {
    const settings = { ...DEFAULT_SETTINGS, ...(await figma.clientStorage.getAsync('nexus-settings')), ...payload };

    figma.ui.postMessage({ type: 'sync-status', payload: { stage: 'pulling', total: 0, current: 0 } });

    const response = await fetch(`${settings.apiUrl}/tokens?ds=${settings.designSystemId}`, {
      headers: { 'x-api-key': settings.apiKey },
    });

    if (!response.ok) throw new Error(`API returned ${response.status}`);

    const data = await response.json();
    const remoteTokens: NexusToken[] = data.tokens || [];

    // Get or create a collection
    const collections = await figma.variables.getLocalVariableCollectionsAsync();
    let collection = collections.find(c => c.name === 'Nexus Design Tokens');

    if (!collection) {
      collection = figma.variables.createVariableCollection('Nexus Design Tokens');
    }

    const modeId = collection.modes[0]?.modeId;
    if (!modeId) throw new Error('No modes in collection');

    let pulled = 0;
    const errors: string[] = [];

    for (const token of remoteTokens) {
      try {
        const figmaPath = token.path.replace(/\./g, '/');
        const existingVars = await figma.variables.getLocalVariablesAsync();
        let variable = existingVars.find(v => v.name === figmaPath && v.variableCollectionId === collection!.id);

        const resolvedType = categoryToFigmaType(token.category);

        if (!variable) {
          variable = figma.variables.createVariable(figmaPath, collection!.id, resolvedType);
        }

        if (token.description) variable.description = token.description;

        const figmaValue = nexusValueToFigma(token.rawValue, resolvedType);
        if (figmaValue !== undefined) {
          variable.setValueForMode(modeId, figmaValue);
          pulled++;
        }
      } catch (e: any) {
        errors.push(`${token.path}: ${e.message}`);
      }
    }

    figma.ui.postMessage({
      type: 'sync-complete',
      payload: { pushed: 0, pulled, conflicts: [], errors } as SyncResult,
    });

    figma.notify(`✅ Pulled ${pulled} tokens from Nexus Design OS`, { timeout: 3000 });
  } catch (err: any) {
    figma.ui.postMessage({ type: 'sync-error', payload: err.message });
    figma.notify(`❌ Pull failed: ${err.message}`, { error: true });
  }
}

function categoryToFigmaType(category: string): VariableResolvedDataType {
  switch (category) {
    case 'color': return 'COLOR';
    case 'spacing':
    case 'border':
    case 'shadow':
    case 'duration': return 'FLOAT';
    case 'typography': return 'STRING';
    default: return 'STRING';
  }
}

function nexusValueToFigma(value: string, type: VariableResolvedDataType): any {
  if (type === 'COLOR') {
    const hex = value.replace('#', '');
    if (hex.length === 6) {
      return {
        r: parseInt(hex.substring(0, 2), 16) / 255,
        g: parseInt(hex.substring(2, 4), 16) / 255,
        b: parseInt(hex.substring(4, 6), 16) / 255,
        a: 1,
      };
    }
  }
  if (type === 'FLOAT') {
    const num = parseFloat(value);
    return isNaN(num) ? undefined : num;
  }
  return value;
}

// ─── Token Inspector ───────────────────────────────────────────────────

async function handleInspect() {
  const selection = figma.currentPage.selection;
  if (selection.length === 0) {
    figma.notify('Select a layer to inspect its bound tokens');
    return;
  }

  const node = selection[0];
  const bindings: { property: string; variableName: string; value: string }[] = [];

  // Check for variable bindings on the node
  if ('boundVariables' in node) {
    const bv = (node as any).boundVariables;
    if (bv) {
      for (const [prop, binding] of Object.entries(bv)) {
        if (binding && typeof binding === 'object' && 'id' in (binding as any)) {
          const variable = await figma.variables.getVariableByIdAsync((binding as any).id);
          if (variable) {
            bindings.push({
              property: prop,
              variableName: variable.name,
              value: resolveVariableValue(
                variable.valuesByMode[Object.keys(variable.valuesByMode)[0]],
                variable.resolvedType
              ),
            });
          }
        }
      }
    }
  }

  figma.ui.postMessage({
    type: 'inspect-result',
    payload: {
      nodeName: node.name,
      nodeType: node.type,
      bindings,
      hasTokens: bindings.length > 0,
    },
  });
}
