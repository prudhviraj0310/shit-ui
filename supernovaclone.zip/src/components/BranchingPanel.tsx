'use client';

import React, { useState, useEffect } from 'react';
import {
  GitBranch, GitMerge, Plus, ArrowRight, Check, RefreshCw,
  GitPullRequest, AlertCircle, FileCode, Clock, Tag
} from 'lucide-react';

interface BranchItem {
  id: string;
  name: string;
  description: string | null;
  isDraft: boolean;
  isReadOnly: boolean;
  tokenCount: number;
  createdAt: string;
}

interface DiffResult {
  sourceBranch: string;
  targetBranch: string;
  totalChanges: number;
  addedCount: number;
  modifiedCount: number;
  deletedCount: number;
  unchangedCount: number;
  changes: Array<{
    path: string;
    category: string;
    type: string;
    changeType: 'added' | 'modified' | 'deleted' | 'unchanged';
    oldValue?: string;
    newValue?: string;
    oldResolved?: string;
    newResolved?: string;
  }>;
}

export function BranchingPanel() {
  const [branches, setBranches] = useState<BranchItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedSource, setSelectedSource] = useState<string>('');
  const [selectedTarget, setSelectedTarget] = useState<string>('Draft');
  const [diff, setDiff] = useState<DiffResult | null>(null);
  const [loadingDiff, setLoadingDiff] = useState(false);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [newBranchName, setNewBranchName] = useState('');
  const [newBranchDesc, setNewBranchDesc] = useState('');
  const [merging, setMerging] = useState(false);
  const [mergeStatus, setMergeStatus] = useState<string | null>(null);

  const fetchBranches = async () => {
    try {
      setLoading(true);
      const res = await fetch('/api/tokens/branches', {
        headers: { 'x-api-key': 'nexus_api_key_for_testing_min24chars' }
      });
      const data = await res.json();
      if (data.success && data.branches) {
        setBranches(data.branches);
        // Find a non-Draft branch to diff against Draft by default
        const nonDraft = data.branches.find((b: BranchItem) => b.name !== 'Draft');
        if (nonDraft && !selectedSource) {
          setSelectedSource(nonDraft.name);
        }
      }
    } catch (e) {
      console.error('Failed to load branches', e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchBranches();
  }, []);

  const runDiff = async () => {
    if (!selectedSource || !selectedTarget) return;
    try {
      setLoadingDiff(true);
      setMergeStatus(null);
      const res = await fetch(
        `/api/tokens/merge?source=${encodeURIComponent(selectedSource)}&target=${encodeURIComponent(selectedTarget)}`,
        { headers: { 'x-api-key': 'nexus_api_key_for_testing_min24chars' } }
      );
      const data = await res.json();
      if (data.success) {
        setDiff(data.diff);
      }
    } catch (e) {
      console.error('Failed to diff branches', e);
    } finally {
      setLoadingDiff(false);
    }
  };

  useEffect(() => {
    if (selectedSource && selectedTarget) {
      runDiff();
    }
  }, [selectedSource, selectedTarget]);

  const handleCreateBranch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newBranchName.trim()) return;

    try {
      const res = await fetch('/api/tokens/branches', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-api-key': 'nexus_api_key_for_testing_min24chars'
        },
        body: JSON.stringify({
          branchName: newBranchName.trim(),
          description: newBranchDesc.trim(),
          baseVersion: selectedTarget
        })
      });
      const data = await res.json();
      if (data.success) {
        setShowCreateModal(false);
        setNewBranchName('');
        setNewBranchDesc('');
        await fetchBranches();
        setSelectedSource(data.branch.name);
      }
    } catch (err) {
      console.error('Failed to create branch', err);
    }
  };

  const handleMerge = async () => {
    if (!selectedSource || !selectedTarget) return;
    if (!confirm(`Are you sure you want to merge "${selectedSource}" into "${selectedTarget}"?`)) return;

    try {
      setMerging(true);
      const res = await fetch('/api/tokens/merge', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-api-key': 'nexus_api_key_for_testing_min24chars'
        },
        body: JSON.stringify({
          source: selectedSource,
          target: selectedTarget,
        })
      });
      const data = await res.json();
      if (data.success) {
        setMergeStatus(`Successfully merged ${data.mergedChanges} change(s) from "${selectedSource}" into "${selectedTarget}"!`);
        await fetchBranches();
        await runDiff();
      } else {
        alert(data.error || 'Merge failed');
      }
    } catch (err) {
      console.error('Merge request failed', err);
    } finally {
      setMerging(false);
    }
  };

  return (
    <div className="space-y-6 max-w-6xl mx-auto">
      {/* Header Card */}
      <div className="nexus-card p-6 rounded-2xl border border-[#e2e8f0]/90 bg-white flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-xs">
        <div className="flex items-center gap-3.5">
          <div className="p-3 rounded-xl bg-cyan-50 border border-cyan-200">
            <GitBranch className="w-6 h-6 text-cyan-600" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl font-bold text-[#0f172a] tracking-tight">Token Branching & Merging</h1>
              <span className="px-2.5 py-0.5 rounded-full bg-cyan-50 text-cyan-700 text-[11px] font-semibold border border-cyan-200">
                {branches.length} {branches.length === 1 ? 'branch' : 'branches'}
              </span>
            </div>
            <p className="text-xs text-[#64748b] mt-0.5">
              Git-like branching workflow for safe token experimentation and reviews.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={fetchBranches}
            className="btn-secondary text-xs py-2 px-3.5 flex items-center gap-1.5"
          >
            <RefreshCw className={`w-3.5 h-3.5 text-[#64748b] ${loading ? 'animate-spin' : ''}`} />
            <span>Refresh</span>
          </button>
          <button
            onClick={() => setShowCreateModal(true)}
            className="btn-primary text-xs py-2 px-4 rounded-xl flex items-center gap-1.5 shadow-xs"
          >
            <Plus className="w-4 h-4" />
            <span>New Branch</span>
          </button>
        </div>
      </div>

      {mergeStatus && (
        <div className="p-4 rounded-xl border border-emerald-200 bg-emerald-50 text-emerald-800 flex items-center justify-between shadow-2xs">
          <div className="flex items-center gap-2">
            <Check className="w-5 h-5 text-emerald-600" />
            <span className="text-sm font-semibold">{mergeStatus}</span>
          </div>
          <button onClick={() => setMergeStatus(null)} className="text-xs text-emerald-700 hover:underline font-semibold">Dismiss</button>
        </div>
      )}

      {/* Branch Selector Bar */}
      <div className="nexus-card p-6 rounded-2xl border border-[#e2e8f0] bg-white space-y-4 shadow-xs">
        <h2 className="text-xs font-bold uppercase tracking-wider text-[#64748b]">Compare & Merge Branches</h2>
        <div className="flex flex-col md:flex-row items-center gap-4">
          <div className="flex-1 w-full">
            <label className="text-xs font-semibold text-[#475569] block mb-1.5">Source Branch (Comparing)</label>
            <select
              value={selectedSource}
              onChange={(e) => setSelectedSource(e.target.value)}
              className="w-full px-3.5 py-2.5 text-xs rounded-xl border border-[#cbd5e1] bg-[#f8fafc] text-[#0f172a] focus:bg-white focus:outline-none focus:border-cyan-500 font-medium"
            >
              <option value="">Select source branch...</option>
              {branches.map(b => (
                <option key={b.id} value={b.name}>{b.name} ({b.tokenCount} tokens)</option>
              ))}
            </select>
          </div>

          <div className="flex items-center justify-center p-2 rounded-full bg-[#f1f5f9] text-[#64748b] border border-[#e2e8f0] md:mt-5">
            <ArrowRight className="w-4 h-4" />
          </div>

          <div className="flex-1 w-full">
            <label className="text-xs font-semibold text-[#475569] block mb-1.5">Target Branch (Base)</label>
            <select
              value={selectedTarget}
              onChange={(e) => setSelectedTarget(e.target.value)}
              className="w-full px-3.5 py-2.5 text-xs rounded-xl border border-[#cbd5e1] bg-[#f8fafc] text-[#0f172a] focus:bg-white focus:outline-none focus:border-cyan-500 font-medium"
            >
              {branches.map(b => (
                <option key={b.id} value={b.name}>{b.name} ({b.tokenCount} tokens)</option>
              ))}
            </select>
          </div>

          <div className="w-full md:w-auto md:mt-5">
            <button
              onClick={handleMerge}
              disabled={merging || !selectedSource || selectedSource === selectedTarget}
              className="w-full md:w-auto flex items-center justify-center gap-2 px-6 py-2.5 text-xs font-bold rounded-xl bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white shadow-xs disabled:opacity-50 transition-all cursor-pointer"
            >
              <GitMerge className="w-4 h-4" />
              <span>{merging ? 'Merging...' : 'Merge into Target'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Diff Metrics */}
      {diff && (
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
          <div className="nexus-card p-3.5 rounded-xl border border-[#e2e8f0] bg-white shadow-2xs">
            <span className="text-xs font-semibold text-[#64748b] block">Total Changes</span>
            <span className="text-xl font-bold text-[#0f172a] mt-0.5 block">{diff.totalChanges}</span>
          </div>
          <div className="nexus-card p-3.5 rounded-xl border border-emerald-200 bg-emerald-50/60 shadow-2xs">
            <span className="text-xs font-semibold text-emerald-800 block">Added Tokens</span>
            <span className="text-xl font-bold text-emerald-700 mt-0.5 block">+{diff.addedCount}</span>
          </div>
          <div className="nexus-card p-3.5 rounded-xl border border-amber-200 bg-amber-50/60 shadow-2xs">
            <span className="text-xs font-semibold text-amber-800 block">Modified Tokens</span>
            <span className="text-xl font-bold text-amber-700 mt-0.5 block">~{diff.modifiedCount}</span>
          </div>
          <div className="nexus-card p-3.5 rounded-xl border border-rose-200 bg-rose-50/60 shadow-2xs">
            <span className="text-xs font-semibold text-rose-800 block">Deleted Tokens</span>
            <span className="text-xl font-bold text-rose-700 mt-0.5 block">-{diff.deletedCount}</span>
          </div>
          <div className="nexus-card p-3.5 rounded-xl border border-[#e2e8f0] bg-white shadow-2xs">
            <span className="text-xs font-semibold text-[#64748b] block">Identical Tokens</span>
            <span className="text-xl font-bold text-[#475569] mt-0.5 block">{diff.unchangedCount}</span>
          </div>
        </div>
      )}

      {/* Visual Diff Table */}
      <div className="nexus-card rounded-2xl border border-[#e2e8f0] bg-white overflow-hidden shadow-xs">
        <div className="p-4 border-b border-[#e2e8f0] flex items-center justify-between bg-[#f8fafc]">
          <div className="flex items-center gap-2">
            <FileCode className="w-4 h-4 text-cyan-600" />
            <h3 className="font-bold text-xs uppercase tracking-wider text-[#0f172a]">Visual Token Diff</h3>
          </div>
          <span className="text-xs font-semibold text-[#64748b]">
            {diff ? `${diff.changes.length} difference(s) detected` : 'Select branches to diff'}
          </span>
        </div>

        {loadingDiff ? (
          <div className="p-12 text-center text-xs text-[#64748b] flex items-center justify-center gap-2">
            <RefreshCw className="w-4 h-4 animate-spin text-cyan-600" />
            <span>Calculating branch diff...</span>
          </div>
        ) : diff && diff.changes.length > 0 ? (
          <div className="divide-y divide-[#e2e8f0]">
            {diff.changes.map((item, idx) => (
              <div key={`${item.path}-${item.changeType}-${idx}`} className="p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 hover:bg-[#f8fafc] transition-colors">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-xs text-[#0f172a] font-bold">{item.path}</span>
                    <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded-full bg-[#f1f5f9] text-[#475569] border border-[#cbd5e1] font-semibold">
                      {item.type}
                    </span>
                  </div>
                  <span className="text-[11px] text-[#64748b] capitalize">{item.category}</span>
                </div>

                <div className="flex items-center gap-3">
                  {item.changeType === 'added' && (
                    <span className="px-2.5 py-1 rounded-full text-xs font-mono font-semibold border border-emerald-200 bg-emerald-50 text-emerald-700">
                      Added: {item.newValue}
                    </span>
                  )}
                  {item.changeType === 'modified' && (
                    <div className="flex items-center gap-2 text-xs font-mono">
                      <span className="px-2 py-0.5 rounded border border-rose-200 bg-rose-50 text-rose-700 line-through">
                        {item.oldValue}
                      </span>
                      <ArrowRight className="w-3.5 h-3.5 text-[#94a3b8]" />
                      <span className="px-2 py-0.5 rounded border border-emerald-200 bg-emerald-50 text-emerald-700 font-bold">
                        {item.newValue}
                      </span>
                    </div>
                  )}
                  {item.changeType === 'deleted' && (
                    <span className="px-2.5 py-1 rounded-full text-xs font-mono font-semibold border border-rose-200 bg-rose-50 text-rose-700">
                      Deleted (was: {item.oldValue})
                    </span>
                  )}
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="p-12 text-center text-xs text-[#94a3b8]">
            {diff ? 'Branches are identical. No differences found.' : 'Select a source branch above to inspect token differences.'}
          </div>
        )}
      </div>

      {/* Create Branch Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-[#0f172a]/40 backdrop-blur-xs p-4">
          <div className="w-full max-w-md rounded-2xl border border-[#e2e8f0] bg-white p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-[#e2e8f0] pb-3">
              <h2 className="text-base font-bold text-[#0f172a]">Create Token Branch</h2>
              <button onClick={() => setShowCreateModal(false)} className="text-[#94a3b8] hover:text-[#0f172a] text-sm">✕</button>
            </div>
            <p className="text-xs text-[#64748b]">
              Create an isolated working branch to experiment with token updates without touching the active draft.
            </p>

            <form onSubmit={handleCreateBranch} className="space-y-4">
              <div>
                <label className="text-xs font-semibold text-[#475569] block mb-1">Branch Name</label>
                <input
                  type="text"
                  placeholder="e.g. experiment/contrast-a11y, feature/new-typography"
                  value={newBranchName}
                  onChange={(e) => setNewBranchName(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-[#cbd5e1] bg-[#f8fafc] text-[#0f172a] placeholder-[#94a3b8] focus:bg-white focus:outline-none focus:border-cyan-600"
                  required
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-[#475569] block mb-1">Description</label>
                <textarea
                  placeholder="What is the goal of this token branch?"
                  value={newBranchDesc}
                  onChange={(e) => setNewBranchDesc(e.target.value)}
                  rows={3}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-[#cbd5e1] bg-[#f8fafc] text-[#0f172a] placeholder-[#94a3b8] focus:bg-white focus:outline-none focus:border-cyan-600"
                />
              </div>

              <div className="flex justify-end gap-2.5 pt-2 border-t border-[#e2e8f0]">
                <button
                  type="button"
                  onClick={() => setShowCreateModal(false)}
                  className="btn-secondary text-xs py-2 px-3.5"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="btn-primary text-xs py-2 px-4 shadow-xs"
                >
                  Create Branch
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
