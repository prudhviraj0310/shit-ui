'use client';

import React, { useState, useEffect } from 'react';
import {
  MessageSquare, MessageCircle, CheckCircle2, Clock, Send,
  Plus, RefreshCw, Hash, Layers, BookOpen, User, Check
} from 'lucide-react';

interface ReplyItem {
  id: string;
  author: string;
  body: string;
  createdAt: string;
}

interface CommentThread {
  id: string;
  targetType: 'token' | 'component' | 'doc' | 'general';
  targetId: string;
  targetTitle: string;
  author: string;
  body: string;
  status: 'open' | 'resolved';
  createdAt: string;
  replies: ReplyItem[];
}

export function CommentsPanel() {
  const [threads, setThreads] = useState<CommentThread[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'all' | 'token' | 'component' | 'doc'>('all');
  const [statusFilter, setStatusFilter] = useState<'all' | 'open' | 'resolved'>('all');
  const [selectedThreadId, setSelectedThreadId] = useState<string | null>(null);
  const [replyText, setReplyText] = useState('');
  const [replyAuthor, setReplyAuthor] = useState('Product Engineer');
  const [showNewModal, setShowNewModal] = useState(false);

  // New comment modal state
  const [newTargetType, setNewTargetType] = useState<'token' | 'component' | 'doc' | 'general'>('token');
  const [newTargetTitle, setNewTargetTitle] = useState('color.brand.primary');
  const [newAuthor, setNewAuthor] = useState('Design Lead');
  const [newBody, setNewBody] = useState('');

  const fetchComments = async () => {
    try {
      setLoading(true);
      const res = await fetch('/api/comments', {
        headers: { 'x-api-key': 'nexus_api_key_for_testing_min24chars' }
      });
      const data = await res.json();
      if (data.success && data.comments) {
        setThreads(data.comments);
        if (data.comments.length > 0 && !selectedThreadId) {
          setSelectedThreadId(data.comments[0].id);
        }
      }
    } catch (e) {
      console.error('Failed to load comments', e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchComments();
  }, []);

  const handleSendReply = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedThreadId || !replyText.trim()) return;

    try {
      const res = await fetch('/api/comments', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-api-key': 'nexus_api_key_for_testing_min24chars'
        },
        body: JSON.stringify({
          action: 'reply',
          commentId: selectedThreadId,
          author: replyAuthor,
          body: replyText.trim()
        })
      });
      const data = await res.json();
      if (data.success) {
        setReplyText('');
        await fetchComments();
      }
    } catch (err) {
      console.error('Failed to post reply', err);
    }
  };

  const handleToggleResolve = async (commentId: string, currentStatus: string) => {
    const nextStatus = currentStatus === 'open' ? 'resolved' : 'open';
    try {
      const res = await fetch('/api/comments', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-api-key': 'nexus_api_key_for_testing_min24chars'
        },
        body: JSON.stringify({
          action: 'resolve',
          commentId,
          status: nextStatus
        })
      });
      const data = await res.json();
      if (data.success) {
        await fetchComments();
      }
    } catch (err) {
      console.error('Failed to toggle status', err);
    }
  };

  const handleCreateThread = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newBody.trim()) return;

    try {
      const res = await fetch('/api/comments', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-api-key': 'nexus_api_key_for_testing_min24chars'
        },
        body: JSON.stringify({
          targetType: newTargetType,
          targetId: newTargetTitle.toLowerCase().replace(/\s+/g, '-'),
          targetTitle: newTargetTitle,
          author: newAuthor,
          body: newBody.trim()
        })
      });
      const data = await res.json();
      if (data.success) {
        setShowNewModal(false);
        setNewBody('');
        await fetchComments();
        if (data.comment?.id) setSelectedThreadId(data.comment.id);
      }
    } catch (err) {
      console.error('Failed to create thread', err);
    }
  };

  const filteredThreads = threads.filter(t => {
    const matchesTab = activeTab === 'all' || t.targetType === activeTab;
    const matchesStatus = statusFilter === 'all' || t.status === statusFilter;
    return matchesTab && matchesStatus;
  });

  const selectedThread = threads.find(t => t.id === selectedThreadId) || filteredThreads[0];

  const getTargetIcon = (type: string) => {
    switch (type) {
      case 'token': return <Hash className="w-3.5 h-3.5 text-cyan-400" />;
      case 'component': return <Layers className="w-3.5 h-3.5 text-indigo-400" />;
      case 'doc': return <BookOpen className="w-3.5 h-3.5 text-emerald-400" />;
      default: return <MessageSquare className="w-3.5 h-3.5 text-zinc-400" />;
    }
  };

  return (
    <div className="space-y-6 max-w-6xl mx-auto">
      {/* Header Card */}
      <div className="nexus-card p-6 rounded-2xl border border-[#e2e8f0]/90 bg-white flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-xs">
        <div className="flex items-center gap-3.5">
          <div className="p-3 rounded-xl bg-violet-50 border border-violet-200">
            <MessageSquare className="w-6 h-6 text-violet-600" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl font-bold text-[#0f172a] tracking-tight">Contextual Comment Threads</h1>
              <span className="px-2.5 py-0.5 rounded-full bg-violet-50 text-violet-700 text-[11px] font-semibold border border-violet-200">
                {threads.length} {threads.length === 1 ? 'thread' : 'threads'}
              </span>
            </div>
            <p className="text-xs text-[#64748b] mt-0.5">
              Collaborative design reviews across tokens, components, and documentation.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={fetchComments}
            className="btn-secondary text-xs py-2 px-3.5 flex items-center gap-1.5"
          >
            <RefreshCw className={`w-3.5 h-3.5 text-[#64748b] ${loading ? 'animate-spin' : ''}`} />
            <span>Refresh</span>
          </button>
          <button
            onClick={() => setShowNewModal(true)}
            className="btn-primary text-xs py-2 px-4 rounded-xl flex items-center gap-1.5 shadow-xs"
          >
            <Plus className="w-4 h-4" />
            <span>New Thread</span>
          </button>
        </div>
      </div>

      {/* Main 2-Column Discussion Workspace */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-6 min-h-[580px]">
        {/* Left: Thread List */}
        <div className="md:col-span-5 nexus-card rounded-2xl border border-[#e2e8f0] bg-white p-4 flex flex-col space-y-4 shadow-xs">
          {/* Filter Bar */}
          <div className="flex items-center justify-between gap-2 border-b border-[#e2e8f0] pb-3 text-xs">
            <div className="flex items-center gap-1 bg-[#f8fafc] border border-[#e2e8f0] p-1 rounded-xl">
              {(['all', 'token', 'component', 'doc'] as const).map(tab => (
                <button
                  key={tab}
                  onClick={() => setActiveTab(tab)}
                  className={`px-3 py-1 rounded-lg capitalize text-xs transition-all ${
                    activeTab === tab
                      ? 'bg-white font-bold text-violet-700 shadow-2xs'
                      : 'text-[#64748b] hover:text-[#0f172a]'
                  }`}
                >
                  {tab}
                </button>
              ))}
            </div>

            <select
              value={statusFilter}
              onChange={(e: any) => setStatusFilter(e.target.value)}
              className="px-2.5 py-1.5 text-xs rounded-xl border border-[#e2e8f0] bg-[#f8fafc] text-[#0f172a] focus:bg-white focus:outline-none focus:border-violet-500 font-medium"
            >
              <option value="all">All States</option>
              <option value="open">Open</option>
              <option value="resolved">Resolved</option>
            </select>
          </div>

          {/* List Items */}
          <div className="flex-1 overflow-y-auto space-y-2.5 pr-1 max-h-[500px]">
            {filteredThreads.length === 0 ? (
              <div className="h-48 flex flex-col items-center justify-center text-xs text-[#94a3b8] gap-2">
                <MessageSquare className="w-8 h-8 text-[#cbd5e1]" />
                <span>No discussion threads match this filter.</span>
              </div>
            ) : (
              filteredThreads.map(thread => {
                const isSelected = selectedThread?.id === thread.id;
                return (
                  <div
                    key={thread.id}
                    onClick={() => setSelectedThreadId(thread.id)}
                    className={`p-4 rounded-xl cursor-pointer border transition-all ${
                      isSelected
                        ? 'border-violet-400 bg-violet-50/70 shadow-xs ring-1 ring-violet-400/40'
                        : 'border-[#e2e8f0] bg-[#f8fafc]/70 hover:bg-[#f8fafc] hover:border-[#cbd5e1]'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-2">
                      <div className="flex items-center gap-1.5 text-xs text-[#0f172a] font-semibold truncate">
                        {getTargetIcon(thread.targetType)}
                        <span className="truncate">{thread.targetTitle}</span>
                      </div>
                      <span className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded-full border capitalize ${
                        thread.status === 'open'
                          ? 'border-amber-200 bg-amber-50 text-amber-700'
                          : 'border-emerald-200 bg-emerald-50 text-emerald-700'
                      }`}>
                        {thread.status}
                      </span>
                    </div>

                    <p className="text-xs text-[#475569] mt-2 line-clamp-2 leading-relaxed">
                      {thread.body}
                    </p>

                    <div className="flex items-center justify-between mt-3 text-[11px] text-[#64748b]">
                      <span className="font-medium text-[#475569]">{thread.author}</span>
                      <span className="flex items-center gap-1 text-[#64748b]">
                        <MessageCircle className="w-3.5 h-3.5 text-violet-500" />
                        {thread.replies.length} replies
                      </span>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* Right: Selected Thread View & Reply */}
        <div className="md:col-span-7 nexus-card rounded-2xl border border-[#e2e8f0] bg-white p-6 flex flex-col justify-between shadow-xs">
          {selectedThread ? (
            <div className="flex flex-col h-full space-y-6">
              {/* Thread Header */}
              <div className="flex items-start justify-between border-b border-[#e2e8f0] pb-4">
                <div>
                  <div className="flex items-center gap-2">
                    {getTargetIcon(selectedThread.targetType)}
                    <h2 className="text-lg font-bold text-[#0f172a]">{selectedThread.targetTitle}</h2>
                  </div>
                  <span className="text-xs text-[#64748b] mt-0.5 block">
                    Thread on <span className="font-semibold text-[#475569]">{selectedThread.targetType}</span> • Started by <span className="font-semibold text-[#0f172a]">{selectedThread.author}</span>
                  </span>
                </div>

                <button
                  onClick={() => handleToggleResolve(selectedThread.id, selectedThread.status)}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold border transition-all ${
                    selectedThread.status === 'open'
                      ? 'border-emerald-200 bg-emerald-50 text-emerald-700 hover:bg-emerald-100'
                      : 'border-amber-200 bg-amber-50 text-amber-700 hover:bg-amber-100'
                  }`}
                >
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  {selectedThread.status === 'open' ? 'Mark Resolved' : 'Reopen Thread'}
                </button>
              </div>

              {/* Original Post */}
              <div className="p-4 rounded-xl border border-[#e2e8f0] bg-[#f8fafc] space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2">
                    <div className="w-6 h-6 rounded-full bg-violet-100 border border-violet-200 flex items-center justify-center font-bold text-[11px] text-violet-700">
                      {selectedThread.author[0]}
                    </div>
                    <span className="font-bold text-[#0f172a]">{selectedThread.author}</span>
                  </div>
                  <span className="text-[#64748b] text-[10px] font-semibold uppercase tracking-wider bg-white px-2 py-0.5 rounded border border-[#e2e8f0]">Author</span>
                </div>
                <p className="text-sm text-[#334155] leading-relaxed pl-8">
                  {selectedThread.body}
                </p>
              </div>

              {/* Replies Chain */}
              <div className="flex-1 overflow-y-auto space-y-3 pr-1 max-h-[300px]">
                {selectedThread.replies.length === 0 ? (
                  <div className="py-6 text-center text-xs text-[#94a3b8]">
                    No replies yet. Join the conversation below.
                  </div>
                ) : (
                  selectedThread.replies.map((rep) => (
                    <div key={rep.id} className="p-3.5 rounded-xl border border-[#e2e8f0] bg-[#f8fafc]/60 space-y-1.5 pl-5">
                      <div className="flex items-center gap-2 text-xs">
                        <div className="w-5 h-5 rounded-full bg-[#e2e8f0] flex items-center justify-center text-[10px] font-bold text-[#475569]">
                          {rep.author[0]}
                        </div>
                        <span className="font-bold text-[#0f172a]">{rep.author}</span>
                      </div>
                      <p className="text-xs text-[#334155] pl-7 leading-relaxed">
                        {rep.body}
                      </p>
                    </div>
                  ))
                )}
              </div>

              {/* Reply Box */}
              <form onSubmit={handleSendReply} className="pt-3 border-t border-[#e2e8f0] flex items-center gap-2">
                <input
                  type="text"
                  placeholder="Write a reply..."
                  value={replyText}
                  onChange={(e) => setReplyText(e.target.value)}
                  className="flex-1 px-4 py-2.5 text-xs rounded-xl border border-[#cbd5e1] bg-[#f8fafc] text-[#0f172a] placeholder-[#94a3b8] focus:bg-white focus:outline-none focus:border-violet-600 transition-all"
                />
                <button
                  type="submit"
                  disabled={!replyText.trim()}
                  className="px-4 py-2.5 rounded-xl bg-violet-600 hover:bg-violet-700 text-white disabled:opacity-40 transition-colors shadow-xs flex items-center gap-1.5 text-xs font-semibold"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>Reply</span>
                </button>
              </form>
            </div>
          ) : (
            <div className="h-full flex items-center justify-center text-xs text-[#94a3b8]">
              Select a thread to view discussion
            </div>
          )}
        </div>
      </div>

      {/* New Thread Modal */}
      {showNewModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-[#0f172a]/40 backdrop-blur-xs p-4">
          <div className="w-full max-w-md rounded-2xl border border-[#e2e8f0] bg-white p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-[#e2e8f0] pb-3">
              <h2 className="text-base font-bold text-[#0f172a]">Start New Discussion Thread</h2>
              <button onClick={() => setShowNewModal(false)} className="text-[#94a3b8] hover:text-[#0f172a] text-sm">✕</button>
            </div>
            <form onSubmit={handleCreateThread} className="space-y-4">
              <div>
                <label className="text-xs font-semibold text-[#475569] block mb-1">Target Entity Type</label>
                <select
                  value={newTargetType}
                  onChange={(e: any) => setNewTargetType(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-[#cbd5e1] bg-[#f8fafc] text-[#0f172a] focus:bg-white focus:outline-none focus:border-violet-600 font-medium"
                >
                  <option value="token">Design Token</option>
                  <option value="component">Component</option>
                  <option value="doc">Documentation Page</option>
                  <option value="general">General Architecture</option>
                </select>
              </div>

              <div>
                <label className="text-xs font-semibold text-[#475569] block mb-1">Target Identifier / Title</label>
                <input
                  type="text"
                  placeholder="e.g. color.brand.primary, Button, Design Foundations"
                  value={newTargetTitle}
                  onChange={(e) => setNewTargetTitle(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-[#cbd5e1] bg-[#f8fafc] text-[#0f172a] placeholder-[#94a3b8] focus:bg-white focus:outline-none focus:border-violet-600"
                  required
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-[#475569] block mb-1">Author Name</label>
                <input
                  type="text"
                  value={newAuthor}
                  onChange={(e) => setNewAuthor(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-[#cbd5e1] bg-[#f8fafc] text-[#0f172a] focus:bg-white focus:outline-none focus:border-violet-600 font-medium"
                  required
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-[#475569] block mb-1">Discussion Note / Review Comment</label>
                <textarea
                  placeholder="Describe your review comment, suggestion, or question..."
                  value={newBody}
                  onChange={(e) => setNewBody(e.target.value)}
                  rows={3}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-[#cbd5e1] bg-[#f8fafc] text-[#0f172a] placeholder-[#94a3b8] focus:bg-white focus:outline-none focus:border-violet-600"
                  required
                />
              </div>

              <div className="flex justify-end gap-2.5 pt-2 border-t border-[#e2e8f0]">
                <button
                  type="button"
                  onClick={() => setShowNewModal(false)}
                  className="btn-secondary text-xs py-2 px-3.5"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="btn-primary text-xs py-2 px-4 shadow-xs"
                >
                  Start Thread
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
