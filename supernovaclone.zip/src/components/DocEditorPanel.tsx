'use client';

import React, { useState, useEffect } from 'react';
import {
  FileText, Plus, Check, Copy, Trash2, Edit3, Slash, BookOpen,
  Heading, Type, Lightbulb, Code, Minus, Palette, Quote, Layers,
  ExternalLink, ChevronRight, X
} from 'lucide-react';

const API_KEY = 'nexus_api_key_for_testing_min24chars';

interface DocBlock {
  id: string;
  type: string;
  content: string;
  properties?: Record<string, any>;
}

interface DocPage {
  id: string;
  title: string;
  slug: string;
  icon: string;
  status: string;
  blocks: DocBlock[];
  updatedAt: number;
  blockCount?: number;
}

interface SlashCommand {
  id: string;
  label: string;
  description: string;
  icon: string;
  category: string;
}

export function DocEditorPanel() {
  const [pages, setPages] = useState<DocPage[]>([]);
  const [selectedPage, setSelectedPage] = useState<DocPage | null>(null);
  const [loading, setLoading] = useState(true);
  const [showSlashMenu, setShowSlashMenu] = useState(false);
  const [slashQuery, setSlashQuery] = useState('');
  const [slashCommands, setSlashCommands] = useState<SlashCommand[]>([]);
  const [editingBlock, setEditingBlock] = useState<string | null>(null);
  const [editingContent, setEditingContent] = useState('');
  const [creatingPage, setCreatingPage] = useState(false);
  const [newPageTitle, setNewPageTitle] = useState('');
  const [copiedMd, setCopiedMd] = useState(false);
  const [hoveredBlockId, setHoveredBlockId] = useState<string | null>(null);

  useEffect(() => { loadPages(); }, []);

  async function loadPages() {
    try {
      const res = await fetch('/api/doc-editor?designSystemId=ds-nova-design', {
        headers: { 'x-api-key': API_KEY },
      });
      const data = await res.json();
      if (data.pages) {
        setPages(data.pages);
        if (data.pages.length > 0 && !selectedPage) {
          loadPage(data.pages[0].id);
        }
      }
      setLoading(false);
    } catch (e) {
      console.error(e);
      setLoading(false);
    }
  }

  async function loadPage(pageId: string) {
    try {
      const res = await fetch(`/api/doc-editor?pageId=${pageId}`, {
        headers: { 'x-api-key': API_KEY },
      });
      const data = await res.json();
      if (data.page) setSelectedPage(data.page);
    } catch (e) { console.error(e); }
  }

  async function searchCommands(q: string) {
    try {
      const res = await fetch(`/api/doc-editor?action=slash-commands&q=${encodeURIComponent(q)}`, {
        headers: { 'x-api-key': API_KEY },
      });
      const data = await res.json();
      if (data.commands) setSlashCommands(data.commands);
    } catch (e) { console.error(e); }
  }

  async function createPage() {
    if (!newPageTitle.trim()) return;
    try {
      const res = await fetch('/api/doc-editor', {
        method: 'POST',
        headers: { 'x-api-key': API_KEY, 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'create-page', title: newPageTitle }),
      });
      const data = await res.json();
      if (data.page) {
        setSelectedPage(data.page);
        setCreatingPage(false);
        setNewPageTitle('');
        loadPages();
      }
    } catch (e) { console.error(e); }
  }

  async function addBlock(type: string) {
    if (!selectedPage) return;
    try {
      let sampleContent = 'Type your documentation content here...';
      if (type === 'heading') sampleContent = 'Section Heading';
      if (type === 'subheading') sampleContent = 'Sub-section Overview';
      if (type === 'code') sampleContent = `import { Button } from '@nexus-design/react';\n\nexport default function App() {\n  return <Button variant="primary">Continue</Button>;\n}`;
      if (type === 'callout') sampleContent = 'Note: This token is synchronized directly with Figma Variables and Storybook CSF3 contracts.';
      if (type === 'token-swatch') sampleContent = 'color.brand.primary = #2563eb';

      const res = await fetch('/api/doc-editor', {
        method: 'POST',
        headers: { 'x-api-key': API_KEY, 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'add-block',
          pageId: selectedPage.id,
          blockType: type,
          content: sampleContent,
        }),
      });
      const data = await res.json();
      if (data.block) loadPage(selectedPage.id);
      setShowSlashMenu(false);
    } catch (e) { console.error(e); }
  }

  async function updateBlock(blockId: string) {
    if (!selectedPage || !editingContent.trim()) return;
    try {
      await fetch('/api/doc-editor', {
        method: 'POST',
        headers: { 'x-api-key': API_KEY, 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'update-block',
          pageId: selectedPage.id,
          blockId,
          content: editingContent,
        }),
      });
      setEditingBlock(null);
      setEditingContent('');
      loadPage(selectedPage.id);
    } catch (e) { console.error(e); }
  }

  async function deleteBlock(blockId: string) {
    if (!selectedPage) return;
    try {
      await fetch('/api/doc-editor', {
        method: 'POST',
        headers: { 'x-api-key': API_KEY, 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'delete-block', pageId: selectedPage.id, blockId }),
      });
      loadPage(selectedPage.id);
    } catch (e) { console.error(e); }
  }

  async function exportMarkdown() {
    if (!selectedPage) return;
    try {
      const res = await fetch('/api/doc-editor', {
        method: 'POST',
        headers: { 'x-api-key': API_KEY, 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'export-markdown', pageId: selectedPage.id }),
      });
      const data = await res.json();
      if (data.markdown) {
        navigator.clipboard.writeText(data.markdown);
        setCopiedMd(true);
        setTimeout(() => setCopiedMd(false), 2000);
      }
    } catch (e) { console.error(e); }
  }

  const slashOptions = [
    { id: 'heading', label: 'Heading', desc: 'Large title (H2)', icon: Heading, color: 'text-indigo-600', bg: 'bg-indigo-50' },
    { id: 'subheading', label: 'Subheading', desc: 'Section header (H3)', icon: Type, color: 'text-blue-600', bg: 'bg-blue-50' },
    { id: 'paragraph', label: 'Text Paragraph', desc: 'Plain text narrative', icon: Type, color: 'text-slate-600', bg: 'bg-slate-50' },
    { id: 'callout', label: 'Callout Box', desc: 'Highlighted info banner', icon: Lightbulb, color: 'text-amber-600', bg: 'bg-amber-50' },
    { id: 'code', label: 'Code Block', desc: 'Syntax highlighted code', icon: Code, color: 'text-purple-600', bg: 'bg-purple-50' },
    { id: 'token-swatch', label: 'Token Swatch', desc: 'Color or token preview', icon: Palette, color: 'text-emerald-600', bg: 'bg-emerald-50' },
    { id: 'quote', label: 'Blockquote', desc: 'Stylized quotation', icon: Quote, color: 'text-cyan-600', bg: 'bg-cyan-50' },
    { id: 'divider', label: 'Divider', desc: 'Horizontal rule separator', icon: Minus, color: 'text-slate-400', bg: 'bg-slate-50' },
  ];

  return (
    <div
      style={{
        display: 'flex',
        flexDirection: 'row',
        height: '100%',
        minHeight: 650,
        borderRadius: 20,
        border: '1px solid #e2e8f0',
        background: '#ffffff',
        overflow: 'hidden',
        boxShadow: '0 4px 20px -2px rgba(15, 23, 42, 0.04)',
      }}
    >
      {/* 1. PERMANENT LEFT SIDEBAR */}
      <aside
        style={{
          width: 280,
          minWidth: 280,
          maxWidth: 280,
          display: 'flex',
          flexDirection: 'column',
          borderRight: '1px solid #e2e8f0',
          background: '#f8fafc',
          flexShrink: 0,
        }}
      >
        {/* Sidebar Header */}
        <div
          style={{
            padding: '16px 18px',
            borderBottom: '1px solid #e2e8f0',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            background: '#f8fafc',
          }}
        >
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <BookOpen size={16} style={{ color: '#2563eb' }} />
            <span style={{ fontSize: 12, fontWeight: 700, color: '#0f172a', letterSpacing: '0.04em', textTransform: 'uppercase' }}>
              Doc Pages
            </span>
            <span
              style={{
                fontSize: 10,
                fontWeight: 700,
                padding: '1px 6px',
                borderRadius: 999,
                background: '#eff6ff',
                color: '#2563eb',
                border: '1px solid #bfdbfe',
              }}
            >
              {pages.length}
            </span>
          </div>
          <button
            onClick={() => setCreatingPage(true)}
            title="Create new documentation page"
            style={{
              width: 28,
              height: 28,
              borderRadius: 8,
              background: '#ffffff',
              border: '1px solid #cbd5e1',
              color: '#0f172a',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              cursor: 'pointer',
              boxShadow: '0 1px 2px rgba(0,0,0,0.04)',
            }}
          >
            <Plus size={14} />
          </button>
        </div>

        {/* Create Page Input Row */}
        {creatingPage && (
          <div
            style={{
              padding: '12px 14px',
              borderBottom: '1px solid #e2e8f0',
              background: '#ffffff',
              display: 'flex',
              alignItems: 'center',
              gap: 8,
            }}
          >
            <input
              value={newPageTitle}
              onChange={(e) => setNewPageTitle(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') createPage();
                if (e.key === 'Escape') setCreatingPage(false);
              }}
              placeholder="Page title..."
              autoFocus
              style={{
                flex: 1,
                padding: '6px 10px',
                borderRadius: 6,
                border: '1px solid #2563eb',
                fontSize: 12,
                outline: 'none',
                color: '#0f172a',
              }}
            />
            <button
              onClick={createPage}
              style={{
                padding: '6px 10px',
                borderRadius: 6,
                background: '#2563eb',
                color: '#ffffff',
                border: 'none',
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
              }}
            >
              <Check size={13} />
            </button>
            <button
              onClick={() => setCreatingPage(false)}
              style={{
                padding: '6px',
                borderRadius: 6,
                background: 'transparent',
                color: '#64748b',
                border: 'none',
                cursor: 'pointer',
              }}
            >
              <X size={13} />
            </button>
          </div>
        )}

        {/* Pages List */}
        <div style={{ flex: 1, overflowY: 'auto', padding: 8, display: 'flex', flexDirection: 'column', gap: 4 }}>
          {loading ? (
            <div style={{ padding: 24, textAlign: 'center', fontSize: 12, color: '#64748b' }}>
              Loading pages...
            </div>
          ) : pages.length === 0 ? (
            <div style={{ padding: 24, textAlign: 'center', fontSize: 12, color: '#64748b' }}>
              No doc pages found.
            </div>
          ) : (
            pages.map((p) => {
              const isSelected = selectedPage?.id === p.id;
              return (
                <div
                  key={p.id}
                  onClick={() => loadPage(p.id)}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: 10,
                    padding: '10px 12px',
                    borderRadius: 10,
                    cursor: 'pointer',
                    background: isSelected ? '#ffffff' : 'transparent',
                    border: isSelected ? '1px solid #e2e8f0' : '1px solid transparent',
                    boxShadow: isSelected ? '0 1px 3px rgba(0,0,0,0.05)' : 'none',
                    transition: 'all 0.15s ease',
                  }}
                  onMouseEnter={(e) => {
                    if (!isSelected) e.currentTarget.style.background = 'rgba(255, 255, 255, 0.6)';
                  }}
                  onMouseLeave={(e) => {
                    if (!isSelected) e.currentTarget.style.background = 'transparent';
                  }}
                >
                  <span style={{ fontSize: 18, flexShrink: 0 }}>{p.icon || '📄'}</span>
                  <div style={{ minWidth: 0, flex: 1 }}>
                    <div
                      style={{
                        fontSize: 13,
                        fontWeight: isSelected ? 700 : 500,
                        color: isSelected ? '#0f172a' : '#475569',
                        overflow: 'hidden',
                        textOverflow: 'ellipsis',
                        whiteSpace: 'nowrap',
                      }}
                    >
                      {p.title}
                    </div>
                    <div
                      style={{
                        fontSize: 10,
                        color: '#94a3b8',
                        fontFamily: 'monospace',
                        marginTop: 2,
                        overflow: 'hidden',
                        textOverflow: 'ellipsis',
                        whiteSpace: 'nowrap',
                      }}
                    >
                      /{p.slug} &bull; {p.blockCount || p.blocks?.length || 0} blocks
                    </div>
                  </div>
                  {isSelected && (
                    <div
                      style={{
                        width: 4,
                        height: 16,
                        borderRadius: 2,
                        background: '#2563eb',
                        flexShrink: 0,
                      }}
                    />
                  )}
                </div>
              );
            })
          )}
        </div>
      </aside>

      {/* 2. MAIN DOCUMENT CANVAS */}
      <main
        style={{
          flex: 1,
          display: 'flex',
          flexDirection: 'column',
          minWidth: 0,
          background: '#ffffff',
          overflowY: 'auto',
        }}
      >
        {selectedPage ? (
          <>
            {/* Document Header Toolbar */}
            <div
              style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                padding: '14px 28px',
                borderBottom: '1px solid #e2e8f0',
                background: '#ffffff',
                position: 'sticky',
                top: 0,
                zIndex: 20,
              }}
            >
              <div style={{ minWidth: 0 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 11, color: '#64748b', marginBottom: 2 }}>
                  <span>Documentation</span>
                  <ChevronRight size={12} />
                  <span style={{ color: '#0f172a', fontWeight: 600 }}>{selectedPage.title}</span>
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                  <span style={{ fontSize: 20 }}>{selectedPage.icon || '📄'}</span>
                  <h1 style={{ margin: 0, fontSize: 18, fontWeight: 800, color: '#0f172a', letterSpacing: '-0.02em' }}>
                    {selectedPage.title}
                  </h1>
                  <span
                    style={{
                      fontFamily: 'monospace',
                      fontSize: 11,
                      color: '#64748b',
                      background: '#f8fafc',
                      padding: '2px 8px',
                      borderRadius: 6,
                      border: '1px solid #e2e8f0',
                    }}
                  >
                    /{selectedPage.slug}
                  </span>
                </div>
              </div>

              {/* Action Toolbar */}
              <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                <button
                  onClick={() => setShowSlashMenu(!showSlashMenu)}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: 6,
                    padding: '7px 12px',
                    borderRadius: 8,
                    background: '#eff6ff',
                    border: '1px solid #bfdbfe',
                    color: '#2563eb',
                    fontSize: 12,
                    fontWeight: 600,
                    cursor: 'pointer',
                    boxShadow: '0 1px 2px rgba(37,99,235,0.06)',
                  }}
                >
                  <Slash size={13} />
                  <span>Insert Block</span>
                </button>

                <button
                  onClick={exportMarkdown}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: 6,
                    padding: '7px 12px',
                    borderRadius: 8,
                    background: '#ffffff',
                    border: '1px solid #cbd5e1',
                    color: '#0f172a',
                    fontSize: 12,
                    fontWeight: 600,
                    cursor: 'pointer',
                    boxShadow: '0 1px 2px rgba(0,0,0,0.04)',
                  }}
                >
                  {copiedMd ? <Check size={13} color="#059669" /> : <Copy size={13} color="#64748b" />}
                  <span>{copiedMd ? 'Copied MD' : 'Export MD'}</span>
                </button>
              </div>
            </div>

            {/* Slash Menu Popover */}
            {showSlashMenu && (
              <div
                style={{
                  margin: '12px 28px 0',
                  padding: 14,
                  borderRadius: 14,
                  background: '#ffffff',
                  border: '1px solid #e2e8f0',
                  boxShadow: '0 10px 25px -5px rgba(0,0,0,0.1), 0 8px 10px -6px rgba(0,0,0,0.1)',
                }}
              >
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 }}>
                  <span style={{ fontSize: 11, fontWeight: 700, textTransform: 'uppercase', color: '#64748b', letterSpacing: '0.04em' }}>
                    Select Block Type to Insert
                  </span>
                  <button
                    onClick={() => setShowSlashMenu(false)}
                    style={{ background: 'transparent', border: 'none', cursor: 'pointer', color: '#94a3b8' }}
                  >
                    <X size={14} />
                  </button>
                </div>

                <div
                  style={{
                    display: 'grid',
                    gridTemplateColumns: 'repeat(auto-fill, minmax(160px, 1fr))',
                    gap: 8,
                  }}
                >
                  {slashOptions.map((opt) => {
                    const IconComp = opt.icon;
                    return (
                      <button
                        key={opt.id}
                        onClick={() => addBlock(opt.id)}
                        style={{
                          display: 'flex',
                          alignItems: 'center',
                          gap: 10,
                          padding: '8px 12px',
                          borderRadius: 10,
                          background: '#f8fafc',
                          border: '1px solid #e2e8f0',
                          cursor: 'pointer',
                          textAlign: 'left',
                          transition: 'all 0.15s ease',
                        }}
                        onMouseEnter={(e) => {
                          e.currentTarget.style.background = '#eff6ff';
                          e.currentTarget.style.borderColor = '#bfdbfe';
                        }}
                        onMouseLeave={(e) => {
                          e.currentTarget.style.background = '#f8fafc';
                          e.currentTarget.style.borderColor = '#e2e8f0';
                        }}
                      >
                        <div
                          style={{
                            width: 30,
                            height: 30,
                            borderRadius: 8,
                            background: '#ffffff',
                            border: '1px solid #e2e8f0',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            flexShrink: 0,
                          }}
                        >
                          <IconComp size={15} className={opt.color} />
                        </div>
                        <div style={{ minWidth: 0 }}>
                          <div style={{ fontSize: 12, fontWeight: 700, color: '#0f172a' }}>{opt.label}</div>
                          <div style={{ fontSize: 10, color: '#64748b' }}>{opt.desc}</div>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Document Content Flow (Centered Reading View) */}
            <div
              style={{
                maxWidth: 780,
                width: '100%',
                margin: '0 auto',
                padding: '36px 32px 100px',
                display: 'flex',
                flexDirection: 'column',
                gap: 18,
              }}
            >
              {selectedPage.blocks.length === 0 ? (
                <div
                  style={{
                    padding: '48px 24px',
                    textAlign: 'center',
                    border: '2px dashed #cbd5e1',
                    borderRadius: 16,
                    color: '#64748b',
                    fontSize: 13,
                  }}
                >
                  This document has no content yet. Click &quot;Insert Block&quot; above to start writing.
                </div>
              ) : (
                selectedPage.blocks.map((block) => {
                  const isEditing = editingBlock === block.id;
                  const isHovered = hoveredBlockId === block.id;

                  return (
                    <div
                      key={block.id}
                      onMouseEnter={() => setHoveredBlockId(block.id)}
                      onMouseLeave={() => setHoveredBlockId(null)}
                      style={{
                        position: 'relative',
                        padding: '4px 8px',
                        borderRadius: 8,
                        transition: 'background 0.15s ease',
                        background: isHovered && !isEditing ? '#f8fafc' : 'transparent',
                      }}
                    >
                      {/* Floating Gutter Actions (Visible ONLY on hover) */}
                      {isHovered && !isEditing && (
                        <div
                          style={{
                            position: 'absolute',
                            right: 8,
                            top: -12,
                            zIndex: 10,
                            display: 'flex',
                            alignItems: 'center',
                            gap: 4,
                            padding: '3px 6px',
                            borderRadius: 6,
                            background: '#ffffff',
                            border: '1px solid #cbd5e1',
                            boxShadow: '0 2px 6px rgba(0,0,0,0.06)',
                          }}
                        >
                          <button
                            onClick={() => {
                              setEditingBlock(block.id);
                              setEditingContent(block.content);
                            }}
                            title="Edit block"
                            style={{
                              padding: '3px 6px',
                              borderRadius: 4,
                              background: 'transparent',
                              border: 'none',
                              color: '#475569',
                              fontSize: 11,
                              fontWeight: 600,
                              cursor: 'pointer',
                              display: 'flex',
                              alignItems: 'center',
                              gap: 3,
                            }}
                          >
                            <Edit3 size={11} />
                            <span>Edit</span>
                          </button>
                          <div style={{ width: 1, height: 12, background: '#e2e8f0' }} />
                          <button
                            onClick={() => deleteBlock(block.id)}
                            title="Delete block"
                            style={{
                              padding: '3px 6px',
                              borderRadius: 4,
                              background: 'transparent',
                              border: 'none',
                              color: '#dc2626',
                              fontSize: 11,
                              fontWeight: 600,
                              cursor: 'pointer',
                              display: 'flex',
                              alignItems: 'center',
                              gap: 3,
                            }}
                          >
                            <Trash2 size={11} />
                            <span>Delete</span>
                          </button>
                        </div>
                      )}

                      {/* Editing Mode */}
                      {isEditing ? (
                        <div
                          style={{
                            display: 'flex',
                            flexDirection: 'column',
                            gap: 8,
                            padding: 12,
                            borderRadius: 10,
                            background: '#ffffff',
                            border: '1.5px solid #2563eb',
                            boxShadow: '0 2px 8px rgba(37,99,235,0.08)',
                          }}
                        >
                          <textarea
                            value={editingContent}
                            onChange={(e) => setEditingContent(e.target.value)}
                            onKeyDown={(e) => {
                              if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) {
                                updateBlock(block.id);
                              }
                              if (e.key === 'Escape') setEditingBlock(null);
                            }}
                            autoFocus
                            rows={block.type === 'code' ? 6 : 3}
                            style={{
                              width: '100%',
                              padding: '8px 10px',
                              borderRadius: 6,
                              border: '1px solid #cbd5e1',
                              fontSize: 13,
                              color: '#0f172a',
                              fontFamily: block.type === 'code' ? 'JetBrains Mono, monospace' : 'inherit',
                              outline: 'none',
                              boxSizing: 'border-box',
                            }}
                          />
                          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'flex-end', gap: 6 }}>
                            <button
                              onClick={() => setEditingBlock(null)}
                              style={{
                                padding: '5px 10px',
                                borderRadius: 6,
                                background: '#f8fafc',
                                border: '1px solid #cbd5e1',
                                fontSize: 11,
                                fontWeight: 600,
                                color: '#475569',
                                cursor: 'pointer',
                              }}
                            >
                              Cancel
                            </button>
                            <button
                              onClick={() => updateBlock(block.id)}
                              style={{
                                padding: '5px 12px',
                                borderRadius: 6,
                                background: '#2563eb',
                                border: 'none',
                                fontSize: 11,
                                fontWeight: 600,
                                color: '#ffffff',
                                cursor: 'pointer',
                              }}
                            >
                              Save Changes
                            </button>
                          </div>
                        </div>
                      ) : (
                        /* Read View for Block */
                        <div
                          onClick={() => {
                            setEditingBlock(block.id);
                            setEditingContent(block.content);
                          }}
                          style={{ cursor: 'text' }}
                        >
                          {block.type === 'heading' && (
                            <h2
                              style={{
                                margin: '8px 0',
                                fontSize: 24,
                                fontWeight: 800,
                                color: '#0f172a',
                                letterSpacing: '-0.025em',
                                lineHeight: 1.3,
                              }}
                            >
                              {block.content}
                            </h2>
                          )}

                          {block.type === 'subheading' && (
                            <h3
                              style={{
                                margin: '6px 0',
                                fontSize: 18,
                                fontWeight: 700,
                                color: '#1e293b',
                                letterSpacing: '-0.015em',
                              }}
                            >
                              {block.content}
                            </h3>
                          )}

                          {block.type === 'paragraph' && (
                            <p
                              style={{
                                margin: '4px 0',
                                fontSize: 14,
                                lineHeight: 1.65,
                                color: '#334155',
                              }}
                            >
                              {block.content}
                            </p>
                          )}

                          {block.type === 'callout' && (
                            <div
                              style={{
                                display: 'flex',
                                alignItems: 'flex-start',
                                gap: 12,
                                padding: '14px 18px',
                                borderRadius: 12,
                                background: '#fffbeb',
                                border: '1px solid #fde68a',
                                color: '#92400e',
                                margin: '8px 0',
                              }}
                            >
                              <Lightbulb size={18} style={{ color: '#d97706', flexShrink: 0, marginTop: 2 }} />
                              <div style={{ fontSize: 13, lineHeight: 1.5, fontWeight: 500 }}>
                                {block.content}
                              </div>
                            </div>
                          )}

                          {block.type === 'code' && (
                            <div
                              style={{
                                margin: '10px 0',
                                borderRadius: 12,
                                background: '#090d16',
                                border: '1px solid #1e293b',
                                overflow: 'hidden',
                                boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
                              }}
                            >
                              <div
                                style={{
                                  display: 'flex',
                                  alignItems: 'center',
                                  justifyContent: 'space-between',
                                  padding: '8px 14px',
                                  background: '#0f172a',
                                  borderBottom: '1px solid #1e293b',
                                }}
                              >
                                <span style={{ fontSize: 10, fontWeight: 700, color: '#94a3b8', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                                  Terminal / Code Snippet
                                </span>
                                <button
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    navigator.clipboard.writeText(block.content);
                                  }}
                                  style={{
                                    display: 'flex',
                                    alignItems: 'center',
                                    gap: 4,
                                    fontSize: 10,
                                    fontWeight: 600,
                                    color: '#cbd5e1',
                                    background: 'rgba(255,255,255,0.08)',
                                    padding: '3px 8px',
                                    borderRadius: 4,
                                    border: 'none',
                                    cursor: 'pointer',
                                  }}
                                >
                                  <Copy size={11} />
                                  <span>Copy</span>
                                </button>
                              </div>
                              <pre
                                style={{
                                  margin: 0,
                                  padding: 16,
                                  fontSize: 13,
                                  lineHeight: 1.6,
                                  fontFamily: 'JetBrains Mono, monospace',
                                  color: '#38bdf8',
                                  overflowX: 'auto',
                                }}
                              >
                                <code>{block.content}</code>
                              </pre>
                            </div>
                          )}

                          {block.type === 'token-swatch' && (
                            <div
                              style={{
                                display: 'flex',
                                alignItems: 'center',
                                gap: 12,
                                padding: '12px 16px',
                                borderRadius: 12,
                                background: '#f8fafc',
                                border: '1px solid #e2e8f0',
                                margin: '8px 0',
                              }}
                            >
                              <div
                                style={{
                                  width: 36,
                                  height: 36,
                                  borderRadius: 8,
                                  background: '#2563eb',
                                  border: '1px solid rgba(0,0,0,0.1)',
                                  boxShadow: '0 2px 4px rgba(0,0,0,0.08)',
                                  flexShrink: 0,
                                }}
                              />
                              <div>
                                <code style={{ fontSize: 13, fontWeight: 700, color: '#0f172a', fontFamily: 'monospace' }}>
                                  {block.content}
                                </code>
                                <div style={{ fontSize: 11, color: '#64748b', marginTop: 2 }}>
                                  Active Living Token Reference
                                </div>
                              </div>
                            </div>
                          )}

                          {block.type === 'quote' && (
                            <blockquote
                              style={{
                                margin: '8px 0',
                                paddingLeft: 16,
                                borderLeft: '3px solid #6366f1',
                                fontStyle: 'italic',
                                fontSize: 14,
                                color: '#475569',
                                lineHeight: 1.6,
                              }}
                            >
                              &ldquo;{block.content}&rdquo;
                            </blockquote>
                          )}

                          {block.type === 'divider' && (
                            <hr style={{ margin: '20px 0', border: 'none', borderTop: '1px solid #e2e8f0' }} />
                          )}

                          {!['heading', 'subheading', 'paragraph', 'callout', 'code', 'quote', 'token-swatch', 'divider'].includes(block.type) && (
                            <div style={{ fontSize: 14, color: '#334155', lineHeight: 1.6 }}>
                              {block.content}
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  );
                })
              )}
            </div>
          </>
        ) : (
          <div
            style={{
              flex: 1,
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              justifyContent: 'center',
              padding: 48,
              textAlign: 'center',
              color: '#64748b',
            }}
          >
            <FileText size={48} style={{ color: '#cbd5e1', marginBottom: 12 }} strokeWidth={1.5} />
            <h3 style={{ margin: 0, fontSize: 16, fontWeight: 700, color: '#0f172a' }}>
              Nexus Living Documentation Editor
            </h3>
            <p style={{ margin: '6px 0 0', fontSize: 13, color: '#64748b', maxWidth: 360 }}>
              Select a documentation page from the sidebar to review, edit, or publish with live design tokens.
            </p>
          </div>
        )}
      </main>
    </div>
  );
}
