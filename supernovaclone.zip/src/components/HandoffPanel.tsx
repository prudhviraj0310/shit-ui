'use client';

import React, { useState, useEffect } from 'react';
import { Monitor, Apple, Smartphone, Copy, Check, Search, Layers, Box, Terminal } from 'lucide-react';

const API_KEY = 'nexus_api_key_for_testing_min24chars';

interface HandoffToken {
  path: string;
  category: string;
  type: string;
  rawValue: string;
  platforms: { web: string; ios: string; android: string; flutter: string };
}

interface HandoffComponent {
  name: string;
  description: string;
  props: any[];
  variants: any[];
  tokens: string[];
  accessibility?: any;
}

interface HandoffSpec {
  name: string;
  tokens: HandoffToken[];
  components: HandoffComponent[];
  platforms: { platform: string; installCommand: string; usageExample: string }[];
  accessibility: any[];
}

export function HandoffPanel() {
  const [spec, setSpec] = useState<HandoffSpec | null>(null);
  const [view, setView] = useState<'full' | 'tokens' | 'platforms' | 'accessibility'>('full');
  const [loading, setLoading] = useState(true);
  const [selectedPlatform, setSelectedPlatform] = useState<'web' | 'ios' | 'android' | 'flutter'>('web');
  const [searchFilter, setSearchFilter] = useState('');
  const [copiedRef, setCopiedRef] = useState<string | null>(null);

  useEffect(() => {
    setLoading(true);
    fetch(`/api/handoff?view=${view}`, { headers: { 'x-api-key': API_KEY } })
      .then(r => r.json())
      .then(d => { setSpec(d.data); setLoading(false); })
      .catch(console.error);
  }, [view]);

  function copyRef(ref: string) {
    navigator.clipboard.writeText(ref);
    setCopiedRef(ref);
    setTimeout(() => setCopiedRef(null), 2000);
  }

  if (loading || !spec) {
    return (
      <div className="nexus-card bg-white border border-[#e2e8f0] rounded-2xl p-16 flex flex-col items-center justify-center text-center shadow-xs">
        <div className="w-12 h-12 rounded-2xl bg-indigo-50 border border-indigo-100 flex items-center justify-center text-indigo-600 mb-4 animate-pulse">
          <Monitor className="w-6 h-6" />
        </div>
        <div className="text-base font-semibold text-[#0f172a]">Loading Developer Handoff Spec...</div>
        <div className="text-xs text-[#64748b] mt-1">Generating multi-platform code references and token schemas</div>
      </div>
    );
  }

  const platformMeta = {
    web: { label: 'Web & CSS', color: 'text-amber-700 bg-amber-50 border-amber-200', activeBg: 'bg-amber-600 text-white', icon: Monitor },
    ios: { label: 'iOS (SwiftUI)', color: 'text-indigo-700 bg-indigo-50 border-indigo-200', activeBg: 'bg-indigo-600 text-white', icon: Apple },
    android: { label: 'Android (Compose)', color: 'text-emerald-700 bg-emerald-50 border-emerald-200', activeBg: 'bg-emerald-600 text-white', icon: Smartphone },
    flutter: { label: 'Flutter (Dart)', color: 'text-cyan-700 bg-cyan-50 border-cyan-200', activeBg: 'bg-cyan-600 text-white', icon: Smartphone },
  };

  const filteredTokens = (spec.tokens || []).filter(t =>
    !searchFilter || t.path.toLowerCase().includes(searchFilter.toLowerCase())
  );

  const currentPlatformSpec = spec.platforms?.find(p => p.platform === selectedPlatform);

  return (
    <div className="space-y-6">
      {/* Header Card */}
      <div className="nexus-card p-6 rounded-2xl border border-[#e2e8f0] bg-white flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-xs">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-indigo-50 border border-indigo-100 flex items-center justify-center text-indigo-600 shadow-2xs">
            <Monitor className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-xl font-bold tracking-tight text-[#0f172a]">Developer Handoff</h2>
              <span className="text-[11px] font-mono px-2 py-0.5 rounded-full bg-indigo-50 text-indigo-700 font-semibold border border-indigo-100">
                Multi-Platform
              </span>
            </div>
            <p className="text-xs text-[#64748b] mt-0.5">
              Production-ready code references, packages, and type bindings for every design token
            </p>
          </div>
        </div>

        {/* Platform Selector Pills */}
        <div className="flex items-center p-1 rounded-xl bg-[#f8fafc] border border-[#e2e8f0]">
          {(['web', 'ios', 'android', 'flutter'] as const).map(p => {
            const isSelected = selectedPlatform === p;
            const IconComp = platformMeta[p].icon;
            return (
              <button
                key={p}
                onClick={() => setSelectedPlatform(p)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                  isSelected
                    ? `${platformMeta[p].activeBg} shadow-2xs`
                    : 'text-[#64748b] hover:text-[#0f172a]'
                }`}
              >
                <IconComp className="w-3.5 h-3.5" />
                <span>{platformMeta[p].label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Package Install Banner */}
      {currentPlatformSpec && (
        <div className="nexus-card rounded-2xl border border-[#e2e8f0] bg-white p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-xs">
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-9 h-9 rounded-xl bg-slate-900 text-slate-100 flex items-center justify-center shrink-0">
              <Terminal className="w-4 h-4" />
            </div>
            <div className="min-w-0">
              <div className="text-[10px] font-bold uppercase tracking-wider text-[#64748b]">
                Install Package ({selectedPlatform.toUpperCase()})
              </div>
              <code className="text-xs font-mono font-semibold text-[#0f172a] block truncate mt-0.5">
                {currentPlatformSpec.installCommand || 'N/A'}
              </code>
            </div>
          </div>
          <button
            onClick={() => copyRef(currentPlatformSpec.installCommand || '')}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-[#cbd5e1] bg-[#f8fafc] hover:bg-[#f1f5f9] text-[#0f172a] text-xs font-medium transition-all shrink-0 cursor-pointer shadow-2xs"
          >
            {copiedRef === currentPlatformSpec.installCommand ? (
              <>
                <Check className="w-3.5 h-3.5 text-emerald-600" />
                <span className="text-emerald-700 font-semibold">Copied!</span>
              </>
            ) : (
              <>
                <Copy className="w-3.5 h-3.5 text-[#64748b]" />
                <span>Copy Command</span>
              </>
            )}
          </button>
        </div>
      )}

      {/* Search and Filter */}
      <div className="flex items-center gap-3">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-[#94a3b8] absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            value={searchFilter}
            onChange={e => setSearchFilter(e.target.value)}
            placeholder="Search tokens by name or path (e.g. color.brand, spacing.4)..."
            className="w-full pl-9 pr-4 py-2.5 rounded-xl bg-white border border-[#cbd5e1] text-[#0f172a] placeholder-[#94a3b8] text-xs focus:outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-100 transition-all shadow-2xs"
          />
        </div>
        <div className="text-xs text-[#64748b] font-medium shrink-0">
          Showing <span className="font-bold text-[#0f172a]">{filteredTokens.length}</span> tokens
        </div>
      </div>

      {/* Token Reference Table */}
      <div className="nexus-card rounded-2xl border border-[#e2e8f0] bg-white overflow-hidden shadow-xs">
        <div className="grid grid-cols-12 gap-3 px-5 py-3 bg-[#f8fafc] border-b border-[#e2e8f0] text-[11px] font-bold text-[#64748b] uppercase tracking-wider">
          <div className="col-span-1 text-center">Preview</div>
          <div className="col-span-4">Token Path</div>
          <div className="col-span-2">Raw Value</div>
          <div className="col-span-4">{selectedPlatform.toUpperCase()} Code Binding</div>
          <div className="col-span-1 text-right">Copy</div>
        </div>

        <div className="divide-y divide-[#e2e8f0] max-h-[460px] overflow-y-auto">
          {filteredTokens.length === 0 ? (
            <div className="p-12 text-center text-xs text-[#64748b]">
              No tokens found matching &quot;{searchFilter}&quot;
            </div>
          ) : (
            filteredTokens.map((t, idx) => {
              const ref = t.platforms[selectedPlatform] || 'N/A';
              const isColor = t.category === 'color';
              const uniqueKey = `${t.path}-${idx}`;
              const isCopied = copiedRef === ref;

              return (
                <div
                  key={uniqueKey}
                  className="grid grid-cols-12 gap-3 px-5 py-3 items-center hover:bg-[#f8fafc] transition-colors"
                >
                  {/* Swatch */}
                  <div className="col-span-1 flex justify-center">
                    {isColor ? (
                      <div
                        className="w-6 h-6 rounded-lg border border-[#cbd5e1] shadow-2xs"
                        style={{ background: t.rawValue }}
                        title={t.rawValue}
                      />
                    ) : (
                      <span className="text-xs text-[#94a3b8] font-mono">--</span>
                    )}
                  </div>

                  {/* Token Path */}
                  <div className="col-span-4 min-w-0">
                    <span className="font-mono text-xs font-semibold text-[#0f172a] block truncate">
                      {t.path}
                    </span>
                    <span className="text-[10px] text-[#64748b] capitalize">{t.category}</span>
                  </div>

                  {/* Raw Value */}
                  <div className="col-span-2 min-w-0">
                    <span className="font-mono text-xs text-[#475569] block truncate">
                      {t.rawValue}
                    </span>
                  </div>

                  {/* Platform Code Binding */}
                  <div className="col-span-4 min-w-0">
                    <code className="text-xs font-mono font-semibold text-indigo-700 bg-indigo-50/70 border border-indigo-100 px-2 py-0.5 rounded-md block truncate">
                      {ref}
                    </code>
                  </div>

                  {/* Action */}
                  <div className="col-span-1 flex justify-end">
                    <button
                      onClick={() => copyRef(ref)}
                      className="p-1.5 rounded-lg border border-[#e2e8f0] bg-white hover:bg-[#f1f5f9] text-[#64748b] hover:text-[#0f172a] transition-all cursor-pointer shadow-2xs"
                      title="Copy binding"
                    >
                      {isCopied ? (
                        <Check className="w-3.5 h-3.5 text-emerald-600" />
                      ) : (
                        <Copy className="w-3.5 h-3.5" />
                      )}
                    </button>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>

      {/* Component Specs Section */}
      {spec.components && spec.components.length > 0 && (
        <div className="nexus-card rounded-2xl border border-[#e2e8f0] bg-white p-6 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-[#e2e8f0]">
            <div className="flex items-center gap-2">
              <Box className="w-4 h-4 text-indigo-600" />
              <h3 className="text-sm font-bold text-[#0f172a]">
                Component Specifications ({spec.components.length})
              </h3>
            </div>
            <span className="text-xs text-[#64748b]">Connected Design Tokens</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {spec.components.map((c, cIdx) => (
              <div
                key={`${c.name}-${cIdx}`}
                className="p-4 rounded-xl border border-[#e2e8f0] bg-[#f8fafc] space-y-3"
              >
                <div>
                  <div className="font-bold text-sm text-[#0f172a]">{c.name}</div>
                  <div className="text-xs text-[#64748b] mt-0.5">{c.description}</div>
                </div>

                {/* Props */}
                {c.props && c.props.length > 0 && (
                  <div>
                    <div className="text-[10px] uppercase font-bold text-[#64748b] tracking-wider mb-1.5">
                      Props
                    </div>
                    <div className="space-y-1">
                      {c.props.map((p: any, pIdx: number) => (
                        <div key={`${p.name}-${pIdx}`} className="text-xs font-mono text-[#475569]">
                          <span className="font-semibold text-[#0f172a]">{p.name}</span>:{' '}
                          <span className="text-indigo-600">{p.type}</span>
                          {p.default !== undefined && (
                            <span className="text-[#94a3b8]"> = {String(p.default)}</span>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Tokens */}
                {c.tokens && c.tokens.length > 0 && (
                  <div>
                    <div className="text-[10px] uppercase font-bold text-[#64748b] tracking-wider mb-1.5">
                      Linked Design Tokens
                    </div>
                    <div className="flex flex-wrap gap-1.5">
                      {c.tokens.map((tok, tokIdx) => (
                        <span
                          key={`${tok}-${tokIdx}`}
                          className="text-[11px] font-mono px-2 py-0.5 rounded-md bg-white border border-[#e2e8f0] text-indigo-700 shadow-2xs"
                        >
                          {tok}
                        </span>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

