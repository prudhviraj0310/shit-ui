'use client';

import React, { useState, useEffect } from 'react';
import {
  Layers, CheckCircle2, Clock, AlertTriangle, Archive, Plus,
  Search, Filter, RefreshCw, ArrowRight, ArrowLeft, Tag, Code2,
  BookOpen, Laptop, Tablet, Smartphone, Sliders, ExternalLink, Play
} from 'lucide-react';
import { StorybookStory, StorybookComponentGroup } from '@/core/components/storybook';

interface ComponentItem {
  id: string;
  name: string;
  category: string;
  framework: string;
  status: 'backlog' | 'in_progress' | 'ready' | 'deprecated';
  description?: string | null;
  isDeprecated: boolean;
  createdAt: string;
}

interface BoardData {
  totalCount: number;
  columns: {
    backlog: ComponentItem[];
    in_progress: ComponentItem[];
    ready: ComponentItem[];
    deprecated: ComponentItem[];
  };
  metrics: {
    healthScore: number;
    readyCount: number;
    inProgressCount: number;
    backlogCount: number;
    deprecatedCount: number;
  };
}

export function ComponentStatusBoard() {
  const [activeTab, setActiveTab] = useState<'board' | 'storybook'>('board');
  const [boardData, setBoardData] = useState<BoardData | null>(null);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [newCompName, setNewCompName] = useState('');
  const [newCompCategory, setNewCompCategory] = useState('inputs');
  const [newCompDesc, setNewCompDesc] = useState('');
  const [newCompStatus, setNewCompStatus] = useState<'backlog' | 'in_progress' | 'ready'>('in_progress');
  const [updatingId, setUpdatingId] = useState<string | null>(null);

  // Storybook State
  const [storybookGroups, setStorybookGroups] = useState<StorybookComponentGroup[]>([]);
  const [selectedStory, setSelectedStory] = useState<StorybookStory | null>(null);
  const [storybookArgs, setStorybookArgs] = useState<Record<string, any>>({});
  const [viewportMode, setViewportMode] = useState<'desktop' | 'tablet' | 'mobile'>('desktop');
  const [storybookUrlInput, setStorybookUrlInput] = useState('');
  const [storybookLoading, setStorybookLoading] = useState(false);

  const fetchBoard = async () => {
    try {
      setLoading(true);
      const res = await fetch('/api/components/status?designSystemId=ds-nova-design', {
        headers: { 'x-api-key': 'nexus_api_key_for_testing_min24chars' }
      });
      const data = await res.json();
      if (data.success) {
        setBoardData(data);
      }
    } catch (e) {
      console.error('Failed to load component board', e);
    } finally {
      setLoading(false);
    }
  };

  const fetchStorybookStories = async (customUrl?: string) => {
    try {
      setStorybookLoading(true);
      const res = await fetch('/api/components/storybook', {
        method: customUrl ? 'POST' : 'GET',
        headers: {
          'x-api-key': 'nexus_api_key_for_testing_min24chars',
          'Content-Type': 'application/json',
        },
        body: customUrl ? JSON.stringify({ storiesJsonUrlOrContent: customUrl }) : undefined,
      });
      const json = await res.json();
      const groups: StorybookComponentGroup[] = json.data?.components || json.components || [];
      setStorybookGroups(groups);
      if (groups.length > 0 && groups[0].stories.length > 0) {
        const firstStory = groups[0].stories[0];
        setSelectedStory(firstStory);
        setStorybookArgs(firstStory.args || {});
      }
    } catch (e) {
      console.error('Failed to load Storybook index', e);
    } finally {
      setStorybookLoading(false);
    }
  };

  useEffect(() => {
    fetchBoard();
    fetchStorybookStories();
  }, []);

  const moveStatus = async (componentId: string, nextStatus: 'backlog' | 'in_progress' | 'ready' | 'deprecated') => {
    try {
      setUpdatingId(componentId);
      const res = await fetch('/api/components/status', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-api-key': 'nexus_api_key_for_testing_min24chars'
        },
        body: JSON.stringify({ action: 'update', componentId, status: nextStatus })
      });
      const data = await res.json();
      if (data.success) {
        await fetchBoard();
      }
    } catch (e) {
      console.error('Failed to update status', e);
    } finally {
      setUpdatingId(null);
    }
  };

  const handleCreateComponent = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCompName.trim()) return;

    try {
      const res = await fetch('/api/components/status', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-api-key': 'nexus_api_key_for_testing_min24chars'
        },
        body: JSON.stringify({
          action: 'create',
          name: newCompName.trim(),
          category: newCompCategory,
          description: newCompDesc.trim(),
          status: newCompStatus,
        })
      });
      const data = await res.json();
      if (data.success) {
        setShowCreateModal(false);
        setNewCompName('');
        setNewCompDesc('');
        await fetchBoard();
      }
    } catch (err) {
      console.error('Failed to create component', err);
    }
  };

  const columnsConfig = [
    {
      key: 'backlog' as const,
      title: 'Backlog / Planned',
      badge: 'border-slate-200 bg-slate-100 text-slate-700',
      icon: Layers,
      next: 'in_progress' as const,
      prev: null,
    },
    {
      key: 'in_progress' as const,
      title: 'In Progress',
      badge: 'border-amber-200 bg-amber-50 text-amber-800',
      icon: Clock,
      next: 'ready' as const,
      prev: 'backlog' as const,
    },
    {
      key: 'ready' as const,
      title: 'Ready for Dev',
      badge: 'border-emerald-200 bg-emerald-50 text-emerald-800',
      icon: CheckCircle2,
      next: 'deprecated' as const,
      prev: 'in_progress' as const,
    },
    {
      key: 'deprecated' as const,
      title: 'Deprecated',
      badge: 'border-rose-200 bg-rose-50 text-rose-800',
      icon: Archive,
      next: null,
      prev: 'ready' as const,
    },
  ];

  const filterItem = (c: ComponentItem) => {
    const matchesSearch = c.name.toLowerCase().includes(search.toLowerCase()) ||
      (c.description || '').toLowerCase().includes(search.toLowerCase());
    const matchesCat = selectedCategory === 'all' || c.category === selectedCategory;
    return matchesSearch && matchesCat;
  };

  const categories = Array.from(
    new Set(
      boardData ? [
        ...boardData.columns.backlog,
        ...boardData.columns.in_progress,
        ...boardData.columns.ready,
        ...boardData.columns.deprecated,
      ].map(c => c.category) : []
    )
  );

  return (
    <div className="space-y-6 max-w-6xl mx-auto">
      {/* Header Card */}
      <div className="nexus-card p-6 rounded-2xl border border-[#e2e8f0]/90 bg-white flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-xs">
        <div className="flex items-center gap-3.5">
          <div className="p-3 rounded-xl bg-indigo-50 border border-indigo-200">
            <Layers className="w-6 h-6 text-indigo-600" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl font-bold text-[#0f172a] tracking-tight">Component Systems & Status</h1>
              <span className="px-2.5 py-0.5 rounded-full bg-indigo-50 text-indigo-700 text-[11px] font-semibold border border-indigo-200">
                CSF3 Ready
              </span>
            </div>
            <p className="text-xs text-[#64748b] mt-0.5">
              Track lifecycle governance and interact with live Storybook CSF3 component stories.
            </p>
          </div>
        </div>

        {/* Tab Switcher & Actions */}
        <div className="flex items-center gap-2.5">
          <div className="flex items-center p-1 rounded-xl bg-[#f8fafc] border border-[#e2e8f0]">
            <button
              onClick={() => setActiveTab('board')}
              className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg transition-all ${
                activeTab === 'board'
                  ? 'bg-white text-indigo-700 shadow-2xs font-bold'
                  : 'text-[#64748b] hover:text-[#0f172a]'
              }`}
            >
              <Layers className="w-3.5 h-3.5" />
              <span>Lifecycle Board</span>
            </button>
            <button
              onClick={() => setActiveTab('storybook')}
              className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg transition-all ${
                activeTab === 'storybook'
                  ? 'bg-white text-pink-700 shadow-2xs font-bold'
                  : 'text-[#64748b] hover:text-[#0f172a]'
              }`}
            >
              <BookOpen className="w-3.5 h-3.5" />
              <span>Storybook CSF3</span>
            </button>
          </div>

          {activeTab === 'board' ? (
            <>
              <button
                onClick={fetchBoard}
                className="btn-secondary text-xs py-2 px-3.5 flex items-center gap-1.5"
              >
                <RefreshCw className={`w-3.5 h-3.5 text-[#64748b] ${loading ? 'animate-spin' : ''}`} />
                <span>Refresh</span>
              </button>
              <button
                onClick={() => setShowCreateModal(true)}
                className="btn-primary text-xs py-2 px-4 rounded-xl flex items-center gap-1.5 shadow-xs"
              >
                <Plus className="w-4 h-4" />
                <span>Add Component</span>
              </button>
            </>
          ) : (
            <button
              onClick={() => fetchStorybookStories()}
              className="btn-secondary text-xs py-2 px-3.5 flex items-center gap-1.5"
            >
              <RefreshCw className={`w-3.5 h-3.5 text-[#64748b] ${storybookLoading ? 'animate-spin' : ''}`} />
              <span>Reload Stories</span>
            </button>
          )}
        </div>
      </div>

      {/* VIEW 1: KANBAN LIFECYCLE BOARD */}
      {activeTab === 'board' && (
        <>
          {/* Metric Cards */}
          {boardData && (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="nexus-card p-4 rounded-xl border border-[#e2e8f0] bg-white flex items-center justify-between shadow-2xs">
                <div>
                  <p className="text-xs font-bold uppercase tracking-wider text-[#64748b]">Health Score</p>
                  <p className="text-2xl font-extrabold text-emerald-600 mt-1">{boardData.metrics.healthScore}%</p>
                  <p className="text-xs text-[#64748b] mt-0.5">Production Ready Ratio</p>
                </div>
                <div className="w-12 h-12 rounded-full border-4 border-emerald-100 border-t-emerald-500 flex items-center justify-center font-bold text-xs text-emerald-700 bg-emerald-50">
                  {boardData.metrics.healthScore}%
                </div>
              </div>

              <div className="nexus-card p-4 rounded-xl border border-[#e2e8f0] bg-white shadow-2xs">
                <p className="text-xs font-bold uppercase tracking-wider text-[#64748b]">Ready for Dev</p>
                <p className="text-2xl font-extrabold text-[#0f172a] mt-1">{boardData.metrics.readyCount}</p>
                <p className="text-xs text-emerald-700 mt-0.5 flex items-center gap-1 font-medium">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" /> Approved in codebase
                </p>
              </div>

              <div className="nexus-card p-4 rounded-xl border border-[#e2e8f0] bg-white shadow-2xs">
                <p className="text-xs font-bold uppercase tracking-wider text-[#64748b]">In Progress</p>
                <p className="text-2xl font-extrabold text-amber-600 mt-1">{boardData.metrics.inProgressCount}</p>
                <p className="text-xs text-[#64748b] mt-0.5 flex items-center gap-1 font-medium">
                  <Clock className="w-3.5 h-3.5 text-amber-500" /> Active development
                </p>
              </div>

              <div className="nexus-card p-4 rounded-xl border border-[#e2e8f0] bg-white shadow-2xs">
                <p className="text-xs font-bold uppercase tracking-wider text-[#64748b]">Total Catalog</p>
                <p className="text-2xl font-extrabold text-[#0f172a] mt-1">{boardData.totalCount}</p>
                <p className="text-xs text-[#64748b] mt-0.5 flex items-center gap-1 font-medium">
                  <Tag className="w-3.5 h-3.5 text-indigo-500" /> Across React / Web
                </p>
              </div>
            </div>
          )}

          {/* Controls & Search */}
          <div className="flex flex-col sm:flex-row gap-3 items-center justify-between">
            <div className="relative w-full sm:w-80">
              <Search className="w-4 h-4 text-[#94a3b8] absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Filter components..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="w-full pl-9 pr-4 py-2 text-xs rounded-xl border border-[#cbd5e1] bg-white text-[#0f172a] placeholder-[#94a3b8] focus:outline-none focus:border-indigo-600 shadow-2xs"
              />
            </div>

            <div className="flex items-center gap-2 w-full sm:w-auto">
              <Filter className="w-4 h-4 text-[#64748b]" />
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="px-3 py-2 text-xs rounded-xl border border-[#cbd5e1] bg-white text-[#0f172a] focus:outline-none focus:border-indigo-600 font-medium shadow-2xs"
              >
                <option value="all">All Categories</option>
                {categories.map(c => (
                  <option key={c} value={c}>{c}</option>
                ))}
              </select>
            </div>
          </div>

          {/* Kanban Board Columns */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-5">
            {columnsConfig.map((col) => {
              const items = boardData ? boardData.columns[col.key].filter(filterItem) : [];
              const Icon = col.icon;

              return (
                <div key={col.key} className="flex flex-col bg-[#f8fafc] border border-[#e2e8f0] rounded-2xl p-4 min-h-[500px] shadow-2xs">
                  <div className="flex items-center justify-between pb-3 mb-3 border-b border-[#e2e8f0]">
                    <div className="flex items-center gap-2">
                      <Icon className="w-4 h-4 text-[#64748b]" />
                      <h3 className="text-xs font-bold uppercase tracking-wider text-[#0f172a]">{col.title}</h3>
                    </div>
                    <span className={`text-xs px-2 py-0.5 rounded-full border ${col.badge} font-bold`}>
                      {items.length}
                    </span>
                  </div>

                  <div className="flex-1 space-y-3 overflow-y-auto max-h-[700px] pr-1">
                    {items.map((item) => (
                      <div
                        key={item.id}
                        className="p-4 rounded-xl border border-[#e2e8f0] bg-white hover:border-[#cbd5e1] hover:shadow-xs transition-all shadow-2xs group"
                      >
                        <div className="flex items-start justify-between gap-2">
                          <div>
                            <span className="text-[10px] uppercase font-mono tracking-wider px-2 py-0.5 rounded-md bg-[#f1f5f9] text-[#475569] border border-[#e2e8f0] font-semibold">
                              {item.category}
                            </span>
                            <h4 className="text-sm font-bold text-[#0f172a] mt-1.5 group-hover:text-indigo-600 transition-colors">
                              {item.name}
                            </h4>
                          </div>
                          <span className="text-[11px] font-mono text-[#94a3b8] font-semibold">{item.framework}</span>
                        </div>

                        {item.description && (
                          <p className="text-xs text-[#64748b] mt-2 line-clamp-2 leading-relaxed">
                            {item.description}
                          </p>
                        )}

                        <div className="flex items-center justify-between pt-3 mt-3 border-t border-[#f1f5f9]">
                          {col.prev ? (
                            <button
                              onClick={() => moveStatus(item.id, col.prev as any)}
                              disabled={updatingId === item.id}
                              className="text-[11px] flex items-center gap-1 text-[#64748b] hover:text-[#0f172a] font-medium disabled:opacity-50"
                            >
                              <ArrowLeft className="w-3 h-3" /> Move Back
                            </button>
                          ) : <div />}

                          {col.next ? (
                            <button
                              onClick={() => moveStatus(item.id, col.next as any)}
                              disabled={updatingId === item.id}
                              className="text-[11px] flex items-center gap-1 text-indigo-600 hover:text-indigo-700 font-bold disabled:opacity-50"
                            >
                              Advance <ArrowRight className="w-3 h-3" />
                            </button>
                          ) : <div />}
                        </div>
                      </div>
                    ))}

                    {items.length === 0 && (
                      <div className="h-32 flex flex-col items-center justify-center border border-dashed border-[#cbd5e1] rounded-xl text-[#94a3b8] text-xs">
                        No components in {col.title.toLowerCase()}
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </>
      )}

      {/* VIEW 2: INTERACTIVE STORYBOOK CSF3 CANVAS */}
      {activeTab === 'storybook' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left Sidebar: Stories Tree */}
          <div className="lg:col-span-4 nexus-card bg-white border border-[#e2e8f0] rounded-2xl p-4 flex flex-col h-[740px] shadow-xs">
            <div className="flex items-center justify-between pb-3 mb-3 border-b border-[#e2e8f0]">
              <div className="flex items-center gap-2">
                <BookOpen className="w-4 h-4 text-pink-600" />
                <h3 className="text-xs font-bold uppercase tracking-wider text-[#0f172a]">Storybook Components</h3>
              </div>
              <span className="text-xs px-2.5 py-0.5 rounded-full bg-pink-50 text-pink-700 font-semibold border border-pink-200">
                CSF3 Ready
              </span>
            </div>

            {/* Custom URL Input */}
            <div className="mb-4">
              <div className="flex gap-2">
                <input
                  type="text"
                  placeholder="Import from stories.json URL..."
                  value={storybookUrlInput}
                  onChange={(e) => setStorybookUrlInput(e.target.value)}
                  className="flex-1 px-3 py-1.5 text-xs rounded-xl border border-[#cbd5e1] bg-[#f8fafc] text-[#0f172a] placeholder-[#94a3b8] focus:bg-white focus:outline-none"
                />
                <button
                  onClick={() => fetchStorybookStories(storybookUrlInput)}
                  className="px-3 py-1.5 rounded-xl bg-pink-600 hover:bg-pink-700 text-white text-xs font-semibold shadow-xs"
                >
                  Load
                </button>
              </div>
            </div>

            {/* Tree list */}
            <div className="flex-1 overflow-y-auto space-y-4 pr-1">
              {storybookGroups.map((group) => (
                <div key={group.title} className="space-y-1">
                  <div className="text-xs font-bold text-[#64748b] uppercase tracking-wider flex items-center justify-between px-2 py-1">
                    <span>{group.title}</span>
                    <span className="text-[10px] text-[#94a3b8] font-semibold">{group.stories.length} stories</span>
                  </div>
                  {group.stories.map((story) => {
                    const isSelected = selectedStory?.id === story.id;
                    return (
                      <button
                        key={story.id}
                        onClick={() => {
                          setSelectedStory(story);
                          setStorybookArgs(story.args || {});
                        }}
                        className={`w-full text-left px-3 py-2 rounded-xl text-xs font-medium flex items-center justify-between transition-colors ${
                          isSelected
                            ? 'bg-pink-50 text-pink-700 border border-pink-200 font-bold'
                            : 'text-[#475569] hover:bg-[#f8fafc]'
                        }`}
                      >
                        <span className="truncate">{story.name}</span>
                        <Play className={`w-3 h-3 ${isSelected ? 'text-pink-600 fill-pink-600' : 'text-[#cbd5e1]'}`} />
                      </button>
                    );
                  })}
                </div>
              ))}

              {storybookGroups.length === 0 && !storybookLoading && (
                <div className="p-8 text-center text-[#94a3b8] text-xs">
                  No Storybook components loaded. Enter a valid stories.json URL above.
                </div>
              )}
            </div>
          </div>

          {/* Right Area: Interactive Canvas & Controls Panel */}
          <div className="lg:col-span-8 flex flex-col gap-5">
            {selectedStory ? (
              <>
                {/* Canvas Toolbar */}
                <div className="flex items-center justify-between nexus-card bg-white border border-[#e2e8f0] rounded-2xl px-5 py-3.5 shadow-xs">
                  <div className="flex items-center gap-3">
                    <span className="text-sm font-bold text-[#0f172a]">{selectedStory.title}</span>
                    <span className="text-xs px-2.5 py-0.5 rounded-full bg-[#f1f5f9] text-[#475569] font-mono border border-[#e2e8f0]">
                      {selectedStory.name}
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    {/* Viewport Toggles */}
                    <div className="flex items-center p-1 rounded-xl bg-[#f8fafc] border border-[#e2e8f0]">
                      <button
                        onClick={() => setViewportMode('desktop')}
                        title="Desktop (100%)"
                        className={`p-1.5 rounded-lg ${viewportMode === 'desktop' ? 'bg-white text-indigo-600 shadow-2xs font-bold' : 'text-[#64748b] hover:text-[#0f172a]'}`}
                      >
                        <Laptop className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => setViewportMode('tablet')}
                        title="Tablet (768px)"
                        className={`p-1.5 rounded-lg ${viewportMode === 'tablet' ? 'bg-white text-indigo-600 shadow-2xs font-bold' : 'text-[#64748b] hover:text-[#0f172a]'}`}
                      >
                        <Tablet className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => setViewportMode('mobile')}
                        title="Mobile (375px)"
                        className={`p-1.5 rounded-lg ${viewportMode === 'mobile' ? 'bg-white text-indigo-600 shadow-2xs font-bold' : 'text-[#64748b] hover:text-[#0f172a]'}`}
                      >
                        <Smartphone className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    {selectedStory.iframeUrl && (
                      <a
                        href={selectedStory.iframeUrl}
                        target="_blank"
                        rel="noreferrer"
                        className="p-2 rounded-xl border border-[#e2e8f0] bg-white text-[#64748b] hover:text-[#0f172a] shadow-2xs"
                        title="Open in Storybook"
                      >
                        <ExternalLink className="w-3.5 h-3.5" />
                      </a>
                    )}
                  </div>
                </div>

                {/* Live Responsive Canvas */}
                <div className="nexus-card bg-[#f8fafc] border border-[#e2e8f0] rounded-2xl p-8 flex items-center justify-center min-h-[340px] overflow-hidden shadow-xs">
                  <div
                    style={{
                      width: viewportMode === 'mobile' ? '375px' : viewportMode === 'tablet' ? '768px' : '100%',
                      maxWidth: '100%',
                      transition: 'width 0.25s ease',
                    }}
                    className="flex items-center justify-center p-8 bg-white border border-[#e2e8f0] rounded-2xl shadow-sm"
                  >
                    {/* Interactive Component Render Simulation based on Props */}
                    {selectedStory.componentName.toLowerCase().includes('button') ? (
                      <button
                        disabled={Boolean(storybookArgs.disabled)}
                        style={{
                          padding: storybookArgs.size === 'small' ? '6px 12px' : storybookArgs.size === 'large' ? '12px 24px' : '10px 18px',
                          fontSize: storybookArgs.size === 'small' ? '12px' : storybookArgs.size === 'large' ? '16px' : '14px',
                          borderRadius: '8px',
                          fontWeight: 600,
                          cursor: storybookArgs.disabled ? 'not-allowed' : 'pointer',
                          opacity: storybookArgs.disabled ? 0.5 : 1,
                          background: storybookArgs.variant === 'secondary'
                            ? '#f1f5f9'
                            : storybookArgs.variant === 'destructive'
                              ? '#ef4444'
                              : storybookArgs.variant === 'ghost'
                                ? 'transparent'
                                : '#2563eb',
                          color: storybookArgs.variant === 'secondary' ? '#0f172a' : '#ffffff',
                          border: storybookArgs.variant === 'ghost' ? '1px solid #cbd5e1' : storybookArgs.variant === 'secondary' ? '1px solid #cbd5e1' : 'none',
                          boxShadow: storybookArgs.variant === 'primary' ? '0 4px 14px rgba(37,99,235,0.25)' : 'none',
                          transition: 'all 0.15s ease',
                        }}
                      >
                        {storybookArgs.label || 'Interactive Button'}
                      </button>
                    ) : selectedStory.componentName.toLowerCase().includes('badge') ? (
                      <span
                        style={{
                          padding: '4px 12px',
                          borderRadius: '20px',
                          fontSize: '12px',
                          fontWeight: 700,
                          background: storybookArgs.variant === 'success' ? '#ecfdf5' : '#eff6ff',
                          color: storybookArgs.variant === 'success' ? '#059669' : '#2563eb',
                          border: `1px solid ${storybookArgs.variant === 'success' ? '#a7f3d0' : '#bfdbfe'}`,
                        }}
                      >
                        {storybookArgs.text || 'Status Badge'}
                      </span>
                    ) : (
                      <div className="p-6 rounded-2xl bg-white border border-[#e2e8f0] text-center max-w-sm shadow-2xs">
                        <h5 className="text-base font-bold text-[#0f172a] mb-2">{storybookArgs.title || selectedStory.componentName}</h5>
                        <p className="text-xs text-[#64748b]">
                          {selectedStory.parameters?.docs?.description?.story || 'Rendered via Storybook CSF3 Canvas'}
                        </p>
                      </div>
                    )}
                  </div>
                </div>

                {/* Controls & Args Panel */}
                <div className="nexus-card bg-white border border-[#e2e8f0] rounded-2xl p-5 shadow-xs">
                  <div className="flex items-center gap-2 pb-3 mb-4 border-b border-[#e2e8f0]">
                    <Sliders className="w-4 h-4 text-indigo-600" />
                    <h4 className="text-xs font-bold text-[#0f172a] uppercase tracking-wider">
                      Interactive Props & Controls
                    </h4>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {Object.entries(storybookArgs).map(([key, val]) => (
                      <div key={key} className="space-y-1.5">
                        <label className="text-xs font-mono font-semibold text-[#475569] flex items-center justify-between">
                          <span>{key}</span>
                          <span className="text-[10px] text-[#94a3b8]">{typeof val}</span>
                        </label>
                        {typeof val === 'boolean' ? (
                          <button
                            onClick={() => setStorybookArgs(prev => ({ ...prev, [key]: !prev[key] }))}
                            className={`w-full px-3 py-2 text-xs font-semibold rounded-xl border text-left transition-colors ${
                              val
                                ? 'bg-indigo-50 border-indigo-200 text-indigo-700'
                                : 'bg-[#f8fafc] border-[#cbd5e1] text-[#64748b]'
                            }`}
                          >
                            {val ? 'true' : 'false'}
                          </button>
                        ) : typeof val === 'string' && ['primary', 'secondary', 'destructive', 'ghost'].includes(val) ? (
                          <select
                            value={val}
                            onChange={(e) => setStorybookArgs(prev => ({ ...prev, [key]: e.target.value }))}
                            className="w-full px-3 py-2 text-xs rounded-xl border border-[#cbd5e1] bg-[#f8fafc] text-[#0f172a] focus:bg-white focus:outline-none"
                          >
                            <option value="primary">primary</option>
                            <option value="secondary">secondary</option>
                            <option value="destructive">destructive</option>
                            <option value="ghost">ghost</option>
                          </select>
                        ) : typeof val === 'string' && ['small', 'medium', 'large'].includes(val) ? (
                          <select
                            value={val}
                            onChange={(e) => setStorybookArgs(prev => ({ ...prev, [key]: e.target.value }))}
                            className="w-full px-3 py-2 text-xs rounded-xl border border-[#cbd5e1] bg-[#f8fafc] text-[#0f172a] focus:bg-white focus:outline-none"
                          >
                            <option value="small">small</option>
                            <option value="medium">medium</option>
                            <option value="large">large</option>
                          </select>
                        ) : (
                          <input
                            type="text"
                            value={String(val)}
                            onChange={(e) => setStorybookArgs(prev => ({ ...prev, [key]: e.target.value }))}
                            className="w-full px-3 py-2 text-xs rounded-xl border border-[#cbd5e1] bg-[#f8fafc] text-[#0f172a] focus:bg-white focus:outline-none"
                          />
                        )}
                      </div>
                    ))}
                  </div>

                  {/* JSX Code Snippet */}
                  <div className="mt-5 pt-4 border-t border-[#e2e8f0]">
                    <div className="flex items-center gap-2 mb-2 text-xs font-bold text-[#64748b]">
                      <Code2 className="w-3.5 h-3.5 text-[#64748b]" />
                      <span>Generated React Usage</span>
                    </div>
                    <pre className="p-3.5 rounded-xl bg-[#0f172a] font-mono text-xs text-indigo-200 overflow-x-auto border border-[#cbd5e1]">
                      {`<${selectedStory.componentName} ${Object.entries(storybookArgs)
                        .map(([k, v]) => (typeof v === 'boolean' ? (v ? k : '') : `${k}=${typeof v === 'string' ? `"${v}"` : `{${JSON.stringify(v)}}`}`))
                        .filter(Boolean)
                        .join(' ')} />`}
                    </pre>
                  </div>
                </div>
              </>
            ) : (
              <div className="h-96 flex flex-col items-center justify-center border border-dashed border-[#cbd5e1] rounded-2xl text-[#94a3b8] text-xs">
                Select a story from the left to interact with its live preview
              </div>
            )}
          </div>
        </div>
      )}

      {/* Modal for Creating Components */}
      {showCreateModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-[#0f172a]/40 backdrop-blur-xs p-4">
          <div className="w-full max-w-md bg-white border border-[#e2e8f0] rounded-2xl p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-[#e2e8f0] pb-3">
              <h3 className="text-base font-bold text-[#0f172a]">Add New Component</h3>
              <button onClick={() => setShowCreateModal(false)} className="text-[#94a3b8] hover:text-[#0f172a] text-sm">✕</button>
            </div>
            <p className="text-xs text-[#64748b]">Create an entity in the component catalog for lifecycle tracking</p>

            <form onSubmit={handleCreateComponent} className="space-y-4 pt-1">
              <div>
                <label className="text-xs font-semibold text-[#475569] block mb-1">Component Name</label>
                <input
                  type="text"
                  placeholder="e.g. Button, DatePicker"
                  value={newCompName}
                  onChange={(e) => setNewCompName(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-[#cbd5e1] bg-[#f8fafc] text-[#0f172a] placeholder-[#94a3b8] focus:bg-white focus:outline-none focus:border-indigo-600"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-semibold text-[#475569] block mb-1">Category</label>
                  <select
                    value={newCompCategory}
                    onChange={(e) => setNewCompCategory(e.target.value)}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-[#cbd5e1] bg-[#f8fafc] text-[#0f172a] focus:bg-white focus:outline-none focus:border-indigo-600 font-medium"
                  >
                    <option value="inputs">Inputs</option>
                    <option value="layout">Layout</option>
                    <option value="feedback">Feedback</option>
                    <option value="overlay">Overlay</option>
                    <option value="navigation">Navigation</option>
                  </select>
                </div>
                <div>
                  <label className="text-xs font-semibold text-[#475569] block mb-1">Initial Status</label>
                  <select
                    value={newCompStatus}
                    onChange={(e: any) => setNewCompStatus(e.target.value)}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-[#cbd5e1] bg-[#f8fafc] text-[#0f172a] focus:bg-white focus:outline-none focus:border-indigo-600 font-medium"
                  >
                    <option value="backlog">Backlog</option>
                    <option value="in_progress">In Progress</option>
                    <option value="ready">Ready for Dev</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="text-xs font-semibold text-[#475569] block mb-1">Description</label>
                <textarea
                  placeholder="What is the component and usage guidelines?"
                  value={newCompDesc}
                  onChange={(e) => setNewCompDesc(e.target.value)}
                  rows={3}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-[#cbd5e1] bg-[#f8fafc] text-[#0f172a] placeholder-[#94a3b8] focus:bg-white focus:outline-none focus:border-indigo-600"
                />
              </div>

              <div className="flex justify-end gap-2.5 pt-2 border-t border-[#e2e8f0]">
                <button
                  type="button"
                  onClick={() => setShowCreateModal(false)}
                  className="btn-secondary text-xs py-2 px-3.5"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="btn-primary text-xs py-2 px-4 shadow-xs"
                >
                  Create Component
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
