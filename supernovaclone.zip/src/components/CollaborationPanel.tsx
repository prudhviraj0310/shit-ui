'use client';

import React, { useState, useEffect } from 'react';
import { Users, Radio, Lock, LogIn, LogOut, Activity, Plus, RefreshCw, CheckCircle2 } from 'lucide-react';

const API_KEY = 'nexus_api_key_for_testing_min24chars';

interface CollabUser {
  userId: string;
  name: string;
  color: string;
  status: string;
  cursor?: { x: number; y: number };
  lastActive: number;
}

interface Operation {
  id: string;
  userId: string;
  type: string;
  path: string;
  value: any;
  previousValue?: any;
  timestamp: number;
}

export function CollaborationPanel() {
  const [users, setUsers] = useState<CollabUser[]>([]);
  const [operations, setOperations] = useState<Operation[]>([]);
  const [roomVersion, setRoomVersion] = useState(0);
  const [locks, setLocks] = useState<any[]>([]);
  const [userName, setUserName] = useState('');
  const [joined, setJoined] = useState(false);
  const [myUserId, setMyUserId] = useState('');

  // Auto-polling for state
  useEffect(() => {
    const interval = setInterval(refreshState, 3000);
    refreshState();
    return () => clearInterval(interval);
  }, []);

  async function refreshState() {
    try {
      const res = await fetch('/api/collab?designSystemId=ds-nova-design', {
        headers: { 'x-api-key': API_KEY },
      });
      const data = await res.json();
      if (data.users) setUsers(data.users);
      if (data.version !== undefined) setRoomVersion(data.version);
      if (data.locks) setLocks(data.locks);
      if (data.operations) setOperations(data.operations.slice(-20));
    } catch (e) {
      console.error(e);
    }
  }

  async function joinRoom() {
    if (!userName.trim()) return;
    const uid = `user-${Date.now()}`;
    try {
      const res = await fetch('/api/collab', {
        method: 'POST',
        headers: { 'x-api-key': API_KEY, 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'join',
          designSystemId: 'ds-nova-design',
          userId: uid,
          name: userName,
          email: `${userName.toLowerCase().replace(/\s/g, '')}@nexus.dev`,
        }),
      });
      const data = await res.json();
      if (data.success) {
        setMyUserId(uid);
        setJoined(true);
        refreshState();
      }
    } catch (e) {
      console.error(e);
    }
  }

  async function leaveRoom() {
    try {
      await fetch('/api/collab', {
        method: 'POST',
        headers: { 'x-api-key': API_KEY, 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'leave', designSystemId: 'ds-nova-design', userId: myUserId }),
      });
      setJoined(false);
      setMyUserId('');
      refreshState();
    } catch (e) {
      console.error(e);
    }
  }

  async function sendOperation(type: string, path: string, value: string) {
    try {
      await fetch('/api/collab', {
        method: 'POST',
        headers: { 'x-api-key': API_KEY, 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'operation',
          designSystemId: 'ds-nova-design',
          userId: myUserId,
          operationType: type,
          path,
          value,
        }),
      });
      refreshState();
    } catch (e) {
      console.error(e);
    }
  }

  return (
    <div className="space-y-6">
      {/* Header Card */}
      <div className="nexus-card p-6 rounded-2xl border border-[#e2e8f0] bg-white flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-xs">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-emerald-50 border border-emerald-100 flex items-center justify-center text-emerald-600 shadow-2xs">
            <Radio className="w-6 h-6 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-xl font-bold tracking-tight text-[#0f172a]">Real-Time Multi-Player Studio</h2>
              <span className="text-[11px] font-mono px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 font-semibold border border-emerald-100 flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-ping" />
                Live OT Stream
              </span>
            </div>
            <p className="text-xs text-[#64748b] mt-0.5">
              Live operational transformation, conflict-free CRDT sync, and presence cursors
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 text-xs font-mono">
          <span className="px-3 py-1 rounded-xl bg-[#f8fafc] border border-[#e2e8f0] text-[#475569]">
            ds-nova-design · <strong className="text-indigo-600">v{roomVersion}</strong>
          </span>
          <span className="px-3 py-1 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-700 font-semibold">
            {users.length} Active
          </span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 min-h-[580px]">
        {/* Left: Room Status & Users */}
        <div className="lg:col-span-4 flex flex-col gap-4">
          {/* Join / Active Session Card */}
          <div className="nexus-card bg-white border border-[#e2e8f0] rounded-2xl p-5 shadow-xs">
            {!joined ? (
              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <LogIn className="w-4 h-4 text-indigo-600" />
                  <h3 className="text-sm font-bold text-[#0f172a]">Join Session</h3>
                </div>
                <p className="text-xs text-[#64748b]">
                  Enter your name to start live editing tokens and broadcasting state changes.
                </p>
                <div className="space-y-2">
                  <input
                    value={userName}
                    onChange={e => setUserName(e.target.value)}
                    placeholder="Your full name (e.g. Alex Designer)..."
                    onKeyDown={e => e.key === 'Enter' && joinRoom()}
                    className="w-full px-3.5 py-2 rounded-xl bg-white border border-[#cbd5e1] text-[#0f172a] placeholder-[#94a3b8] text-xs focus:outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-100 transition-all shadow-2xs"
                  />
                  <button
                    onClick={joinRoom}
                    disabled={!userName.trim()}
                    className="w-full py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white font-semibold text-xs transition-all cursor-pointer shadow-xs flex items-center justify-center gap-2"
                  >
                    <LogIn className="w-4 h-4" />
                    <span>Join Room</span>
                  </button>
                </div>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="flex items-center justify-between pb-3 border-b border-[#e2e8f0]">
                  <div className="flex items-center gap-2 text-xs font-bold text-emerald-700">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    <span>Connected to Room</span>
                  </div>
                  <button
                    onClick={leaveRoom}
                    className="px-2.5 py-1 rounded-lg border border-rose-200 bg-rose-50 hover:bg-rose-100 text-rose-700 text-xs font-semibold transition-all cursor-pointer flex items-center gap-1"
                  >
                    <LogOut className="w-3 h-3" />
                    <span>Disconnect</span>
                  </button>
                </div>

                <div className="text-xs text-[#64748b]">
                  User ID: <code className="font-mono text-[#0f172a] bg-[#f8fafc] px-1.5 py-0.5 rounded border border-[#e2e8f0]">{myUserId}</code>
                </div>

                <div className="space-y-2 pt-2 border-t border-[#e2e8f0]">
                  <div className="text-[10px] uppercase font-bold text-[#64748b] tracking-wider">
                    Quick Broadcast Actions
                  </div>
                  <button
                    onClick={() => sendOperation('update', 'tokens/color.brand.primary/rawValue', '#' + Math.floor(Math.random()*16777215).toString(16))}
                    className="w-full py-2 px-3 rounded-xl border border-[#cbd5e1] bg-[#f8fafc] hover:bg-white text-indigo-700 font-semibold text-xs text-left transition-all cursor-pointer shadow-2xs flex items-center justify-between"
                  >
                    <span>Update Primary Color</span>
                    <RefreshCw className="w-3.5 h-3.5 text-indigo-500" />
                  </button>
                  <button
                    onClick={() => sendOperation('create', 'tokens/color.accent.' + Date.now().toString().slice(-4), '#6366f1')}
                    className="w-full py-2 px-3 rounded-xl border border-[#cbd5e1] bg-[#f8fafc] hover:bg-white text-emerald-700 font-semibold text-xs text-left transition-all cursor-pointer shadow-2xs flex items-center justify-between"
                  >
                    <span>Create Accent Token</span>
                    <Plus className="w-3.5 h-3.5 text-emerald-500" />
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Connected Peers List */}
          <div className="nexus-card bg-white border border-[#e2e8f0] rounded-2xl p-5 flex-1 shadow-xs space-y-3">
            <div className="flex items-center justify-between pb-3 border-b border-[#e2e8f0]">
              <div className="flex items-center gap-2">
                <Users className="w-4 h-4 text-indigo-600" />
                <h3 className="text-sm font-bold text-[#0f172a]">Active Participants ({users.length})</h3>
              </div>
              <span className="text-[11px] text-[#64748b]">Real-Time Presence</span>
            </div>

            {users.length === 0 ? (
              <div className="p-8 text-center text-xs text-[#64748b]">
                No participants currently connected. Join above to start collaborating!
              </div>
            ) : (
              <div className="space-y-2 max-h-[360px] overflow-y-auto">
                {users.map(u => {
                  const isMe = u.userId === myUserId;
                  return (
                    <div
                      key={u.userId}
                      className={`p-3 rounded-xl border transition-all flex items-center justify-between ${
                        isMe
                          ? 'bg-indigo-50/70 border-indigo-200'
                          : 'bg-[#f8fafc] border-[#e2e8f0]'
                      }`}
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        <div
                          className="w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold text-white shadow-xs shrink-0"
                          style={{ backgroundColor: u.color || '#6366f1' }}
                        >
                          {u.name.charAt(0).toUpperCase()}
                        </div>
                        <div className="min-w-0">
                          <div className="text-xs font-bold text-[#0f172a] truncate flex items-center gap-1.5">
                            <span>{u.name}</span>
                            {isMe && (
                              <span className="text-[9px] font-mono px-1.5 py-0.2 rounded bg-indigo-600 text-white font-bold">
                                YOU
                              </span>
                            )}
                          </div>
                          <div className="text-[10px] text-[#64748b] truncate font-mono">
                            {u.userId}
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center gap-1.5 shrink-0">
                        <span className="w-2 h-2 rounded-full bg-emerald-500" />
                        <span className="text-[10px] font-medium text-emerald-700 capitalize">
                          {u.status}
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>

        {/* Right: Operational Transformation Log */}
        <div className="lg:col-span-8 flex flex-col">
          <div className="nexus-card bg-white border border-[#e2e8f0] rounded-2xl p-5 flex-1 flex flex-col shadow-xs">
            <div className="flex items-center justify-between pb-4 border-b border-[#e2e8f0]">
              <div className="flex items-center gap-2">
                <Activity className="w-4 h-4 text-emerald-600" />
                <h3 className="text-sm font-bold text-[#0f172a]">Live Operation Stream (OT Log)</h3>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-xs text-[#64748b]">Showing latest 20 ops</span>
                <button
                  onClick={refreshState}
                  className="p-1.5 rounded-lg border border-[#e2e8f0] bg-white hover:bg-[#f8fafc] text-[#64748b] transition-all cursor-pointer shadow-2xs"
                  title="Refresh stream"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            <div className="flex-1 overflow-y-auto mt-4 space-y-2.5 max-h-[520px] pr-1">
              {operations.length === 0 ? (
                <div className="p-16 text-center text-xs text-[#64748b] flex flex-col items-center justify-center">
                  <Activity className="w-8 h-8 text-[#94a3b8] mb-2 stroke-1" />
                  <div className="font-semibold text-[#0f172a]">Waiting for Operations</div>
                  <div className="mt-1 max-w-sm">
                    Token changes, edits, and deletions will appear in real-time as team members work.
                  </div>
                </div>
              ) : (
                operations.map(op => {
                  const isUpdate = op.type === 'update';
                  const isCreate = op.type === 'create';
                  const badgeColor = isCreate
                    ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                    : isUpdate
                    ? 'bg-indigo-50 text-indigo-700 border-indigo-200'
                    : 'bg-rose-50 text-rose-700 border-rose-200';

                  return (
                    <div
                      key={op.id}
                      className="p-3.5 rounded-xl border border-[#e2e8f0] bg-[#f8fafc] hover:bg-white transition-all shadow-2xs flex items-start justify-between gap-4"
                    >
                      <div className="space-y-1 min-w-0 flex-1">
                        <div className="flex items-center gap-2">
                          <span className={`text-[10px] font-bold font-mono uppercase px-2 py-0.5 rounded-md border ${badgeColor}`}>
                            {op.type}
                          </span>
                          <span className="font-mono text-xs font-semibold text-[#0f172a] truncate">
                            {op.path}
                          </span>
                        </div>

                        <div className="text-xs font-mono text-[#475569] pl-1 flex items-center gap-2">
                          {op.previousValue && (
                            <span className="text-[#94a3b8] line-through">
                              {String(op.previousValue)}
                            </span>
                          )}
                          {op.previousValue && <span className="text-[#64748b]">→</span>}
                          <span className="text-emerald-700 font-semibold bg-emerald-50 px-1.5 py-0.2 rounded border border-emerald-200">
                            {String(op.value)}
                          </span>
                        </div>
                      </div>

                      <div className="text-right shrink-0">
                        <div className="text-[11px] font-mono font-medium text-[#0f172a]">
                          {op.userId}
                        </div>
                        <div className="text-[10px] text-[#64748b] mt-0.5">
                          {new Date(op.timestamp).toLocaleTimeString()}
                        </div>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

