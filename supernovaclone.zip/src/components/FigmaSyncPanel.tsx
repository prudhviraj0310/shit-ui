'use client';

import React, { useState } from 'react';
import { UploadCloud, DownloadCloud, Eye, CheckCircle2, AlertCircle, RefreshCw, X } from 'lucide-react';

interface FigmaSyncPanelProps {
  designSystemId?: string;
  defaultFileKey?: string;
}

interface DiffItem {
  path: string;
  status: 'added' | 'modified' | 'unchanged' | 'conflict' | 'removed';
  oldValue?: string;
  newValue?: string;
  category: string;
}

const API_KEY = 'nexus_api_key_for_testing_min24chars';

export function FigmaSyncPanel({
  designSystemId = 'ds-nova-design',
  defaultFileKey = '',
}: FigmaSyncPanelProps) {
  const [fileKey, setFileKey] = useState(defaultFileKey);
  const [figmaToken, setFigmaToken] = useState('');
  const [collectionName, setCollectionName] = useState('Nexus Design OS');
  const [modeName, setModeName] = useState('Light');

  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState<{ type: 'success' | 'error' | 'info'; text: string } | null>(null);

  // Inbound Pull State
  const [pullDiff, setPullDiff] = useState<DiffItem[]>([]);
  const [pullStats, setPullStats] = useState<{ total: number; imported: number } | null>(null);

  // Outbound Push State
  const [pushPlan, setPushPlan] = useState<{
    pushedCount: number;
    createdCount: number;
    updatedCount: number;
    summary: any;
  } | null>(null);
  const [showPushConfirmModal, setShowPushConfirmModal] = useState(false);

  // 1. Pull from Figma
  async function handlePull(dryRun: boolean = true) {
    if (!fileKey.trim()) {
      setMessage({ type: 'error', text: 'Please provide a valid Figma File Key.' });
      return;
    }
    setLoading(true);
    setMessage(null);

    try {
      const res = await fetch('/api/figma/sync', {
        method: 'POST',
        headers: {
          'x-api-key': API_KEY,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          fileKey: fileKey.trim(),
          figmaToken: figmaToken.trim() || undefined,
          modeName,
          designSystemId,
          dryRun,
        }),
      });

      const data = await res.json();
      if (!res.ok || !data.success) {
        throw new Error(data.error || 'Failed to pull variables from Figma.');
      }

      setPullDiff(data.diff || []);
      setPullStats({
        total: data.totalVariablesFound || 0,
        imported: data.appliedCount || data.diff?.length || 0,
      });

      setMessage({
        type: 'success',
        text: dryRun
          ? `Dry run successful: ${data.totalVariablesFound || 0} variables inspected from Figma.`
          : `Live sync complete: ${data.appliedCount || 0} tokens imported into draft.`,
      });
    } catch (err: any) {
      setMessage({ type: 'error', text: err.message || 'An error occurred during Figma pull.' });
    } finally {
      setLoading(false);
    }
  }

  // 2. Prepare Outbound Push (Dry Run)
  async function handlePreparePush() {
    if (!fileKey.trim()) {
      setMessage({ type: 'error', text: 'Please provide a valid Figma File Key.' });
      return;
    }
    setLoading(true);
    setMessage(null);

    try {
      const res = await fetch('/api/figma/sync/push', {
        method: 'POST',
        headers: {
          'x-api-key': API_KEY,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          fileKey: fileKey.trim(),
          figmaToken: figmaToken.trim() || undefined,
          designSystemId,
          collectionName,
          dryRun: true,
        }),
      });

      const data = await res.json();
      if (!res.ok || !data.success) {
        throw new Error(data.error || 'Failed to prepare Figma push plan.');
      }

      setPushPlan({
        pushedCount: data.pushedCount || 0,
        createdCount: data.createdCount || 0,
        updatedCount: data.updatedCount || 0,
        summary: data.summary,
      });
      setShowPushConfirmModal(true);
    } catch (err: any) {
      setMessage({ type: 'error', text: err.message || 'Dry run push to Figma failed.' });
    } finally {
      setLoading(false);
    }
  }

  // 3. Execute Live Push
  async function handleExecuteLivePush() {
    setShowPushConfirmModal(false);
    setLoading(true);
    setMessage(null);

    try {
      const res = await fetch('/api/figma/sync/push', {
        method: 'POST',
        headers: {
          'x-api-key': API_KEY,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          fileKey: fileKey.trim(),
          figmaToken: figmaToken.trim() || undefined,
          designSystemId,
          collectionName,
          dryRun: false,
        }),
      });

      const data = await res.json();
      if (!res.ok || !data.success) {
        throw new Error(data.error || 'Failed to execute Figma push.');
      }

      setMessage({
        type: 'success',
        text: `Successfully pushed ${data.pushedCount} tokens to Figma file "${fileKey}" (${data.createdCount} created, ${data.updatedCount} updated).`,
      });
      setPushPlan(null);
    } catch (err: any) {
      setMessage({ type: 'error', text: err.message || 'Live push to Figma failed.' });
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="space-y-6">
      {/* Header Card */}
      <div className="nexus-card p-6 rounded-2xl border border-[#e2e8f0] bg-white flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-xs">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-purple-500/10 via-pink-500/10 to-orange-500/10 border border-purple-200 flex items-center justify-center text-xl shadow-2xs">
            ❖
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-xl font-bold tracking-tight text-[#0f172a]">
                Bi-Directional Figma Variable Synchronization
              </h2>
              <span className="text-[11px] font-mono px-2 py-0.5 rounded-full bg-cyan-50 text-cyan-700 font-semibold border border-cyan-200">
                REST API v1
              </span>
            </div>
            <p className="text-xs text-[#64748b] mt-0.5">
              Sync DTCG tokens to and from native Figma REST Variables (POST /v1/files/:file_key/variables)
            </p>
          </div>
        </div>
      </div>

      {/* Inputs Form */}
      <div className="nexus-card bg-white border border-[#e2e8f0] rounded-2xl p-6 shadow-xs space-y-5">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div>
            <label className="block text-xs font-bold text-[#475569] mb-1.5">
              Figma File Key *
            </label>
            <input
              type="text"
              placeholder="e.g. 4k3J9x8LMNP..."
              value={fileKey}
              onChange={(e) => setFileKey(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl bg-white border border-[#cbd5e1] text-xs text-[#0f172a] placeholder-[#94a3b8] focus:outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-100 transition-all shadow-2xs"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-[#475569] mb-1.5">
              Personal Access Token (or env)
            </label>
            <input
              type="password"
              placeholder="figd_..."
              value={figmaToken}
              onChange={(e) => setFigmaToken(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl bg-white border border-[#cbd5e1] text-xs text-[#0f172a] placeholder-[#94a3b8] focus:outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-100 transition-all shadow-2xs"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-[#475569] mb-1.5">
              Variable Collection Name
            </label>
            <input
              type="text"
              value={collectionName}
              onChange={(e) => setCollectionName(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl bg-white border border-[#cbd5e1] text-xs text-[#0f172a] placeholder-[#94a3b8] focus:outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-100 transition-all shadow-2xs"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-[#475569] mb-1.5">
              Mode / Theme Name
            </label>
            <input
              type="text"
              value={modeName}
              onChange={(e) => setModeName(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl bg-white border border-[#cbd5e1] text-xs text-[#0f172a] placeholder-[#94a3b8] focus:outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-100 transition-all shadow-2xs"
            />
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-3 flex-wrap pt-2 border-t border-[#e2e8f0]">
          <button
            onClick={handlePreparePush}
            disabled={loading}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 disabled:opacity-50 text-white font-semibold text-xs shadow-xs transition-all cursor-pointer"
          >
            <UploadCloud className="w-4 h-4" />
            <span>Push to Figma (Outbound)</span>
          </button>

          <button
            onClick={() => handlePull(true)}
            disabled={loading}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl border border-[#cbd5e1] bg-[#f8fafc] hover:bg-[#f1f5f9] text-[#0f172a] font-semibold text-xs shadow-2xs transition-all cursor-pointer"
          >
            <Eye className="w-4 h-4 text-[#64748b]" />
            <span>Preview Pull (Dry Run)</span>
          </button>

          <button
            onClick={() => handlePull(false)}
            disabled={loading}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white font-semibold text-xs shadow-xs transition-all cursor-pointer"
          >
            <DownloadCloud className="w-4 h-4" />
            <span>Pull from Figma</span>
          </button>
        </div>

        {/* Message Banner */}
        {message && (
          <div
            className={`p-3.5 rounded-xl border text-xs flex items-center gap-2 shadow-2xs ${
              message.type === 'success'
                ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
                : message.type === 'error'
                ? 'bg-rose-50 border-rose-200 text-rose-800'
                : 'bg-blue-50 border-blue-200 text-blue-800'
            }`}
          >
            {message.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            ) : (
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
            )}
            <span>{message.text}</span>
          </div>
        )}

        {/* Pull Diff Preview Table */}
        {pullDiff.length > 0 && (
          <div className="space-y-3 pt-3 border-t border-[#e2e8f0]">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-[#0f172a]">
                Token Diff Breakdown ({pullDiff.length} tokens)
              </span>
              {pullStats && (
                <span className="text-[11px] text-[#64748b] font-mono">
                  Total in Figma: <strong className="text-[#0f172a]">{pullStats.total}</strong> | Synced:{' '}
                  <strong className="text-emerald-700">{pullStats.imported}</strong>
                </span>
              )}
            </div>

            <div className="rounded-xl border border-[#e2e8f0] overflow-hidden max-h-64 overflow-y-auto">
              <table className="w-full text-xs text-left">
                <thead className="bg-[#f8fafc] border-b border-[#e2e8f0] text-[10px] uppercase font-bold text-[#64748b] tracking-wider">
                  <tr>
                    <th className="py-2.5 px-3">Status</th>
                    <th className="py-2.5 px-3">Token Path</th>
                    <th className="py-2.5 px-3">Category</th>
                    <th className="py-2.5 px-3">New Value</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#e2e8f0]">
                  {pullDiff.map((d, i) => (
                    <tr key={i} className="hover:bg-[#f8fafc] transition-colors">
                      <td className="py-2 px-3">
                        <span
                          className={`text-[10px] font-mono uppercase px-2 py-0.5 rounded-md font-bold border ${
                            d.status === 'added'
                              ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                              : d.status === 'modified'
                              ? 'bg-amber-50 text-amber-700 border-amber-200'
                              : 'bg-slate-100 text-slate-700 border-slate-200'
                          }`}
                        >
                          {d.status}
                        </span>
                      </td>
                      <td className="py-2 px-3 font-mono text-[#0f172a] font-semibold">{d.path}</td>
                      <td className="py-2 px-3 text-[#64748b] capitalize">{d.category}</td>
                      <td className="py-2 px-3 font-mono text-indigo-700 font-semibold">{d.newValue || '-'}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>

      {/* Confirmation Modal for Push */}
      {showPushConfirmModal && pushPlan && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-in fade-in duration-150">
          <div className="w-full max-w-lg rounded-2xl border border-[#e2e8f0] bg-white p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-[#e2e8f0]">
              <h3 className="text-base font-bold text-[#0f172a]">Confirm Push to Figma</h3>
              <button
                onClick={() => setShowPushConfirmModal(false)}
                className="p-1 rounded-lg text-[#64748b] hover:text-[#0f172a] hover:bg-[#f1f5f9] cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <p className="text-xs text-[#64748b] leading-relaxed">
              You are about to push your design system tokens directly into Figma file{' '}
              <code className="text-indigo-600 font-mono font-semibold bg-indigo-50 px-1 py-0.5 rounded border border-indigo-100">
                {fileKey}
              </code>
              . This action creates and updates native Figma Variable Collections.
            </p>

            <div className="p-4 rounded-xl border border-[#e2e8f0] bg-[#f8fafc]">
              <div className="grid grid-cols-2 gap-3 text-xs">
                <div>
                  <span className="text-[#64748b]">Total Tokens:</span>{' '}
                  <strong className="text-[#0f172a] font-bold">{pushPlan.pushedCount}</strong>
                </div>
                <div>
                  <span className="text-[#64748b]">Variables to Create:</span>{' '}
                  <strong className="text-emerald-700 font-bold">+{pushPlan.createdCount}</strong>
                </div>
                <div>
                  <span className="text-[#64748b]">Variables to Update:</span>{' '}
                  <strong className="text-indigo-700 font-bold">~{pushPlan.updatedCount}</strong>
                </div>
                <div>
                  <span className="text-[#64748b]">Target Collection:</span>{' '}
                  <strong className="text-[#0f172a] font-semibold">{collectionName}</strong>
                </div>
              </div>
            </div>

            <div className="flex justify-end gap-2.5 pt-2 border-t border-[#e2e8f0]">
              <button
                onClick={() => setShowPushConfirmModal(false)}
                className="px-4 py-2 rounded-xl border border-[#cbd5e1] text-xs font-semibold text-[#64748b] hover:text-[#0f172a] hover:bg-[#f1f5f9] transition-all cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={handleExecuteLivePush}
                disabled={loading}
                className="px-4 py-2 rounded-xl bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 disabled:opacity-50 text-white font-semibold text-xs shadow-xs transition-all cursor-pointer flex items-center gap-1.5"
              >
                {loading ? 'Pushing...' : 'Confirm & Push Variables'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
