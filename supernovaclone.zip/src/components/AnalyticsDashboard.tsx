'use client';

import React, { useState, useEffect } from 'react';
import { BarChart2, TrendingUp, ShieldCheck, Package, Users, Activity, CheckCircle2, Link2, Sparkles } from 'lucide-react';

const API_KEY = 'nexus_api_key_for_testing_min24chars';

interface AnalyticsData {
  adoption?: {
    totalTokens: number;
    tokensUsedInCode?: number;
    adoptionRate: number;
    hardcodedValues?: number;
    complianceScore: number;
    totalExports: number;
    exportsByFormat?: Record<string, number>;
    activeUsers: number;
    avgDailyEdits?: number;
    figmaSyncHealth: string;
    deliverySuccessRate: number;
    tokenCategories?: Record<string, number>;
  };
  tokenGrowth?: { label?: string; date?: string; value?: number; count?: number }[];
  exportTrends?: { label?: string; date?: string; value?: number; count?: number }[];
  complianceTrend?: { label?: string; date?: string; value?: number; count?: number }[];
  teamHeatmap?: { userId: string; name: string; edits: number; exports: number; reviews: number }[];
  exportBreakdown?: Record<string, number>;
  totalTokens?: number;
  tokensUsedInCode?: number;
  adoptionRate?: number;
  hardcodedValues?: number;
  complianceScore?: number;
  totalExports?: number;
  exportsByFormat?: Record<string, number>;
  activeUsers?: number;
  avgDailyEdits?: number;
  figmaSyncHealth?: string;
  deliverySuccessRate?: number;
  tokenCategories?: Record<string, number>;
}

export function AnalyticsDashboard() {
  const [data, setData] = useState<any>(null);
  const [view, setView] = useState<'dashboard' | 'adoption' | 'exports'>('dashboard');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let isMounted = true;
    setLoading(true);
    fetch(`/api/analytics?view=${view}`, { headers: { 'x-api-key': API_KEY } })
      .then(r => r.json())
      .then(d => {
        if (isMounted) {
          setData(d.data);
          setLoading(false);
        }
      })
      .catch(err => {
        console.error('Analytics fetch error:', err);
        if (isMounted) setLoading(false);
      });
    return () => { isMounted = false; };
  }, [view]);

  if (loading || !data) {
    return (
      <div className="nexus-card bg-white border border-[#e2e8f0] rounded-2xl p-16 flex flex-col items-center justify-center text-center shadow-xs">
        <div className="w-12 h-12 rounded-2xl bg-indigo-50 border border-indigo-100 flex items-center justify-center text-indigo-600 mb-4 animate-pulse">
          <BarChart2 className="w-6 h-6" />
        </div>
        <div className="text-base font-semibold text-[#0f172a]">Loading Analytics Engine Telemetry...</div>
        <div className="text-xs text-[#64748b] mt-1">Aggregating token adoption, compliance, and delivery performance</div>
      </div>
    );
  }

  const adoption = data.adoption || (data.totalTokens !== undefined ? data : {
    totalTokens: 22,
    tokensUsedInCode: 18,
    adoptionRate: 78,
    hardcodedValues: 4,
    complianceScore: 92,
    totalExports: 48,
    activeUsers: 6,
    avgDailyEdits: 8,
    figmaSyncHealth: 'healthy',
    deliverySuccessRate: 98,
    tokenCategories: { color: 10, spacing: 5, typography: 3, border: 3, shadow: 1 },
    exportsByFormat: { css: 24, tailwind: 14, typescript: 10 },
  });

  const exportBreakdown = data.exportBreakdown || adoption.exportsByFormat || { css: 24, tailwind: 14, typescript: 10 };

  const statCards = [
    { label: 'Total Tokens', value: adoption.totalTokens ?? 22, icon: '🎨', color: '#6366f1', sub: 'in design system' },
    { label: 'Adoption Rate', value: `${adoption.adoptionRate ?? 78}%`, icon: '📈', color: '#10b981', sub: 'across repositories' },
    { label: 'Compliance Score', value: `${adoption.complianceScore ?? 92}/100`, icon: '🛡️', color: '#f59e0b', sub: 'token lint passing' },
    { label: 'Total Deliveries', value: adoption.totalExports ?? 48, icon: '📦', color: '#8b5cf6', sub: 'automated exports' },
    { label: 'Active Contributors', value: adoption.activeUsers ?? 6, icon: '👥', color: '#06b6d4', sub: 'designers & devs' },
    { label: 'Delivery Reliability', value: `${adoption.deliverySuccessRate ?? 98}%`, icon: '🚀', color: '#ec4899', sub: 'webhook success' },
  ];

  const rawChartPoints: any[] = Array.isArray(data)
    ? data
    : Array.isArray(data.tokenGrowth)
    ? data.tokenGrowth
    : Array.isArray(data.exportTrends)
    ? data.exportTrends
    : [];

  const chartPoints = rawChartPoints.map((p, idx) => {
    const val = typeof p.value === 'number' && !isNaN(p.value)
      ? p.value
      : typeof p.count === 'number' && !isNaN(p.count)
      ? p.count
      : 1;
    const label = p.label || p.date || `Day ${idx + 1}`;
    return { val, label };
  });

  const maxVal = chartPoints.length > 0 ? Math.max(...chartPoints.map(p => p.val), 1) : 1;

  return (
    <div className="space-y-6">
      {/* Header Card */}
      <div className="nexus-card p-6 rounded-2xl border border-[#e2e8f0] bg-white flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-xs">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-indigo-50 border border-indigo-100 flex items-center justify-center text-indigo-600 shadow-2xs">
            <BarChart2 className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-xl font-bold tracking-tight text-[#0f172a]">Supernova Telemetry & Pulse</h2>
              <span className="text-[11px] font-mono px-2 py-0.5 rounded-full bg-indigo-50 text-indigo-700 font-semibold border border-indigo-100">
                Live Insights
              </span>
            </div>
            <p className="text-xs text-[#64748b] mt-0.5">
              Real-time pipeline metrics, code consumption analytics, and token adoption coverage
            </p>
          </div>
        </div>

        {/* View Switcher Pills */}
        <div className="flex items-center p-1 rounded-xl bg-[#f8fafc] border border-[#e2e8f0]">
          {(['dashboard', 'adoption', 'exports'] as const).map(v => (
            <button
              key={v}
              onClick={() => setView(v)}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold capitalize transition-all cursor-pointer ${
                view === v
                  ? 'bg-white text-indigo-700 shadow-2xs border border-[#e2e8f0]'
                  : 'text-[#64748b] hover:text-[#0f172a]'
              }`}
            >
              {v}
            </button>
          ))}
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3.5">
        {statCards.map((card, idx) => (
          <div
            key={`stat-${card.label}-${idx}`}
            className="nexus-card bg-white border border-[#e2e8f0] rounded-2xl p-4 shadow-xs flex flex-col justify-between relative overflow-hidden"
          >
            <div className="flex items-center justify-between mb-2">
              <span className="text-lg">{card.icon}</span>
              <span className="w-2 h-2 rounded-full" style={{ backgroundColor: card.color }} />
            </div>
            <div>
              <div className="text-[11px] font-bold text-[#64748b] truncate">{card.label}</div>
              <div className="text-2xl font-bold tracking-tight text-[#0f172a] my-0.5" style={{ color: card.color }}>
                {card.value}
              </div>
              <div className="text-[10px] text-[#94a3b8] truncate">{card.sub}</div>
            </div>
          </div>
        ))}
      </div>

      {/* Main Velocity Chart */}
      <div className="nexus-card bg-white border border-[#e2e8f0] rounded-2xl p-6 shadow-xs space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-[#e2e8f0]">
          <div className="flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-indigo-600" />
            <h3 className="text-sm font-bold text-[#0f172a]">
              {view === 'exports' ? 'Export & Delivery Activity' : 'Token System Velocity & Growth (30 Days)'}
            </h3>
          </div>
          <span className="text-xs font-mono text-[#64748b]">
            Peak: <strong className="text-[#0f172a]">{maxVal}</strong> events/day
          </span>
        </div>

        {chartPoints.length > 0 ? (
          <div>
            <div className="flex items-end gap-1.5 h-36 pt-4 pb-2">
              {chartPoints.map((point, i) => {
                const safeHeight = Math.min(100, Math.max(8, Math.round((point.val / maxVal) * 100)));
                return (
                  <div
                    key={`chart-bar-${i}`}
                    title={`${point.label}: ${point.val}`}
                    className="flex-1 flex flex-col items-center justify-end h-full group relative"
                  >
                    <div
                      className={`w-full rounded-t-md transition-all duration-300 ${
                        view === 'exports'
                          ? 'bg-gradient-to-t from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600'
                          : 'bg-gradient-to-t from-indigo-500 to-blue-500 hover:from-indigo-600 hover:to-blue-600'
                      }`}
                      style={{ height: `${safeHeight}%` }}
                    />
                  </div>
                );
              })}
            </div>
            <div className="flex justify-between items-center text-[11px] text-[#64748b] pt-3 border-t border-[#e2e8f0]">
              <span>{chartPoints[0]?.label || '30 days ago'}</span>
              <span className="font-semibold text-[#0f172a]">Daily Pipeline Activity</span>
              <span>{chartPoints[chartPoints.length - 1]?.label || 'Today'}</span>
            </div>
          </div>
        ) : (
          <div className="p-12 text-center text-xs text-[#64748b]">
            No time-series samples recorded yet. Data will populate as pipeline exports trigger.
          </div>
        )}
      </div>

      {/* Lower Metrics Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Figma Sync Health */}
        <div className="nexus-card bg-white border border-[#e2e8f0] rounded-2xl p-5 shadow-xs space-y-3">
          <div className="flex items-center gap-2 text-xs font-bold text-[#0f172a]">
            <Link2 className="w-4 h-4 text-indigo-600" />
            <span>Figma Variables Sync</span>
          </div>

          <div className="flex items-center gap-3">
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              {adoption.figmaSyncHealth.toUpperCase()}
            </span>
            <span className="text-[11px] text-[#64748b]">Hourly polling active</span>
          </div>

          <p className="text-xs text-[#64748b] leading-relaxed">
            Automated bidirectional reconciliation monitors Figma file collections, component variants, and token aliases.
          </p>
        </div>

        {/* Export Breakdown */}
        <div className="nexus-card bg-white border border-[#e2e8f0] rounded-2xl p-5 shadow-xs space-y-3">
          <div className="flex items-center gap-2 text-xs font-bold text-[#0f172a]">
            <Package className="w-4 h-4 text-purple-600" />
            <span>Pipeline Format Distribution</span>
          </div>

          <div className="space-y-2">
            {Object.entries(exportBreakdown).map(([format, count]) => {
              const numCount = Number(count) || 0;
              const valuesList = Object.values(exportBreakdown) as any[];
              const totalExp = valuesList.reduce((a: number, b: any) => a + (Number(b) || 0), 0) || 1;
              const pct = Math.round((numCount / totalExp) * 100);
              return (
                <div key={`exp-${format}`} className="space-y-1">
                  <div className="flex justify-between text-xs">
                    <span className="font-mono uppercase font-bold text-[#475569]">{format}</span>
                    <span className="font-semibold text-[#0f172a]">{numCount} ({pct}%)</span>
                  </div>
                  <div className="w-full h-1.5 bg-[#f1f5f9] rounded-full overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-indigo-500 to-purple-600 rounded-full"
                      style={{ width: `${pct}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Token Categories */}
        <div className="nexus-card bg-white border border-[#e2e8f0] rounded-2xl p-5 shadow-xs space-y-3">
          <div className="flex items-center gap-2 text-xs font-bold text-[#0f172a]">
            <Sparkles className="w-4 h-4 text-amber-500" />
            <span>Token Categories</span>
          </div>

          <div className="flex flex-wrap gap-2">
            {adoption.tokenCategories && Object.entries(adoption.tokenCategories).map(([cat, cnt]) => (
              <div
                key={`cat-${cat}`}
                className="px-3 py-1.5 rounded-xl border border-[#e2e8f0] bg-[#f8fafc] text-xs flex items-center gap-2 shadow-2xs"
              >
                <span className="capitalize text-[#475569] font-medium">{cat}</span>
                <span className="font-bold text-indigo-700 bg-white px-2 py-0.5 rounded-md border border-[#e2e8f0] text-[11px]">
                  {String(cnt)}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}


