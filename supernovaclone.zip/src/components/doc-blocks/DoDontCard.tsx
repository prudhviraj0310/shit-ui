'use client';

import React from 'react';
import { CheckCircle2, XCircle } from 'lucide-react';
import { DoDontDocBlock, DoDontItem } from '@/core/docs/types';

interface DoDontCardProps {
  block: DoDontDocBlock;
}

function SubCard({
  item,
  type,
}: {
  item: DoDontItem;
  type: 'do' | 'dont';
}) {
  const isDo = type === 'do';
  const borderColor = isDo ? '#86efac' : '#fca5a5';
  const badgeBg = isDo ? '#dcfce7' : '#fee2e2';
  const badgeBorder = isDo ? '#bbf7d0' : '#fecdd3';
  const badgeColor = isDo ? '#15803d' : '#b91c1c';
  const Icon = isDo ? CheckCircle2 : XCircle;

  return (
    <div
      style={{
        flex: 1,
        borderRadius: 14,
        border: `1.5px solid ${borderColor}`,
        background: '#ffffff',
        overflow: 'hidden',
        display: 'flex',
        flexDirection: 'column',
        boxShadow: '0 1px 3px rgba(0, 0, 0, 0.04)',
      }}
    >
      {/* Visual Content Box (Media, Swatch, Code, etc.) */}
      <div
        style={{
          minHeight: 140,
          background: isDo ? '#f0fdf4' : '#fff1f2',
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          padding: 16,
          borderBottom: `1px solid ${isDo ? '#dcfce7' : '#fee2e2'}`,
          position: 'relative',
        }}
      >
        {item.mediaUrl && (
          <img
            src={item.mediaUrl}
            alt={item.title || type}
            style={{ maxWidth: '100%', maxHeight: 180, borderRadius: 8, objectFit: 'contain' }}
          />
        )}

        {item.tokenValue && (
          <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8 }}>
            <div
              style={{
                width: 64,
                height: 64,
                borderRadius: 12,
                background: item.tokenValue,
                boxShadow: '0 4px 12px rgba(0,0,0,0.08)',
                border: '1px solid rgba(0,0,0,0.1)',
              }}
            />
            {item.tokenPath && (
              <code style={{ fontSize: 11, color: '#475569', fontFamily: 'monospace', fontWeight: 600 }}>
                {item.tokenPath}
              </code>
            )}
          </div>
        )}

        {item.code && (
          <pre
            style={{
              margin: 0,
              padding: '10px 14px',
              borderRadius: 8,
              background: '#090d16',
              border: '1px solid #1e293b',
              color: isDo ? '#4ade80' : '#f87171',
              fontSize: 12,
              fontFamily: 'monospace',
              width: '100%',
              overflowX: 'auto',
              boxSizing: 'border-box',
            }}
          >
            <code>{item.code}</code>
          </pre>
        )}
      </div>

      {/* Rationale & Header */}
      <div style={{ padding: 16, display: 'flex', flexDirection: 'column', gap: 8, flex: 1 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <span
            style={{
              display: 'inline-flex',
              alignItems: 'center',
              gap: 5,
              padding: '2px 8px',
              borderRadius: 16,
              background: badgeBg,
              border: `1px solid ${badgeBorder}`,
              color: badgeColor,
              fontSize: 11,
              fontWeight: 700,
              letterSpacing: '0.04em',
              textTransform: 'uppercase',
            }}
          >
            <Icon size={13} />
            {isDo ? 'DO' : "DON'T"}
          </span>
          {item.title && (
            <span style={{ fontSize: 13, fontWeight: 700, color: '#0f172a' }}>{item.title}</span>
          )}
        </div>

        <p style={{ margin: 0, fontSize: 13, color: '#475569', lineHeight: 1.55 }}>
          {item.text}
        </p>

        {item.caption && (
          <span style={{ fontSize: 11, color: '#64748b', fontStyle: 'italic', marginTop: 4 }}>
            {item.caption}
          </span>
        )}
      </div>
    </div>
  );
}

export function DoDontCard({ block }: DoDontCardProps) {
  return (
    <div style={{ margin: '24px 0', fontFamily: 'Inter, system-ui, sans-serif' }}>
      {block.title && (
        <h4 style={{ margin: '0 0 12px 0', fontSize: 16, fontWeight: 700, color: '#0f172a' }}>
          {block.title}
        </h4>
      )}
      <div
        style={{
          display: 'flex',
          gap: 20,
          flexDirection: 'row',
          flexWrap: 'wrap',
        }}
      >
        <SubCard item={block.doItem} type="do" />
        <SubCard item={block.dontItem} type="dont" />
      </div>
    </div>
  );
}
