'use client';

import React, { useState } from 'react';
import { DocBlock, DocRenderContext } from '@/core/docs/types';
import { DoDontCard } from './DoDontCard';
import { InteractivePlayground } from './InteractivePlayground';
import { LiveTokenTable } from './LiveTokenTable';
import { DocCallout } from './DocCallout';
import { AssetGrid } from './AssetGrid';
import { ContextMcpCard } from './ContextMcpCard';
import { ComponentHealthCard } from './ComponentHealthCard';
import { PromptTemplateCard } from './PromptTemplateCard';
import { PropsTableCard } from './PropsTableCard';
import { Copy, Check, GitCommit, ExternalLink } from 'lucide-react';

interface BlockCanvasRendererProps {
  blocks: DocBlock[];
  context?: DocRenderContext;
  theme?: 'dark' | 'light';
}

export function BlockCanvasRenderer({ blocks, context, theme = 'light' }: BlockCanvasRendererProps) {
  const isLight = theme === 'light';
  const [activeTabs, setActiveTabs] = useState<Record<string, number>>({});
  const [copiedCodeId, setCopiedCodeId] = useState<string | null>(null);

  const copyCode = (code: string, id: string) => {
    navigator.clipboard.writeText(code);
    setCopiedCodeId(id);
    setTimeout(() => setCopiedCodeId(null), 1500);
  };

  return (
    <div
      className={`nexus-doc-canvas ${theme === 'light' ? 'theme-light' : 'theme-dark'}`}
      style={{
        display: 'flex',
        flexDirection: 'column',
        gap: 16,
        color: theme === 'light' ? '#0f172a' : '#f8fafc',
        fontFamily: 'Inter, system-ui, sans-serif',
      }}
    >
      {blocks.map((block) => {
        switch (block.type) {
          case 'heading': {
            const Tag = `h${block.level}` as 'h1' | 'h2' | 'h3' | 'h4' | 'h5' | 'h6';
            const slug = block.text

              .toLowerCase()
              .replace(/[^a-z0-9]+/g, '-')
              .replace(/(^-|-$)/g, '');

            const sizes: Record<number, string> = {
              1: '32px',
              2: '24px',
              3: '20px',
              4: '16px',
              5: '14px',
              6: '13px',
            };

            return (
              <Tag
                key={block.id}
                id={slug}
                style={{
                  fontSize: sizes[block.level] || '20px',
                  fontWeight: block.level === 1 ? 800 : block.level === 2 ? 700 : 600,
                  marginTop: block.level === 1 ? 8 : 24,
                  marginBottom: 8,
                  letterSpacing: block.level === 1 ? '-0.03em' : '-0.02em',
                  color: theme === 'light' ? '#0f172a' : '#f8fafc',
                  scrollMarginTop: 80,
                }}
              >
                {block.text}
              </Tag>
            );
          }

          case 'paragraph': {
            return (
              <p
                key={block.id}
                style={{
                  margin: 0,
                  fontSize: 15,
                  lineHeight: 1.65,
                  color: theme === 'light' ? '#334155' : '#94a3b8',
                }}
              >
                {block.text}
              </p>
            );
          }

          case 'code': {
            const isCopied = copiedCodeId === block.id;
            return (
              <div
                key={block.id}
                style={{
                  margin: '12px 0',
                  borderRadius: 10,
                  overflow: 'hidden',
                  border: isLight ? '1px solid #e2e8f0' : '1px solid rgba(255, 255, 255, 0.08)',
                  background: '#090d16',
                  boxShadow: isLight ? '0 1px 3px rgba(0,0,0,0.05)' : 'none',
                }}
              >
                <div
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    padding: '8px 14px',
                    background: '#0f172a',
                    borderBottom: '1px solid #1e293b',
                  }}
                >
                  <span style={{ fontSize: 11, fontWeight: 600, color: '#94a3b8', textTransform: 'uppercase' }}>
                    {block.title || block.language}
                  </span>
                  <button
                    onClick={() => copyCode(block.code, block.id)}
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: 4,
                      padding: '3px 8px',
                      borderRadius: 4,
                      border: 'none',
                      background: 'rgba(255,255,255,0.08)',
                      color: isCopied ? '#34d399' : '#cbd5e1',
                      fontSize: 11,
                      cursor: 'pointer',
                    }}
                  >
                    {isCopied ? <Check size={12} /> : <Copy size={12} />}
                    {isCopied ? 'Copied' : 'Copy'}
                  </button>
                </div>
                <pre
                  style={{
                    margin: 0,
                    padding: 16,
                    fontSize: 13,
                    fontFamily: 'monospace',
                    color: '#f8fafc',
                    overflowX: 'auto',
                  }}
                >
                  <code>{block.code}</code>
                </pre>
              </div>
            );
          }

          case 'callout': {
            return <DocCallout key={block.id} block={block} />;
          }

          case 'do_dont': {
            return <DoDontCard key={block.id} block={block} />;
          }

          case 'interactive_playground': {
            return <InteractivePlayground key={block.id} block={block} />;
          }

          case 'token_table': {
            const mapped = (context?.tokens || []).map((t) => ({
              path: t.path,
              category: t.type,
              type: t.type,
              rawValue: t.resolvedValue,
              resolvedValue: t.resolvedValue,
            }));
            return <LiveTokenTable key={block.id} block={block} tokens={mapped.length > 0 ? mapped : undefined} />;
          }

          case 'asset_grid': {
            const mappedAssets = (context?.assets || []).map((a) => ({
              id: a.id,
              name: a.name,
              category: 'icons' as const,
              svg: a.svgContent,
            }));
            return <AssetGrid key={block.id} block={block} assets={mappedAssets.length > 0 ? mappedAssets : undefined} />;
          }

          case 'divider': {
            return (
              <hr
                key={block.id}
                style={{
                  margin: '16px 0',
                  border: 'none',
                  borderTop: isLight ? '1px solid #e2e8f0' : '1px solid rgba(255, 255, 255, 0.08)',
                }}
              />
            );
          }

          case 'table': {
            return (
              <div
                key={block.id}
                style={{
                  margin: '16px 0',
                  borderRadius: 10,
                  overflowX: 'auto',
                  border: isLight ? '1px solid #e2e8f0' : '1px solid rgba(255, 255, 255, 0.08)',
                  background: isLight ? '#ffffff' : 'rgba(15, 23, 42, 0.4)',
                  boxShadow: isLight ? '0 1px 3px rgba(0,0,0,0.04)' : 'none',
                }}
              >
                <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13, textAlign: 'left' }}>
                  <thead>
                    <tr
                      style={{
                        background: isLight ? '#f8fafc' : 'rgba(255, 255, 255, 0.04)',
                        borderBottom: isLight ? '1px solid #e2e8f0' : '1px solid rgba(255, 255, 255, 0.08)',
                      }}
                    >
                      {block.headers.map((h, i) => (
                        <th key={i} style={{ padding: '10px 14px', fontWeight: 600, color: isLight ? '#475569' : '#94a3b8' }}>
                          {h}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {block.rows.map((row, ri) => (
                      <tr
                        key={ri}
                        style={{
                          borderBottom: isLight ? '1px solid #f1f5f9' : '1px solid rgba(255, 255, 255, 0.04)',
                          background: isLight && ri % 2 === 1 ? '#fafafa' : 'transparent',
                        }}
                      >
                        {row.map((cell, ci) => (
                          <td key={ci} style={{ padding: '10px 14px', color: isLight ? '#0f172a' : '#cbd5e1' }}>
                            {cell}
                          </td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            );
          }

          case 'tabs': {
            const currentTabIdx = activeTabs[block.id] || 0;
            return (
              <div
                key={block.id}
                style={{
                  margin: '16px 0',
                  borderRadius: 12,
                  border: isLight ? '1px solid #e2e8f0' : '1px solid rgba(255, 255, 255, 0.08)',
                  background: isLight ? '#ffffff' : 'rgba(15, 23, 42, 0.5)',
                  boxShadow: isLight ? '0 1px 3px rgba(0,0,0,0.05)' : 'none',
                  overflow: 'hidden',
                }}
              >
                <div
                  style={{
                    display: 'flex',
                    background: isLight ? '#f8fafc' : 'rgba(2, 6, 23, 0.6)',
                    borderBottom: isLight ? '1px solid #e2e8f0' : '1px solid rgba(255, 255, 255, 0.06)',
                  }}
                >
                  {block.tabs.map((tab, idx) => (
                    <button
                      key={idx}
                      onClick={() => setActiveTabs((prev) => ({ ...prev, [block.id]: idx }))}
                      style={{
                        padding: '10px 18px',
                        border: 'none',
                        borderBottom:
                          currentTabIdx === idx
                            ? `2px solid ${isLight ? '#2563eb' : '#06b6d4'}`
                            : '2px solid transparent',
                        background:
                          currentTabIdx === idx
                            ? isLight
                              ? '#ffffff'
                              : 'rgba(255, 255, 255, 0.05)'
                            : 'transparent',
                        color:
                          currentTabIdx === idx
                            ? isLight
                              ? '#2563eb'
                              : '#38bdf8'
                            : isLight
                            ? '#64748b'
                            : '#94a3b8',
                        fontWeight: 600,
                        fontSize: 13,
                        cursor: 'pointer',
                      }}
                    >
                      {tab.title}
                    </button>
                  ))}
                </div>
                <div style={{ padding: 18 }}>
                  <BlockCanvasRenderer
                    blocks={block.tabs[currentTabIdx]?.blocks || []}
                    context={context}
                    theme={theme}
                  />
                </div>
              </div>
            );
          }

          case 'context_mcp': {
            return <ContextMcpCard key={block.id} block={block} />;
          }

          case 'component_health_matrix': {
            return <ComponentHealthCard key={block.id} block={block} />;
          }

          case 'prompt_template': {
            return <PromptTemplateCard key={block.id} block={block} />;
          }

          case 'props_table': {
            return <PropsTableCard key={block.id} block={block} />;
          }

          case 'storybook_embed': {
            return (
              <div
                key={block.id}
                style={{
                  borderRadius: 12,
                  overflow: 'hidden',
                  border: isLight ? '1px solid #e2e8f0' : '1px solid rgba(255, 255, 255, 0.08)',
                  background: isLight ? '#ffffff' : '#090d16',
                  boxShadow: isLight ? '0 1px 3px rgba(0,0,0,0.05)' : 'none',
                }}
              >
                <div
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    padding: '8px 14px',
                    background: isLight ? '#f8fafc' : 'rgba(255, 255, 255, 0.04)',
                    borderBottom: isLight ? '1px solid #e2e8f0' : '1px solid rgba(255, 255, 255, 0.06)',
                  }}
                >
                  <span style={{ fontSize: 12, fontWeight: 600, color: '#f43f5e', display: 'flex', alignItems: 'center', gap: 6 }}>
                    📕 Storybook CSF3: {block.title || block.storyId || 'Preview'}
                  </span>
                  <a
                    href={block.url}
                    target="_blank"
                    rel="noreferrer"
                    style={{ fontSize: 11, color: isLight ? '#475569' : '#94a3b8', display: 'flex', alignItems: 'center', gap: 4, textDecoration: 'none' }}
                  >
                    Open Storybook <ExternalLink size={11} />
                  </a>
                </div>
                <iframe
                  src={block.url}
                  title={block.title || 'Storybook Preview'}
                  style={{ width: '100%', height: block.height || 360, border: 'none', background: isLight ? '#f8fafc' : '#0f172a' }}
                />
              </div>
            );
          }

          case 'version_diff': {
            return (
              <div
                key={block.id}
                style={{
                  borderRadius: 12,
                  border: isLight ? '1px solid #e2e8f0' : '1px solid rgba(255, 255, 255, 0.08)',
                  background: isLight ? '#ffffff' : 'rgba(15, 23, 42, 0.6)',
                  boxShadow: isLight ? '0 1px 3px rgba(0,0,0,0.05)' : 'none',
                  padding: 16,
                }}
              >
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                    <GitCommit size={15} color={isLight ? '#2563eb' : '#38bdf8'} />
                    <span style={{ fontSize: 14, fontWeight: 700, color: isLight ? '#0f172a' : '#f8fafc' }}>
                      {block.title || 'Token Version Diff'}
                    </span>
                  </div>
                  <span style={{ fontSize: 12, color: isLight ? '#64748b' : '#94a3b8', fontFamily: 'monospace' }}>
                    {block.fromVersion || 'v1.0.0'} &rarr; {block.toVersion || 'v2.0.0'}
                  </span>
                </div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                  {(block.changes || []).map((ch, idx) => {
                    const badgeColor =
                      ch.changeType === 'added' ? '#16a34a' : ch.changeType === 'removed' ? '#dc2626' : '#d97706';
                    return (
                      <div
                        key={idx}
                        style={{
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'space-between',
                          padding: '6px 10px',
                          borderRadius: 6,
                          background: isLight ? '#f8fafc' : 'rgba(255, 255, 255, 0.02)',
                          border: isLight ? '1px solid #e2e8f0' : 'none',
                          fontSize: 12,
                        }}
                      >
                        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                          <span
                            style={{
                              fontSize: 10,
                              fontWeight: 700,
                              textTransform: 'uppercase',
                              color: badgeColor,
                              border: `1px solid ${badgeColor}40`,
                              padding: '1px 5px',
                              borderRadius: 4,
                            }}
                          >
                            {ch.changeType}
                          </span>
                          <code style={{ color: isLight ? '#0f172a' : '#e2e8f0' }}>{ch.path}</code>
                        </div>
                        <div style={{ display: 'flex', alignItems: 'center', gap: 8, fontFamily: 'monospace', fontSize: 11 }}>
                          {ch.oldValue && <span style={{ color: '#94a3b8', textDecoration: 'line-through' }}>{ch.oldValue}</span>}
                          {ch.newValue && <span style={{ color: isLight ? '#0284c7' : '#38bdf8' }}>{ch.newValue}</span>}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          }

          case 'token_chip': {
            const token = context?.tokens?.find((t) => t.path === block.tokenPath);
            const val = token?.resolvedValue;
            const isColor = val && (val.startsWith('#') || val.startsWith('rgb') || val.startsWith('hsl'));
            return (
              <span
                key={block.id}
                style={{
                  display: 'inline-flex',
                  alignItems: 'center',
                  gap: 6,
                  padding: '3px 8px',
                  borderRadius: 6,
                  background: isLight ? '#f8fafc' : 'rgba(255, 255, 255, 0.06)',
                  border: isLight ? '1px solid #cbd5e1' : '1px solid rgba(255, 255, 255, 0.08)',
                  fontSize: 12,
                  fontFamily: 'monospace',
                }}
              >
                {isColor && (
                  <span
                    style={{
                      width: 12,
                      height: 12,
                      borderRadius: 3,
                      background: val,
                      border: isLight ? '1px solid #cbd5e1' : '1px solid rgba(255,255,255,0.2)',
                    }}
                  />
                )}
                <code style={{ color: isLight ? '#2563eb' : '#38bdf8' }}>{block.label || block.tokenPath}</code>
                {val && <span style={{ color: isLight ? '#475569' : '#94a3b8' }}>{val}</span>}
              </span>
            );
          }

          case 'token_list': {
            const listTokens = (context?.tokens || []).filter(
              (t) => !block.category || t.type === block.category
            );
            return (
              <div
                key={block.id}
                style={{
                  borderRadius: 10,
                  border: isLight ? '1px solid #e2e8f0' : '1px solid rgba(255, 255, 255, 0.08)',
                  background: isLight ? '#ffffff' : 'rgba(15, 23, 42, 0.4)',
                  boxShadow: isLight ? '0 1px 3px rgba(0,0,0,0.05)' : 'none',
                  padding: 12,
                  display: 'flex',
                  flexDirection: 'column',
                  gap: 6,
                }}
              >
                {listTokens.map((t, idx) => (
                  <div
                    key={idx}
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'space-between',
                      padding: '4px 8px',
                      borderRadius: 4,
                      background: isLight ? '#f8fafc' : 'rgba(255, 255, 255, 0.02)',
                      border: isLight ? '1px solid #e2e8f0' : 'none',
                      fontSize: 12,
                    }}
                  >
                    <code style={{ color: isLight ? '#2563eb' : '#38bdf8' }}>{t.path}</code>
                    <code style={{ color: isLight ? '#0f172a' : '#e2e8f0' }}>{t.resolvedValue}</code>
                  </div>
                ))}
              </div>
            );
          }

          case 'figma_embed': {
            return (
              <div
                key={block.id}
                style={{
                  borderRadius: 12,
                  overflow: 'hidden',
                  border: isLight ? '1px solid #e2e8f0' : '1px solid rgba(255, 255, 255, 0.08)',
                  background: isLight ? '#ffffff' : '#090d16',
                  boxShadow: isLight ? '0 1px 3px rgba(0,0,0,0.05)' : 'none',
                }}
              >
                <div
                  style={{
                    padding: '8px 14px',
                    background: isLight ? '#f8fafc' : 'rgba(255, 255, 255, 0.04)',
                    borderBottom: isLight ? '1px solid #e2e8f0' : '1px solid rgba(255, 255, 255, 0.06)',
                    fontSize: 12,
                    fontWeight: 600,
                    color: isLight ? '#0f172a' : '#94a3b8',
                  }}
                >
                  🎨 Figma Embed: {block.title || block.url}
                </div>
                <iframe
                  src={block.url}
                  title={block.title || 'Figma Embed'}
                  style={{ width: '100%', height: block.height || 400, border: 'none' }}
                  allowFullScreen
                />
              </div>
            );
          }

          case 'component_preview': {
            const comp = context?.components?.find((c) => c.id === block.componentId);
            return (
              <div
                key={block.id}
                style={{
                  borderRadius: 12,
                  border: isLight ? '1px solid #e2e8f0' : '1px solid rgba(255, 255, 255, 0.08)',
                  background: isLight ? '#ffffff' : 'rgba(15, 23, 42, 0.5)',
                  boxShadow: isLight ? '0 1px 3px rgba(0,0,0,0.05)' : 'none',
                  padding: 16,
                }}
              >
                <div style={{ fontSize: 13, fontWeight: 600, color: isLight ? '#0f172a' : '#38bdf8', marginBottom: 8 }}>
                  Component Preview: {comp?.name || block.componentId} ({block.framework || 'react'})
                </div>
                <div
                  style={{
                    padding: 24,
                    borderRadius: 8,
                    background: isLight ? '#f8fafc' : 'rgba(255, 255, 255, 0.02)',
                    border: isLight ? '1px solid #e2e8f0' : 'none',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}
                >
                  <button
                    style={{
                      padding: '8px 16px',
                      borderRadius: 6,
                      background: '#2563eb',
                      color: 'white',
                      border: 'none',
                      fontWeight: 600,
                      cursor: 'pointer',
                    }}
                  >
                    {comp?.name || block.componentId}
                  </button>
                </div>
              </div>
            );
          }

          default:
            return null;
        }
      })}
    </div>
  );
}
