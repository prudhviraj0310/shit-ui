'use client';

import React from 'react';
import { ShieldCheck, GitBranch, Layers, BookOpen, CheckCircle2 } from 'lucide-react';
import { ComponentHealthMatrixDocBlock } from '@/core/docs/types';

interface ComponentHealthCardProps {
  block: ComponentHealthMatrixDocBlock;
}

export function ComponentHealthCard({ block }: ComponentHealthCardProps) {
  const componentsList = [
    {
      id: 'cmp-button',
      name: 'Button',
      category: 'Inputs',
      figmaVariants: 16,
      codeProps: 16,
      storybookLinked: true,
      auditPassed: true,
      lastSynced: '10 mins ago',
      status: 'healthy' as const,
    },
    {
      id: 'cmp-badge',
      name: 'Badge',
      category: 'Data Display',
      figmaVariants: 8,
      codeProps: 8,
      storybookLinked: true,
      auditPassed: true,
      lastSynced: '1 hour ago',
      status: 'healthy' as const,
    },
    {
      id: 'cmp-modal',
      name: 'Modal Dialog',
      category: 'Feedback',
      figmaVariants: 6,
      codeProps: 6,
      storybookLinked: true,
      auditPassed: true,
      lastSynced: 'Yesterday',
      status: 'healthy' as const,
    },
    {
      id: 'cmp-tabs',
      name: 'Tabs',
      category: 'Navigation',
      figmaVariants: 4,
      codeProps: 4,
      storybookLinked: true,
      auditPassed: true,
      lastSynced: '2 days ago',
      status: 'healthy' as const,
    },
  ];

  return (
    <div
      style={{
        margin: '20px 0',
        borderRadius: 14,
        background: '#ffffff',
        border: '1px solid #e2e8f0',
        boxShadow: '0 1px 3px rgba(0, 0, 0, 0.04)',
        overflow: 'hidden',
        fontFamily: 'Inter, system-ui, sans-serif',
      }}
    >
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          padding: '14px 18px',
          background: '#f8fafc',
          borderBottom: '1px solid #e2e8f0',
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <ShieldCheck size={18} style={{ color: '#059669' }} />
          <span style={{ fontSize: 14, fontWeight: 700, color: '#0f172a' }}>
            {block.title || 'Component Health & Parity Matrix (Figma vs Code)'}
          </span>
        </div>
        <span
          style={{
            fontSize: 11,
            color: '#059669',
            background: '#ecfdf5',
            border: '1px solid #a7f3d0',
            padding: '2px 8px',
            borderRadius: 6,
            fontWeight: 600,
          }}
        >
          100% System Parity
        </span>
      </div>

      <div style={{ overflowX: 'auto' }}>
        <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13, textAlign: 'left' }}>
          <thead>
            <tr style={{ background: '#f8fafc', borderBottom: '1px solid #e2e8f0' }}>
              <th style={{ padding: '10px 16px', color: '#475569', fontWeight: 600 }}>Component</th>
              <th style={{ padding: '10px 16px', color: '#475569', fontWeight: 600 }}>Figma Sync</th>
              <th style={{ padding: '10px 16px', color: '#475569', fontWeight: 600 }}>Code Parity</th>
              <th style={{ padding: '10px 16px', color: '#475569', fontWeight: 600 }}>Storybook</th>
              <th style={{ padding: '10px 16px', color: '#475569', fontWeight: 600 }}>Token Audit</th>
              <th style={{ padding: '10px 16px', color: '#475569', fontWeight: 600 }}>Status</th>
            </tr>
          </thead>
          <tbody>
            {componentsList.map((c) => (
              <tr key={c.id} style={{ borderBottom: '1px solid #f1f5f9' }}>
                <td style={{ padding: '12px 16px', fontWeight: 600, color: '#0f172a' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                    <span>{c.name}</span>
                    <span
                      style={{
                        fontSize: 10,
                        color: '#475569',
                        background: '#f1f5f9',
                        border: '1px solid #e2e8f0',
                        padding: '1px 6px',
                        borderRadius: 4,
                        fontWeight: 500,
                      }}
                    >
                      {c.category}
                    </span>
                  </div>
                </td>
                <td style={{ padding: '12px 16px', color: '#475569' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                    <Layers size={14} style={{ color: '#e11d48' }} />
                    <span>{c.figmaVariants} variants</span>
                  </div>
                </td>
                <td style={{ padding: '12px 16px', color: '#475569' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                    <GitBranch size={14} style={{ color: '#2563eb' }} />
                    <span>{c.codeProps} props</span>
                  </div>
                </td>
                <td style={{ padding: '12px 16px' }}>
                  <span style={{ display: 'inline-flex', alignItems: 'center', gap: 4, color: '#db2777', fontSize: 12, fontWeight: 500 }}>
                    <BookOpen size={13} />
                    CSF3 Verified
                  </span>
                </td>
                <td style={{ padding: '12px 16px' }}>
                  <span style={{ display: 'inline-flex', alignItems: 'center', gap: 4, color: '#059669', fontSize: 12, fontWeight: 500 }}>
                    <CheckCircle2 size={13} />
                    100% Tokenized
                  </span>
                </td>
                <td style={{ padding: '12px 16px' }}>
                  <span
                    style={{
                      fontSize: 11,
                      fontWeight: 600,
                      color: '#059669',
                      background: '#ecfdf5',
                      border: '1px solid #a7f3d0',
                      padding: '3px 8px',
                      borderRadius: 12,
                    }}
                  >
                    Production Ready
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
