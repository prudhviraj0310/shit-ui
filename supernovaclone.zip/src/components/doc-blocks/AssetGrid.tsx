'use client';

import React, { useState, useMemo } from 'react';
import { Search, Download, Copy, Check, Image as ImageIcon } from 'lucide-react';
import { AssetGridDocBlock } from '@/core/docs/types';

interface AssetItem {
  id: string;
  name: string;
  category: 'icons' | 'logos' | 'illustrations';
  svg: string;
  tags?: string[];
}

const DEFAULT_ASSETS: AssetItem[] = [
  {
    id: 'icon-arrow-right',
    name: 'ArrowRight',
    category: 'icons',
    tags: ['navigation', 'directional'],
    svg: `<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14M12 5l7 7-7 7"/></svg>`,
  },
  {
    id: 'icon-check-circle',
    name: 'CheckCircle',
    category: 'icons',
    tags: ['status', 'success', 'validation'],
    svg: `<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>`,
  },
  {
    id: 'icon-search',
    name: 'Search',
    category: 'icons',
    tags: ['utility', 'find', 'query'],
    svg: `<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></svg>`,
  },
  {
    id: 'icon-layers',
    name: 'Layers',
    category: 'icons',
    tags: ['components', 'design', 'structure'],
    svg: `<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="12 2 2 7 12 12 22 7 12 2"/><polyline points="2 17 12 22 22 17"/><polyline points="2 12 12 17 22 12"/></svg>`,
  },
  {
    id: 'icon-sparkles',
    name: 'Sparkles',
    category: 'icons',
    tags: ['ai', 'magic', 'feature'],
    svg: `<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m12 3-1.9 5.8a2 2 0 0 1-1.3 1.3L3 12l5.8 1.9a2 2 0 0 1 1.3 1.3L12 21l1.9-5.8a2 2 0 0 1 1.3-1.3L21 12l-5.8-1.9a2 2 0 0 1-1.3-1.3Z"/></svg>`,
  },
  {
    id: 'icon-shield-check',
    name: 'ShieldCheck',
    category: 'icons',
    tags: ['security', 'compliance', 'protection'],
    svg: `<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10"/><path d="m9 12 2 2 4-4"/></svg>`,
  },
];

interface AssetGridProps {
  block?: AssetGridDocBlock;
  assets?: AssetItem[];
}

export function AssetGrid({ block, assets = DEFAULT_ASSETS }: AssetGridProps) {
  const [search, setSearch] = useState('');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const filteredAssets = useMemo(() => {
    return assets.filter((asset) => {
      if (block?.category && asset.category !== block.category) {
        return false;
      }
      if (block?.filterTag && !asset.tags?.includes(block.filterTag)) {
        return false;
      }
      if (!search) return true;
      const q = search.toLowerCase();
      return (
        asset.name.toLowerCase().includes(q) ||
        asset.tags?.some((t) => t.toLowerCase().includes(q))
      );
    });
  }, [assets, block, search]);

  const copySvg = (svg: string, id: string) => {
    navigator.clipboard.writeText(svg);
    setCopiedId(`svg-${id}`);
    setTimeout(() => setCopiedId(null), 1500);
  };

  const copyJsx = (asset: AssetItem) => {
    const jsx = `export const ${asset.name}Icon = (props: React.SVGProps<SVGSVGElement>) => (\n  ${asset.svg.replace('<svg', '<svg {...props}')}\n);`;
    navigator.clipboard.writeText(jsx);
    setCopiedId(`jsx-${asset.id}`);
    setTimeout(() => setCopiedId(null), 1500);
  };

  const downloadSvg = (asset: AssetItem) => {
    const blob = new Blob([asset.svg], { type: 'image/svg+xml;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${asset.name.toLowerCase()}.svg`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const exportPng = (asset: AssetItem) => {
    const svgBlob = new Blob([asset.svg], { type: 'image/svg+xml;charset=utf-8' });
    const URLObject = window.URL || window.webkitURL || window;
    const blobURL = URLObject.createObjectURL(svgBlob);
    const image = new Image();
    image.onload = () => {
      const canvas = document.createElement('canvas');
      canvas.width = 128;
      canvas.height = 128;
      const context = canvas.getContext('2d');
      if (context) {
        context.drawImage(image, 0, 0, 128, 128);
        const png = canvas.toDataURL('image/png');
        const link = document.createElement('a');
        link.download = `${asset.name.toLowerCase()}.png`;
        link.href = png;
        link.click();
      }
      URLObject.revokeObjectURL(blobURL);
    };
    image.src = blobURL;
  };

  return (
    <div
      style={{
        margin: '24px 0',
        borderRadius: 16,
        border: '1px solid #e2e8f0',
        background: '#ffffff',
        padding: 20,
        fontFamily: 'Inter, system-ui, sans-serif',
        boxShadow: '0 1px 3px rgba(0,0,0,0.05)',
      }}
    >
      {/* Header & Search */}
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          marginBottom: 16,
          gap: 12,
          flexWrap: 'wrap',
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <ImageIcon size={18} style={{ color: '#0284c7' }} />
          <h4 style={{ margin: 0, fontSize: 15, fontWeight: 700, color: '#0f172a' }}>
            Vector Asset Catalog
          </h4>
          <span style={{ fontSize: 11, color: '#64748b' }}>({filteredAssets.length} assets)</span>
        </div>

        <div style={{ position: 'relative', width: 220 }}>
          <Search
            size={13}
            style={{ position: 'absolute', left: 10, top: '50%', transform: 'translateY(-50%)', color: '#94a3b8' }}
          />
          <input
            type="text"
            placeholder="Search icons by name..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            style={{
              width: '100%',
              padding: '6px 10px 6px 30px',
              borderRadius: 8,
              background: '#f8fafc',
              border: '1px solid #cbd5e1',
              color: '#0f172a',
              fontSize: 12,
              outline: 'none',
              boxSizing: 'border-box',
            }}
          />
        </div>
      </div>

      {/* Grid of Icons */}
      <div
        style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fill, minmax(140px, 1fr))',
          gap: 14,
        }}
      >
        {filteredAssets.map((asset) => {
          const svgCopied = copiedId === `svg-${asset.id}`;
          const jsxCopied = copiedId === `jsx-${asset.id}`;

          return (
            <div
              key={asset.id}
              style={{
                borderRadius: 12,
                border: '1px solid #e2e8f0',
                background: '#f8fafc',
                padding: 14,
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                gap: 8,
                transition: 'border-color 0.15s ease, transform 0.15s ease',
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.borderColor = '#0284c7';
                e.currentTarget.style.transform = 'translateY(-2px)';
                e.currentTarget.style.background = '#ffffff';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.borderColor = '#e2e8f0';
                e.currentTarget.style.transform = 'translateY(0)';
                e.currentTarget.style.background = '#f8fafc';
              }}
            >
              {/* Icon Visual */}
              <div
                style={{
                  width: 48,
                  height: 48,
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  color: '#0284c7',
                }}
                dangerouslySetInnerHTML={{ __html: asset.svg }}
              />

              <span style={{ fontSize: 12, fontWeight: 600, color: '#0f172a', textAlign: 'center' }}>
                {asset.name}
              </span>

              {/* Action Buttons */}
              <div style={{ display: 'flex', gap: 4, width: '100%', justifyContent: 'center', marginTop: 4 }}>
                <button
                  onClick={() => copySvg(asset.svg, asset.id)}
                  title="Copy SVG code"
                  style={{
                    padding: '4px 6px',
                    borderRadius: 6,
                    background: svgCopied ? '#dcfce7' : '#ffffff',
                    border: '1px solid #e2e8f0',
                    color: svgCopied ? '#15803d' : '#475569',
                    fontSize: 10,
                    fontWeight: 600,
                    cursor: 'pointer',
                  }}
                >
                  {svgCopied ? '✓' : 'SVG'}
                </button>

                <button
                  onClick={() => copyJsx(asset)}
                  title="Copy React JSX component"
                  style={{
                    padding: '4px 6px',
                    borderRadius: 6,
                    background: jsxCopied ? '#dcfce7' : '#ffffff',
                    border: '1px solid #e2e8f0',
                    color: jsxCopied ? '#15803d' : '#475569',
                    fontSize: 10,
                    fontWeight: 600,
                    cursor: 'pointer',
                  }}
                >
                  {jsxCopied ? '✓' : 'JSX'}
                </button>

                <button
                  onClick={() => downloadSvg(asset)}
                  title="Download SVG file"
                  style={{
                    padding: '4px 6px',
                    borderRadius: 6,
                    background: '#ffffff',
                    border: '1px solid #e2e8f0',
                    color: '#475569',
                    fontSize: 10,
                    fontWeight: 600,
                    cursor: 'pointer',
                  }}
                >
                  <Download size={10} />
                </button>

                <button
                  onClick={() => exportPng(asset)}
                  title="Export 128px PNG"
                  style={{
                    padding: '4px 6px',
                    borderRadius: 6,
                    background: '#ffffff',
                    border: '1px solid #e2e8f0',
                    color: '#475569',
                    fontSize: 10,
                    fontWeight: 600,
                    cursor: 'pointer',
                  }}
                >
                  PNG
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
