'use client';

import React, { useState } from 'react';
import { Copy, Check, Bot, Terminal, Sparkles, Cpu, Radio } from 'lucide-react';
import { ContextMcpDocBlock } from '@/core/docs/types';

interface ContextMcpCardProps {
  block: ContextMcpDocBlock;
}

export function ContextMcpCard({ block }: ContextMcpCardProps) {
  const [activeClient, setActiveClient] = useState<'cursor' | 'claude' | 'vscode' | 'cli'>('cursor');
  const [copied, setCopied] = useState(false);

  const mcpUrl = block.mcpUrl || 'http://localhost:3000/api/mcp';
  const title = block.title || 'Model Context Protocol (MCP) — AI Agent Gateway';
  const description =
    block.description ||
    'Connect Cursor, Claude Code, or any MCP-compatible coding agent directly to this living design system to read tokens, inspect components, and write automated styles.';

  const configs: Record<'cursor' | 'claude' | 'vscode' | 'cli', { filename: string; code: string; desc: string }> = {
    cursor: {
      filename: '.cursor/mcp.json',
      desc: 'Add to your project workspace or global Cursor configuration.',
      code: JSON.stringify(
        {
          mcpServers: {
            'nexus-design-os': {
              command: 'npx',
              args: ['nexus-design-os', 'mcp'],
            },
          },
        },
        null,
        2
      ),
    },
    claude: {
      filename: 'claude_desktop_config.json',
      desc: 'Add to ~/Library/Application Support/Claude/claude_desktop_config.json',
      code: JSON.stringify(
        {
          mcpServers: {
            'nexus-design-system': {
              command: 'node',
              args: ['dist/cli/index.js', 'mcp'],
            },
          },
        },
        null,
        2
      ),
    },
    vscode: {
      filename: '.vscode/settings.json',
      desc: 'Configure VS Code Copilot & MCP Tools extension.',
      code: JSON.stringify(
        {
          'mcp.servers': {
            'nexus-design-os': {
              url: mcpUrl,
              type: 'sse',
            },
          },
        },
        null,
        2
      ),
    },
    cli: {
      filename: 'Terminal / CLI',
      desc: 'Direct Stdio execution for autonomous agents and subagents.',
      code: `npx nexus-design-os mcp`,
    },
  };

  const current = configs[activeClient];

  const handleCopy = () => {
    navigator.clipboard.writeText(current.code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div
      style={{
        margin: '20px 0',
        borderRadius: 14,
        background: '#ffffff',
        border: '1px solid #e2e8f0',
        boxShadow: '0 1px 3px rgba(0, 0, 0, 0.04)',
        overflow: 'hidden',
        fontFamily: 'Inter, system-ui, sans-serif',
      }}
    >
      {/* Header bar */}
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          padding: '14px 20px',
          background: '#f8fafc',
          borderBottom: '1px solid #e2e8f0',
          gap: 12,
          flexWrap: 'wrap',
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <div
            style={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              width: 36,
              height: 36,
              borderRadius: 10,
              background: 'linear-gradient(135deg, #4f46e5, #7c3aed)',
              color: '#ffffff',
              boxShadow: '0 2px 8px rgba(99, 102, 241, 0.25)',
              flexShrink: 0,
            }}
          >
            <Bot size={18} />
          </div>
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <span style={{ fontSize: 14, fontWeight: 700, color: '#0f172a' }}>{title}</span>
              <span
                style={{
                  display: 'inline-flex',
                  alignItems: 'center',
                  gap: 4,
                  fontSize: 10,
                  fontWeight: 700,
                  textTransform: 'uppercase',
                  letterSpacing: '0.05em',
                  background: '#ecfdf5',
                  color: '#059669',
                  padding: '2px 8px',
                  borderRadius: 12,
                  border: '1px solid #a7f3d0',
                }}
              >
                <Radio size={10} className="animate-pulse" />
                Live Agent Gateway
              </span>
            </div>
            <p style={{ margin: '2px 0 0', fontSize: 12, color: '#475569' }}>{description}</p>
          </div>
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          <span
            style={{
              fontSize: 11,
              fontFamily: 'monospace',
              background: '#ffffff',
              color: '#0f172a',
              padding: '4px 10px',
              borderRadius: 6,
              border: '1px solid #cbd5e1',
              fontWeight: 500,
            }}
          >
            {mcpUrl}
          </span>
        </div>
      </div>

      {/* Client selector tabs */}
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          padding: '8px 16px',
          background: '#ffffff',
          borderBottom: '1px solid #e2e8f0',
          gap: 8,
          flexWrap: 'wrap',
        }}
      >
        <div style={{ display: 'flex', gap: 6 }}>
          {[
            { id: 'cursor' as const, label: 'Cursor IDE', icon: Sparkles },
            { id: 'claude' as const, label: 'Claude Code', icon: Cpu },
            { id: 'vscode' as const, label: 'VS Code Copilot', icon: Bot },
            { id: 'cli' as const, label: 'Stdio Runner', icon: Terminal },
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeClient === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveClient(tab.id)}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: 6,
                  padding: '6px 12px',
                  borderRadius: 8,
                  border: `1px solid ${isActive ? '#bfdbfe' : 'transparent'}`,
                  fontSize: 12,
                  fontWeight: 600,
                  cursor: 'pointer',
                  background: isActive ? '#eff6ff' : 'transparent',
                  color: isActive ? '#2563eb' : '#64748b',
                  transition: 'all 0.15s ease',
                }}
              >
                <Icon size={13} />
                {tab.label}
              </button>
            );
          })}
        </div>

        <button
          onClick={handleCopy}
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: 6,
            padding: '6px 12px',
            borderRadius: 8,
            border: 'none',
            background: copied ? '#10b981' : '#2563eb',
            color: '#ffffff',
            fontSize: 12,
            fontWeight: 600,
            cursor: 'pointer',
            transition: 'all 0.15s ease',
            boxShadow: '0 1px 2px rgba(0, 0, 0, 0.05)',
          }}
        >
          {copied ? <Check size={13} /> : <Copy size={13} />}
          {copied ? 'Copied Config' : 'Copy Config'}
        </button>
      </div>

      {/* Code body */}
      <div style={{ padding: '16px 20px', background: '#090d16' }}>
        <div style={{ marginBottom: 8, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <span style={{ fontSize: 11, fontWeight: 600, color: '#94a3b8' }}>Target File: {current.filename}</span>
          <span style={{ fontSize: 11, color: '#64748b' }}>{current.desc}</span>
        </div>
        <pre
          style={{
            margin: 0,
            padding: 14,
            borderRadius: 8,
            background: '#040711',
            border: '1px solid #1e293b',
            fontSize: 12,
            fontFamily: 'monospace',
            color: '#38bdf8',
            overflowX: 'auto',
            lineHeight: 1.5,
          }}
        >
          <code>{current.code}</code>
        </pre>
      </div>
    </div>
  );
}
