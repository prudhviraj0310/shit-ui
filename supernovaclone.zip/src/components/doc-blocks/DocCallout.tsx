'use client';

import React from 'react';
import { Info, AlertTriangle, CheckCircle2, AlertOctagon } from 'lucide-react';
import { CalloutDocBlock } from '@/core/docs/types';

interface DocCalloutProps {
  block: CalloutDocBlock;
}

export function DocCallout({ block }: DocCalloutProps) {
  const type = block.calloutType || 'info';

  const config = {
    info: {
      border: '#bae6fd',
      background: '#f0f9ff',
      iconColor: '#0284c7',
      titleColor: '#0369a1',
      textColor: '#0c4a6e',
      icon: Info,
    },
    warning: {
      border: '#fde68a',
      background: '#fffbeb',
      iconColor: '#d97706',
      titleColor: '#b45309',
      textColor: '#78350f',
      icon: AlertTriangle,
    },
    success: {
      border: '#bbf7d0',
      background: '#f0fdf4',
      iconColor: '#16a34a',
      titleColor: '#15803d',
      textColor: '#14532d',
      icon: CheckCircle2,
    },
    error: {
      border: '#fecdd3',
      background: '#fff1f2',
      iconColor: '#e11d48',
      titleColor: '#be123c',
      textColor: '#881337',
      icon: AlertOctagon,
    },
    danger: {
      border: '#fecdd3',
      background: '#fff1f2',
      iconColor: '#e11d48',
      titleColor: '#be123c',
      textColor: '#881337',
      icon: AlertOctagon,
    },
  }[type as 'info' | 'warning' | 'success' | 'error' | 'danger'] || {
    border: '#bae6fd',
    background: '#f0f9ff',
    iconColor: '#0284c7',
    titleColor: '#0369a1',
    textColor: '#0c4a6e',
    icon: Info,
  };

  const IconComponent = config.icon;

  return (
    <div
      style={{
        margin: '20px 0',
        padding: '16px 20px',
        borderRadius: 12,
        border: `1px solid ${config.border}`,
        background: config.background,
        display: 'flex',
        gap: 14,
        alignItems: 'flex-start',
        fontFamily: 'Inter, system-ui, sans-serif',
      }}
    >
      <div style={{ marginTop: 2, flexShrink: 0 }}>
        <IconComponent size={18} style={{ color: config.iconColor }} />
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: 4, flex: 1 }}>
        {block.title && (
          <strong style={{ fontSize: 13, fontWeight: 700, color: config.titleColor }}>
            {block.title}
          </strong>
        )}
        <p style={{ margin: 0, fontSize: 13, color: config.textColor, lineHeight: 1.55 }}>
          {block.text}
        </p>
      </div>
    </div>
  );
}
