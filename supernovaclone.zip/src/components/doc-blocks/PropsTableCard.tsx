'use client';

import React from 'react';
import { PropsTableDocBlock } from '@/core/docs/types';
import { Layers } from 'lucide-react';

interface PropsTableCardProps {
  block: PropsTableDocBlock;
}

export function PropsTableCard({ block }: PropsTableCardProps) {
  const title = block.title || `${block.componentName || 'Component'} API Props`;

  return (
    <div
      className="doc-props-table-card"
      style={{
        borderRadius: 14,
        border: '1px solid #e2e8f0',
        background: '#ffffff',
        overflow: 'hidden',
        boxShadow: '0 1px 3px rgba(0, 0, 0, 0.04)',
        fontFamily: 'Inter, system-ui, sans-serif',
      }}
    >
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          padding: '12px 18px',
          background: '#f8fafc',
          borderBottom: '1px solid #e2e8f0',
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <Layers size={16} color="#2563eb" />
          <span style={{ fontSize: 14, fontWeight: 700, color: '#0f172a' }}>{title}</span>
        </div>
        <span
          style={{
            fontSize: 11,
            fontWeight: 600,
            padding: '3px 8px',
            borderRadius: 6,
            background: '#eff6ff',
            color: '#2563eb',
            border: '1px solid #bfdbfe',
          }}
        >
          TypeScript / React
        </span>
      </div>

      <div style={{ overflowX: 'auto' }}>
        <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left', fontSize: 13 }}>
          <thead>
            <tr style={{ background: '#f8fafc', borderBottom: '1px solid #e2e8f0' }}>
              <th style={{ padding: '10px 16px', fontWeight: 600, color: '#475569' }}>Prop</th>
              <th style={{ padding: '10px 16px', fontWeight: 600, color: '#475569' }}>Type</th>
              <th style={{ padding: '10px 16px', fontWeight: 600, color: '#475569' }}>Default</th>
              <th style={{ padding: '10px 16px', fontWeight: 600, color: '#475569' }}>Description</th>
            </tr>
          </thead>
          <tbody>
            {(block.props || []).map((p, idx) => (
              <tr
                key={idx}
                style={{
                  borderBottom: '1px solid #f1f5f9',
                  background: idx % 2 === 1 ? '#fafafa' : 'transparent',
                }}
              >
                <td style={{ padding: '12px 16px' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                    <code style={{ color: '#2563eb', fontWeight: 600, fontSize: 13, fontFamily: 'monospace' }}>
                      {p.name}
                    </code>
                    {p.required && (
                      <span
                        style={{
                          fontSize: 10,
                          fontWeight: 700,
                          color: '#b91c1c',
                          background: '#fee2e2',
                          border: '1px solid #fecdd3',
                          padding: '1px 5px',
                          borderRadius: 4,
                        }}
                      >
                        REQUIRED
                      </span>
                    )}
                  </div>
                </td>
                <td style={{ padding: '12px 16px' }}>
                  <code
                    style={{
                      color: '#7e22ce',
                      fontSize: 12,
                      background: '#f5f3ff',
                      border: '1px solid #ede9fe',
                      padding: '2px 6px',
                      borderRadius: 4,
                      fontFamily: 'monospace',
                    }}
                  >
                    {p.type}
                  </code>
                </td>
                <td style={{ padding: '12px 16px' }}>
                  {p.defaultValue ? (
                    <code style={{ color: '#475569', fontSize: 12, fontFamily: 'monospace' }}>{p.defaultValue}</code>
                  ) : (
                    <span style={{ color: '#94a3b8' }}>-</span>
                  )}
                </td>
                <td style={{ padding: '12px 16px', color: '#334155', lineHeight: 1.5 }}>
                  {p.description}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
