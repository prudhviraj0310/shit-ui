'use client';

import React, { useState } from 'react';
import { PromptTemplateDocBlock } from '@/core/docs/types';
import { Sparkles, Copy, Check, Terminal, Cpu } from 'lucide-react';

interface PromptTemplateCardProps {
  block: PromptTemplateDocBlock;
}

export function PromptTemplateCard({ block }: PromptTemplateCardProps) {
  const [selectedTool, setSelectedTool] = useState<'cursor' | 'claude' | 'copilot' | 'chatgpt'>('cursor');
  const [copied, setCopied] = useState(false);

  const title = block.title || 'AI System Prompt Template';
  const desc = block.description || 'Pre-configured prompt template optimized for AI coding assistants.';

  // Interpolate variables if provided
  let formattedPrompt = block.prompt;
  if (block.variables) {
    for (const [key, val] of Object.entries(block.variables)) {
      formattedPrompt = formattedPrompt.replaceAll(`{{${key}}}`, val);
    }
  }

  const handleCopy = () => {
    navigator.clipboard.writeText(formattedPrompt);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div
      className="doc-prompt-template-card"
      style={{
        borderRadius: 14,
        border: '1px solid #e9d5ff',
        background: '#ffffff',
        padding: 20,
        boxShadow: '0 1px 3px rgba(0, 0, 0, 0.04)',
        fontFamily: 'Inter, system-ui, sans-serif',
      }}
    >
      <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 14 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <div
            style={{
              width: 36,
              height: 36,
              borderRadius: 10,
              background: 'linear-gradient(135deg, #9333ea 0%, #ec4899 100%)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              boxShadow: '0 2px 8px rgba(147, 51, 234, 0.25)',
            }}
          >
            <Sparkles size={18} color="#ffffff" />
          </div>
          <div>
            <h4 style={{ margin: 0, fontSize: 16, fontWeight: 700, color: '#0f172a' }}>{title}</h4>
            <p style={{ margin: 0, fontSize: 13, color: '#7e22ce' }}>{desc}</p>
          </div>
        </div>

        <span
          style={{
            fontSize: 11,
            fontWeight: 700,
            textTransform: 'uppercase',
            letterSpacing: '0.05em',
            padding: '4px 10px',
            borderRadius: 999,
            background: '#f3e8ff',
            border: '1px solid #e9d5ff',
            color: '#7e22ce',
          }}
        >
          Prompt Template
        </span>
      </div>

      {/* Target tools tabs */}
      <div style={{ display: 'flex', gap: 8, marginBottom: 12 }}>
        {(['cursor', 'claude', 'copilot', 'chatgpt'] as const).map((tool) => (
          <button
            key={tool}
            onClick={() => setSelectedTool(tool)}
            style={{
              padding: '6px 12px',
              borderRadius: 8,
              border: selectedTool === tool ? '1px solid #c084fc' : '1px solid #e2e8f0',
              background: selectedTool === tool ? '#f5f3ff' : '#ffffff',
              color: selectedTool === tool ? '#6b21a8' : '#64748b',
              fontSize: 12,
              fontWeight: 600,
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              gap: 6,
              transition: 'all 0.15s ease',
            }}
          >
            {tool === 'cursor' ? <Terminal size={13} /> : <Cpu size={13} />}
            {tool.charAt(0).toUpperCase() + tool.slice(1)}
          </button>
        ))}
      </div>

      {/* Prompt preview box */}
      <div
        style={{
          position: 'relative',
          borderRadius: 10,
          background: '#090d16',
          border: '1px solid #1e293b',
          padding: '14px 16px',
        }}
      >
        <button
          onClick={handleCopy}
          style={{
            position: 'absolute',
            top: 10,
            right: 10,
            display: 'flex',
            alignItems: 'center',
            gap: 5,
            padding: '4px 10px',
            borderRadius: 6,
            border: '1px solid rgba(255, 255, 255, 0.15)',
            background: copied ? 'rgba(34, 197, 94, 0.25)' : 'rgba(255, 255, 255, 0.08)',
            color: copied ? '#4ade80' : '#f1f5f9',
            fontSize: 12,
            fontWeight: 600,
            cursor: 'pointer',
          }}
        >
          {copied ? <Check size={13} /> : <Copy size={13} />}
          {copied ? 'Copied!' : 'Copy Prompt'}
        </button>

        <pre
          style={{
            margin: 0,
            fontSize: 13,
            lineHeight: 1.6,
            fontFamily: 'JetBrains Mono, monospace',
            color: '#f1f5f9',
            whiteSpace: 'pre-wrap',
            paddingRight: 80,
          }}
        >
          {formattedPrompt}
        </pre>
      </div>

      {block.variables && Object.keys(block.variables).length > 0 && (
        <div style={{ marginTop: 12, display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap' }}>
          <span style={{ fontSize: 11, color: '#64748b', fontWeight: 600 }}>Active Variables:</span>
          {Object.entries(block.variables).map(([k, v]) => (
            <span
              key={k}
              style={{
                fontSize: 11,
                fontFamily: 'monospace',
                background: '#f8fafc',
                border: '1px solid #e2e8f0',
                padding: '2px 8px',
                borderRadius: 4,
                color: '#2563eb',
                fontWeight: 600,
              }}
            >
              {`{{${k}}}`} = &quot;{v}&quot;
            </span>
          ))}
        </div>
      )}
    </div>
  );
}
