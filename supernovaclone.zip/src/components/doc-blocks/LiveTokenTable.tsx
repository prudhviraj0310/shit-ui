'use client';

import React, { useState, useMemo } from 'react';
import { Search, Copy, Check, Tag } from 'lucide-react';
import { TokenTableDocBlock } from '@/core/docs/types';

interface LiveTokenItem {
  path: string;
  category: string;
  type: string;
  rawValue: string;
  resolvedValue: string;
  isAlias?: boolean;
  aliasTarget?: string;
  description?: string;
}

interface LiveTokenTableProps {
  block?: TokenTableDocBlock;
  tokens?: LiveTokenItem[];
}

const DEFAULT_TOKENS: LiveTokenItem[] = [
  { path: 'color.brand.primary', category: 'color', type: 'color', rawValue: '#2563eb', resolvedValue: '#2563eb', description: 'Primary brand blue' },
  { path: 'color.brand.secondary', category: 'color', type: 'color', rawValue: '#4f46e5', resolvedValue: '#4f46e5', description: 'Secondary indigo' },
  { path: 'color.text.primary', category: 'color', type: 'color', rawValue: '#0f172a', resolvedValue: '#0f172a', description: 'Main foreground body text' },
  { path: 'color.background.canvas', category: 'color', type: 'color', rawValue: '#f8fafc', resolvedValue: '#f8fafc', description: 'Light workspace background' },
  { path: 'spacing.sm', category: 'spacing', type: 'dimension', rawValue: '8px', resolvedValue: '8px', description: 'Tight component padding' },
  { path: 'spacing.md', category: 'spacing', type: 'dimension', rawValue: '16px', resolvedValue: '16px', description: 'Standard container gutter' },
  { path: 'spacing.lg', category: 'spacing', type: 'dimension', rawValue: '24px', resolvedValue: '24px', description: 'Generous card spacing' },
  { path: 'radius.md', category: 'radius', type: 'borderRadius', rawValue: '8px', resolvedValue: '8px', description: 'Standard button & input radius' },
  { path: 'radius.lg', category: 'radius', type: 'borderRadius', rawValue: '16px', resolvedValue: '16px', description: 'Modal and card corner radius' },
];

export function LiveTokenTable({ block, tokens = DEFAULT_TOKENS }: LiveTokenTableProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [copiedPath, setCopiedPath] = useState<string | null>(null);

  const filteredTokens = useMemo(() => {
    return tokens.filter((t) => {
      if (block?.category && block.category !== 'all' && t.category !== block.category && t.type !== block.category) {
        return false;
      }
      if (block?.filterPath && !t.path.startsWith(block.filterPath)) {
        return false;
      }
      if (!searchTerm) return true;
      const q = searchTerm.toLowerCase();
      return (
        t.path.toLowerCase().includes(q) ||
        t.resolvedValue.toLowerCase().includes(q) ||
        (t.description || '').toLowerCase().includes(q)
      );
    });
  }, [tokens, block, searchTerm]);

  const copyToken = (value: string, path: string) => {
    navigator.clipboard.writeText(value);
    setCopiedPath(path);
    setTimeout(() => setCopiedPath(null), 1500);
  };

  const isColor = (val: string) => val.startsWith('#') || val.startsWith('rgb');

  return (
    <div
      style={{
        margin: '24px 0',
        borderRadius: 14,
        border: '1px solid #e2e8f0',
        background: '#ffffff',
        boxShadow: '0 1px 3px rgba(0, 0, 0, 0.04)',
        overflow: 'hidden',
        fontFamily: 'Inter, system-ui, sans-serif',
      }}
    >
      {/* Top Header & Search Bar */}
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          padding: '14px 18px',
          borderBottom: '1px solid #e2e8f0',
          background: '#f8fafc',
          gap: 12,
          flexWrap: 'wrap',
        }}
      >
        <div>
          <h4 style={{ margin: 0, fontSize: 14, fontWeight: 700, color: '#0f172a' }}>
            {block?.title || 'Design System Tokens'}
          </h4>
          <span style={{ fontSize: 11, color: '#64748b' }}>
            Showing {filteredTokens.length} tokens {block?.category ? `in ${block.category}` : ''}
          </span>
        </div>

        {/* Search */}
        <div style={{ position: 'relative', width: 220 }}>
          <Search
            size={13}
            style={{ position: 'absolute', left: 10, top: '50%', transform: 'translateY(-50%)', color: '#64748b' }}
          />
          <input
            type="text"
            placeholder="Filter tokens..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            style={{
              width: '100%',
              padding: '6px 10px 6px 30px',
              borderRadius: 8,
              background: '#ffffff',
              border: '1px solid #cbd5e1',
              color: '#0f172a',
              fontSize: 12,
              outline: 'none',
              boxSizing: 'border-box',
            }}
          />
        </div>
      </div>

      {/* Token Grid Table */}
      <div style={{ overflowX: 'auto', maxHeight: 380, overflowY: 'auto' }}>
        <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 12, textAlign: 'left' }}>
          <thead>
            <tr style={{ background: '#f8fafc', borderBottom: '1px solid #e2e8f0', color: '#475569' }}>
              <th style={{ padding: '10px 16px', fontWeight: 600 }}>Token Path</th>
              <th style={{ padding: '10px 16px', fontWeight: 600 }}>Value</th>
              <th style={{ padding: '10px 16px', fontWeight: 600 }}>Category</th>
              <th style={{ padding: '10px 16px', fontWeight: 600, textAlign: 'right' }}>Actions</th>
            </tr>
          </thead>
          <tbody>
            {filteredTokens.map((token, idx) => {
              const copied = copiedPath === token.path;
              return (
                <tr
                  key={`${token.path}-${idx}`}
                  style={{
                    borderBottom: '1px solid #f1f5f9',
                    transition: 'background 0.15s ease',
                  }}
                  onMouseEnter={(e) => (e.currentTarget.style.background = '#f8fafc')}
                  onMouseLeave={(e) => (e.currentTarget.style.background = 'transparent')}
                >
                  <td style={{ padding: '10px 16px' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                      <code style={{ color: '#0f172a', fontFamily: 'monospace', fontWeight: 600 }}>
                        {token.path}
                      </code>
                      {token.isAlias && (
                        <span
                          title={`Aliased to ${token.aliasTarget}`}
                          style={{
                            padding: '1px 6px',
                            borderRadius: 4,
                            background: '#f3e8ff',
                            border: '1px solid #e9d5ff',
                            color: '#7e22ce',
                            fontSize: 10,
                            fontWeight: 600,
                          }}
                        >
                          Alias
                        </span>
                      )}
                    </div>
                    {token.description && (
                      <div style={{ fontSize: 11, color: '#64748b', marginTop: 2 }}>{token.description}</div>
                    )}
                  </td>

                  <td style={{ padding: '10px 16px' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                      {isColor(token.resolvedValue) && (
                        <span
                          style={{
                            width: 18,
                            height: 18,
                            borderRadius: 4,
                            background: token.resolvedValue,
                            border: '1px solid #cbd5e1',
                            boxShadow: '0 1px 2px rgba(0,0,0,0.05)',
                            display: 'inline-block',
                          }}
                          title={token.resolvedValue}
                        />
                      )}
                      <code style={{ color: '#2563eb', fontFamily: 'monospace', fontWeight: 600 }}>
                        {token.resolvedValue}
                      </code>
                    </div>
                  </td>

                  <td style={{ padding: '10px 16px' }}>
                    <span
                      style={{
                        padding: '2px 8px',
                        borderRadius: 12,
                        background: '#f1f5f9',
                        border: '1px solid #e2e8f0',
                        color: '#475569',
                        fontSize: 11,
                        fontWeight: 500,
                      }}
                    >
                      {token.category}
                    </span>
                  </td>

                  <td style={{ padding: '10px 16px', textAlign: 'right' }}>
                    <button
                      onClick={() => copyToken(token.resolvedValue, token.path)}
                      title="Copy resolved value"
                      style={{
                        padding: '5px 10px',
                        borderRadius: 6,
                        background: copied ? '#ecfdf5' : '#ffffff',
                        border: `1px solid ${copied ? '#a7f3d0' : '#e2e8f0'}`,
                        color: copied ? '#059669' : '#475569',
                        fontSize: 11,
                        fontWeight: 500,
                        cursor: 'pointer',
                        display: 'inline-flex',
                        alignItems: 'center',
                        gap: 4,
                        boxShadow: '0 1px 2px rgba(0,0,0,0.02)',
                      }}
                    >
                      {copied ? <Check size={12} /> : <Copy size={12} />}
                      {copied ? 'Copied' : 'Copy'}
                    </button>
                  </td>
                </tr>
              );
            })}

            {filteredTokens.length === 0 && (
              <tr>
                <td colSpan={4} style={{ padding: 24, textAlign: 'center', color: '#64748b' }}>
                  No matching tokens found for "{searchTerm}".
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
