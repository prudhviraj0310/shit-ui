'use client';

import React, { useState } from 'react';
import { Sliders, Laptop, Tablet, Smartphone, Copy, Check } from 'lucide-react';
import { InteractivePlaygroundDocBlock } from '@/core/docs/types';

interface InteractivePlaygroundProps {
  block: InteractivePlaygroundDocBlock;
}

export function InteractivePlayground({ block }: InteractivePlaygroundProps) {
  const componentName = block.componentName || 'Button';

  // Initialize props state from defaults
  const [props, setProps] = useState<Record<string, any>>({
    variant: 'primary',
    size: 'medium',
    disabled: false,
    children: 'Interactive Component',
    ...block.defaultProps,
  });

  const [viewport, setViewport] = useState<'desktop' | 'tablet' | 'mobile'>('desktop');
  const [copied, setCopied] = useState(false);

  const supportedProps = block.supportedProps || [
    { name: 'variant', type: 'select', options: ['primary', 'secondary', 'destructive', 'ghost'], defaultValue: 'primary' },
    { name: 'size', type: 'select', options: ['small', 'medium', 'large'], defaultValue: 'medium' },
    { name: 'disabled', type: 'boolean', defaultValue: false },
    { name: 'children', type: 'string', defaultValue: 'Interactive Component' },
  ];

  const handlePropChange = (key: string, value: any) => {
    setProps((prev) => ({ ...prev, [key]: value }));
  };

  const generatedJsx = `<${componentName}${Object.entries(props)
    .filter(([k, v]) => {
      if (k === 'children') return false;
      if (typeof v === 'boolean') return v;
      return v !== undefined && v !== '';
    })
    .map(([k, v]) => (typeof v === 'boolean' ? ` ${k}` : ` ${k}="${v}"`))
    .join('')}>
  ${props.children || ''}
</${componentName}>`;

  const copyCode = () => {
    navigator.clipboard.writeText(generatedJsx);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div
      style={{
        margin: '28px 0',
        borderRadius: 14,
        border: '1px solid #e2e8f0',
        background: '#ffffff',
        overflow: 'hidden',
        boxShadow: '0 1px 3px rgba(0, 0, 0, 0.04)',
        fontFamily: 'Inter, system-ui, sans-serif',
      }}
    >
      {/* Header bar */}
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          padding: '12px 18px',
          background: '#f8fafc',
          borderBottom: '1px solid #e2e8f0',
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <span style={{ fontSize: 13, fontWeight: 700, color: '#0f172a' }}>
            {block.title || `${componentName} Playground`}
          </span>
          <span
            style={{
              padding: '2px 8px',
              borderRadius: 6,
              background: '#eff6ff',
              border: '1px solid #bfdbfe',
              color: '#2563eb',
              fontSize: 11,
              fontWeight: 600,
            }}
          >
            Live Component
          </span>
        </div>

        {/* Viewport Modes */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 2, background: '#ffffff', border: '1px solid #cbd5e1', borderRadius: 8, padding: 2 }}>
          <button
            onClick={() => setViewport('desktop')}
            title="Desktop View"
            style={{
              padding: '5px 8px',
              borderRadius: 6,
              border: 'none',
              background: viewport === 'desktop' ? '#f1f5f9' : 'transparent',
              color: viewport === 'desktop' ? '#0f172a' : '#64748b',
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
            }}
          >
            <Laptop size={14} />
          </button>
          <button
            onClick={() => setViewport('tablet')}
            title="Tablet View (768px)"
            style={{
              padding: '5px 8px',
              borderRadius: 6,
              border: 'none',
              background: viewport === 'tablet' ? '#f1f5f9' : 'transparent',
              color: viewport === 'tablet' ? '#0f172a' : '#64748b',
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
            }}
          >
            <Tablet size={14} />
          </button>
          <button
            onClick={() => setViewport('mobile')}
            title="Mobile View (375px)"
            style={{
              padding: '5px 8px',
              borderRadius: 6,
              border: 'none',
              background: viewport === 'mobile' ? '#f1f5f9' : 'transparent',
              color: viewport === 'mobile' ? '#0f172a' : '#64748b',
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
            }}
          >
            <Smartphone size={14} />
          </button>
        </div>
      </div>

      {/* Main Interactive Stage */}
      <div
        style={{
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
          minHeight: 240,
          background: '#f8fafc',
          borderBottom: '1px solid #e2e8f0',
          padding: 32,
        }}
      >
        <div
          style={{
            width: viewport === 'mobile' ? '375px' : viewport === 'tablet' ? '768px' : '100%',
            maxWidth: '100%',
            transition: 'width 0.25s ease',
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center',
          }}
        >
          {/* Dynamic Component Rendering */}
          <button
            disabled={Boolean(props.disabled)}
            style={{
              padding: props.size === 'small' ? '6px 14px' : props.size === 'large' ? '14px 28px' : '10px 20px',
              fontSize: props.size === 'small' ? '12px' : props.size === 'large' ? '16px' : '14px',
              borderRadius: 8,
              fontWeight: 600,
              cursor: props.disabled ? 'not-allowed' : 'pointer',
              opacity: props.disabled ? 0.5 : 1,
              background: props.variant === 'secondary'
                ? '#f1f5f9'
                : props.variant === 'destructive'
                  ? '#dc2626'
                  : props.variant === 'ghost'
                    ? 'transparent'
                    : '#2563eb',
              color: props.variant === 'secondary' || props.variant === 'ghost' ? '#0f172a' : '#ffffff',
              border: props.variant === 'ghost'
                ? '1px solid #cbd5e1'
                : props.variant === 'secondary'
                  ? '1px solid #e2e8f0'
                  : 'none',
              boxShadow: props.variant === 'primary' ? '0 2px 8px rgba(37, 99, 235, 0.25)' : 'none',
              transition: 'all 0.15s ease',
            }}
          >
            {props.children || 'Interactive Button'}
          </button>
        </div>
      </div>

      {/* Dynamic Props Controls Panel */}
      <div
        style={{
          padding: '16px 20px',
          background: '#ffffff',
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 14 }}>
          <Sliders size={13} style={{ color: '#2563eb' }} />
          <span style={{ fontSize: 11, fontWeight: 700, color: '#475569', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
            Prop Controls
          </span>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: 14 }}>
          {supportedProps.map((p) => {
            const currentVal = props[p.name] !== undefined ? props[p.name] : p.defaultValue;

            return (
              <div key={p.name} style={{ display: 'flex', flexDirection: 'column', gap: 5 }}>
                <label style={{ fontSize: 12, fontWeight: 600, color: '#475569', fontFamily: 'monospace' }}>
                  {p.name}
                </label>

                {p.type === 'select' && p.options ? (
                  <select
                    value={currentVal}
                    onChange={(e) => handlePropChange(p.name, e.target.value)}
                    style={{
                      padding: '8px 10px',
                      borderRadius: 6,
                      background: '#ffffff',
                      border: '1px solid #cbd5e1',
                      color: '#0f172a',
                      fontSize: 12,
                      outline: 'none',
                    }}
                  >
                    {p.options.map((opt) => (
                      <option key={opt} value={opt}>
                        {opt}
                      </option>
                    ))}
                  </select>
                ) : p.type === 'boolean' ? (
                  <button
                    onClick={() => handlePropChange(p.name, !currentVal)}
                    style={{
                      padding: '8px 12px',
                      borderRadius: 6,
                      background: currentVal ? '#eff6ff' : '#f8fafc',
                      border: `1px solid ${currentVal ? '#bfdbfe' : '#cbd5e1'}`,
                      color: currentVal ? '#2563eb' : '#64748b',
                      fontSize: 12,
                      fontWeight: 600,
                      cursor: 'pointer',
                      textAlign: 'left',
                    }}
                  >
                    {currentVal ? 'true' : 'false'}
                  </button>
                ) : (
                  <input
                    type="text"
                    value={String(currentVal || '')}
                    onChange={(e) => handlePropChange(p.name, e.target.value)}
                    style={{
                      padding: '8px 10px',
                      borderRadius: 6,
                      background: '#ffffff',
                      border: '1px solid #cbd5e1',
                      color: '#0f172a',
                      fontSize: 12,
                      outline: 'none',
                    }}
                  />
                )}
              </div>
            );
          })}
        </div>

        {/* Live Code Output */}
        <div style={{ marginTop: 16, paddingTop: 14, borderTop: '1px solid #e2e8f0' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifySelf: 'stretch', justifyContent: 'space-between', marginBottom: 8 }}>
            <span style={{ fontSize: 11, fontWeight: 700, color: '#64748b', textTransform: 'uppercase' }}>
              JSX Output
            </span>
            <button
              onClick={copyCode}
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: 5,
                padding: '4px 8px',
                borderRadius: 6,
                background: '#f8fafc',
                border: '1px solid #e2e8f0',
                color: copied ? '#059669' : '#475569',
                fontSize: 11,
                fontWeight: 500,
                cursor: 'pointer',
              }}
            >
              {copied ? <Check size={12} /> : <Copy size={12} />}
              {copied ? 'Copied' : 'Copy JSX'}
            </button>
          </div>
          <pre
            style={{
              margin: 0,
              padding: '10px 14px',
              borderRadius: 8,
              background: '#090d16',
              border: '1px solid #1e293b',
              color: '#38bdf8',
              fontSize: 12,
              fontFamily: 'monospace',
              overflowX: 'auto',
            }}
          >
            <code>{generatedJsx}</code>
          </pre>
        </div>
      </div>
    </div>
  );
}
