'use client';

import React, { useState, useEffect } from 'react';
import { Terminal, Copy, Check, Play, Edit3, FileCode, CheckCircle2, Sparkles, Loader2 } from 'lucide-react';

interface PulsarTemplate {
  id: string;
  name: string;
  description: string;
  outputFileName: string;
  settings?: { key: string; label: string; type: string; default: any }[];
}

interface PulsarResult {
  output: string;
  fileName: string;
  stats: { linesGenerated: number; tokensProcessed: number; duration: string };
}

const API_KEY = 'nexus_api_key_for_testing_min24chars';

export function PulsarPanel() {
  const [templates, setTemplates] = useState<PulsarTemplate[]>([]);
  const [selectedTemplate, setSelectedTemplate] = useState<string | null>(null);
  const [result, setResult] = useState<PulsarResult | null>(null);
  const [executing, setExecuting] = useState(false);
  const [rawTemplate, setRawTemplate] = useState('');
  const [showRawEditor, setShowRawEditor] = useState(false);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    fetch('/api/pulsar', { headers: { 'x-api-key': API_KEY } })
      .then(r => r.json())
      .then(d => { if (d.templates) setTemplates(d.templates); })
      .catch(console.error);
  }, []);

  async function executeTemplate(templateId: string) {
    setExecuting(true);
    setResult(null);
    try {
      const res = await fetch('/api/pulsar', {
        method: 'POST',
        headers: { 'x-api-key': API_KEY, 'Content-Type': 'application/json' },
        body: JSON.stringify({ templateId }),
      });
      const data = await res.json();
      if (data.success) {
        setResult({ output: data.output, fileName: data.fileName, stats: data.stats });
      }
    } catch (e) { console.error(e); }
    setExecuting(false);
  }

  async function executeRaw() {
    if (!rawTemplate.trim()) return;
    setExecuting(true);
    setResult(null);
    try {
      const res = await fetch('/api/pulsar', {
        method: 'POST',
        headers: { 'x-api-key': API_KEY, 'Content-Type': 'application/json' },
        body: JSON.stringify({ rawTemplate }),
      });
      const data = await res.json();
      if (data.success) {
        setResult({ output: data.output, fileName: data.fileName, stats: data.stats });
      }
    } catch (e) { console.error(e); }
    setExecuting(false);
  }

  function copyOutput() {
    if (result) {
      navigator.clipboard.writeText(result.output);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  }

  const templateIcons: Record<string, string> = {
    'scss-variables': '🎨', 'flutter-theme': '📱', 'android-xml': '🤖',
    'css-modules': '🧩', 'figma-tokens-json': '🔗', 'style-dictionary': '📖',
  };

  return (
    <div className="space-y-6">
      {/* Header Card */}
      <div className="nexus-card p-6 rounded-2xl border border-[#e2e8f0] bg-white flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-xs">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-amber-50 border border-amber-100 flex items-center justify-center text-amber-600 shadow-2xs">
            <Terminal className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-xl font-bold tracking-tight text-[#0f172a]">Pulsar Transformation Engine</h2>
              <span className="text-[11px] font-mono px-2 py-0.5 rounded-full bg-amber-50 text-amber-700 font-semibold border border-amber-100">
                AST Templating
              </span>
            </div>
            <p className="text-xs text-[#64748b] mt-0.5">
              Compile design tokens to any code target with custom Pulsar blueprint transformations
            </p>
          </div>
        </div>

        <button
          onClick={() => setShowRawEditor(!showRawEditor)}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold transition-all cursor-pointer shadow-2xs border ${
            showRawEditor
              ? 'bg-indigo-600 text-white border-indigo-600'
              : 'bg-white border-[#cbd5e1] text-[#0f172a] hover:bg-[#f8fafc]'
          }`}
        >
          {showRawEditor ? <Sparkles className="w-4 h-4" /> : <Edit3 className="w-4 h-4" />}
          <span>{showRawEditor ? 'Built-in Blueprints' : 'Custom Blueprint'}</span>
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 min-h-[580px]">
        {/* Left: Template Selector Sidebar */}
        <div className="lg:col-span-4 flex flex-col gap-4">
          {showRawEditor ? (
            <div className="nexus-card bg-white border border-[#e2e8f0] rounded-2xl p-5 flex-1 flex flex-col gap-4 shadow-xs">
              <div>
                <h3 className="text-sm font-bold text-[#0f172a]">Custom Pulsar Template</h3>
                <p className="text-xs text-[#64748b] mt-1">
                  Write Jinja2/Liquid-compatible token expressions with filters.
                </p>
              </div>

              <div className="p-3 rounded-xl bg-[#f8fafc] border border-[#e2e8f0] text-[11px] text-[#475569] space-y-1 font-mono">
                <div>Available variables:</div>
                <div className="text-indigo-600">{`{{ token.path }}`} · {`{{ token.rawValue }}`}</div>
                <div className="text-emerald-600">{`{% for token in tokens|filter("color") %}`}</div>
              </div>

              <textarea
                value={rawTemplate}
                onChange={e => setRawTemplate(e.target.value)}
                placeholder={'// Custom Export Blueprint\n{% for token in tokens|filter("color") %}\nexport const {{ token.path | camelCase }} = "{{ token.rawValue }}";\n{% endfor %}'}
                className="w-full flex-1 min-h-[240px] p-3 rounded-xl bg-slate-900 border border-slate-700 text-slate-100 font-mono text-xs focus:outline-none focus:border-indigo-400 resize-none"
              />

              <button
                onClick={executeRaw}
                disabled={executing || !rawTemplate.trim()}
                className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white font-semibold text-xs transition-all cursor-pointer shadow-xs"
              >
                {executing ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>Compiling Blueprint...</span>
                  </>
                ) : (
                  <>
                    <Play className="w-4 h-4" />
                    <span>Run Custom Blueprint</span>
                  </>
                )}
              </button>
            </div>
          ) : (
            <div className="nexus-card bg-white border border-[#e2e8f0] rounded-2xl p-4 flex-1 flex flex-col gap-2 shadow-xs">
              <div className="px-2 py-1 text-[11px] font-bold uppercase tracking-wider text-[#64748b]">
                Standard Exporters ({templates.length})
              </div>

              <div className="space-y-2 overflow-y-auto max-h-[580px] pr-1">
                {templates.map(t => {
                  const isSelected = selectedTemplate === t.id;
                  return (
                    <button
                      key={t.id}
                      onClick={() => { setSelectedTemplate(t.id); executeTemplate(t.id); }}
                      className={`w-full p-4 rounded-xl text-left transition-all border cursor-pointer flex flex-col gap-2 ${
                        isSelected
                          ? 'bg-indigo-50/80 border-indigo-200 shadow-2xs'
                          : 'bg-[#f8fafc] border-[#e2e8f0] hover:bg-white hover:border-[#cbd5e1]'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <span className="text-xl">{templateIcons[t.id] || '📄'}</span>
                        <div className="min-w-0 flex-1">
                          <div className={`text-xs font-bold truncate ${isSelected ? 'text-indigo-900' : 'text-[#0f172a]'}`}>
                            {t.name}
                          </div>
                          <div className="text-[11px] text-[#64748b] truncate mt-0.5">
                            {t.description}
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center justify-between pt-2 border-t border-[#e2e8f0]/60">
                        <span className="text-[10px] font-mono px-2 py-0.5 rounded-md bg-white border border-[#e2e8f0] text-[#475569]">
                          → {t.outputFileName}
                        </span>
                        {isSelected && executing && (
                          <span className="text-[10px] font-medium text-indigo-600 flex items-center gap-1">
                            <Loader2 className="w-3 h-3 animate-spin" /> Running
                          </span>
                        )}
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          )}
        </div>

        {/* Right: Compiled Output Terminal */}
        <div className="lg:col-span-8 flex flex-col">
          {result ? (
            <div className="nexus-card bg-white border border-[#e2e8f0] rounded-2xl p-5 flex-1 flex flex-col gap-4 shadow-xs">
              {/* Output Header */}
              <div className="flex items-center justify-between pb-4 border-b border-[#e2e8f0]">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-600 flex items-center justify-center">
                    <CheckCircle2 className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="text-sm font-bold text-[#0f172a] font-mono">{result.fileName}</div>
                    <div className="text-xs text-[#64748b]">
                      {result.stats.linesGenerated} lines generated · {result.stats.tokensProcessed} tokens processed in{' '}
                      <span className="font-semibold text-[#0f172a]">{result.stats.duration}</span>
                    </div>
                  </div>
                </div>

                <button
                  onClick={copyOutput}
                  className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl border border-[#cbd5e1] bg-[#f8fafc] hover:bg-[#f1f5f9] text-[#0f172a] text-xs font-semibold transition-all cursor-pointer shadow-2xs"
                >
                  {copied ? (
                    <>
                      <Check className="w-4 h-4 text-emerald-600" />
                      <span className="text-emerald-700">Copied!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-4 h-4 text-[#64748b]" />
                      <span>Copy Code</span>
                    </>
                  )}
                </button>
              </div>

              {/* Code Terminal Output */}
              <div className="flex-1 rounded-xl bg-[#0d1117] border border-slate-800 overflow-hidden flex flex-col min-h-[460px]">
                <div className="px-4 py-2.5 bg-slate-900/90 border-b border-slate-800 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full bg-rose-500/80" />
                    <div className="w-3 h-3 rounded-full bg-amber-500/80" />
                    <div className="w-3 h-3 rounded-full bg-emerald-500/80" />
                    <span className="ml-2 text-xs font-mono text-slate-400">{result.fileName}</span>
                  </div>
                  <span className="text-[10px] font-mono text-slate-500 uppercase">UTF-8 Output</span>
                </div>

                <div className="p-4 flex-1 overflow-auto">
                  <pre className="text-xs font-mono text-slate-200 leading-relaxed whitespace-pre font-normal">
                    {result.output}
                  </pre>
                </div>
              </div>
            </div>
          ) : (
            <div className="nexus-card bg-white border border-[#e2e8f0] rounded-2xl p-16 flex-1 flex flex-col items-center justify-center text-center shadow-xs">
              <div className="w-14 h-14 rounded-2xl bg-amber-50 border border-amber-100 flex items-center justify-center text-amber-600 mb-4">
                <FileCode className="w-7 h-7" />
              </div>
              <h3 className="text-base font-bold text-[#0f172a]">Ready to Compile Design Tokens</h3>
              <p className="text-xs text-[#64748b] max-w-sm mt-1">
                Select a template from the sidebar or write a custom blueprint to transform design tokens into production code.
              </p>
              {executing && (
                <div className="mt-4 flex items-center gap-2 text-xs font-semibold text-indigo-600">
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Executing AST pipeline...</span>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

