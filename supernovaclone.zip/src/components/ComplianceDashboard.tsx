'use client';

import React, { useState, useEffect } from 'react';
import {
  ShieldCheck, FileSpreadsheet, Download, RefreshCw, AlertCircle,
  CheckCircle2, Clock, Lock, Shield, Database, Activity, FileText
} from 'lucide-react';

interface ComplianceCheckItem {
  id: string;
  name: string;
  category: 'security' | 'tokens' | 'delivery' | 'governance';
  status: 'passed' | 'warning' | 'failed';
  score: number;
  description: string;
  recommendation?: string;
}

interface ComplianceData {
  overallScore: number;
  totalAuditEvents: number;
  recentEvents: Array<{
    id: string;
    action: string;
    resourceType: string;
    resourceId?: string | null;
    actorUserId?: string | null;
    ipAddress?: string | null;
    createdAt: string;
  }>;
  checklist: ComplianceCheckItem[];
}

export function ComplianceDashboard() {
  const [data, setData] = useState<ComplianceData | null>(null);
  const [loading, setLoading] = useState(true);

  const fetchReport = async () => {
    try {
      setLoading(true);
      const res = await fetch('/api/audit/compliance', {
        headers: { 'x-api-key': 'nexus_api_key_for_testing_min24chars' }
      });
      const json = await res.json();
      if (json.success) {
        setData(json);
      }
    } catch (e) {
      console.error('Failed to load compliance report', e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchReport();
  }, []);

  const downloadExport = (format: 'csv' | 'json') => {
    window.open(`/api/audit/compliance?format=${format}&key=nexus_api_key_for_testing_min24chars`, '_blank');
  };

  return (
    <div className="space-y-6 max-w-6xl mx-auto">
      {/* Header Card */}
      <div className="nexus-card p-6 rounded-2xl border border-[#e2e8f0]/90 bg-white flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-xs">
        <div className="flex items-center gap-3.5">
          <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200">
            <ShieldCheck className="w-6 h-6 text-emerald-600" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl font-bold text-[#0f172a] tracking-tight">Audit & Compliance Center</h1>
              <span className="px-2.5 py-0.5 rounded-full bg-emerald-50 text-emerald-700 text-[11px] font-semibold border border-emerald-200">
                SOC 2 Ready
              </span>
            </div>
            <p className="text-xs text-[#64748b] mt-0.5">
              Enterprise security posture, token governance metrics, and immutable audit logs.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={fetchReport}
            className="btn-secondary text-xs py-2 px-3.5 flex items-center gap-1.5"
          >
            <RefreshCw className={`w-3.5 h-3.5 text-[#64748b] ${loading ? 'animate-spin' : ''}`} />
            <span>Refresh</span>
          </button>
          <button
            onClick={() => downloadExport('csv')}
            className="btn-secondary text-xs py-2 px-3.5 flex items-center gap-1.5"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-600" />
            <span>Export CSV</span>
          </button>
          <button
            onClick={() => downloadExport('json')}
            className="btn-primary text-xs py-2 px-4 rounded-xl flex items-center gap-1.5 shadow-xs"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export JSON</span>
          </button>
        </div>
      </div>

      {/* Score Overview Cards */}
      {data && (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
          <div className="nexus-card p-5 rounded-2xl border border-[#e2e8f0] bg-white flex items-center justify-between shadow-xs">
            <div>
              <p className="text-xs font-bold uppercase tracking-wider text-[#64748b]">Compliance Score</p>
              <p className="text-3xl font-extrabold text-emerald-600 mt-1">{data.overallScore}%</p>
              <p className="text-xs text-[#64748b] mt-1 font-medium">Design Ops Standard</p>
            </div>
            <div className="w-14 h-14 rounded-full border-4 border-emerald-100 border-t-emerald-500 flex items-center justify-center font-bold text-sm text-emerald-700 bg-emerald-50">
              {data.overallScore}%
            </div>
          </div>

          <div className="nexus-card p-5 rounded-2xl border border-[#e2e8f0] bg-white shadow-xs">
            <p className="text-xs font-bold uppercase tracking-wider text-[#64748b]">Security Checks</p>
            <p className="text-3xl font-extrabold text-[#0f172a] mt-1">100%</p>
            <p className="text-xs text-emerald-700 mt-1 flex items-center gap-1 font-medium">
              <Lock className="w-3.5 h-3.5 text-emerald-600" /> API Keys & RBAC Passing
            </p>
          </div>

          <div className="nexus-card p-5 rounded-2xl border border-[#e2e8f0] bg-white shadow-xs">
            <p className="text-xs font-bold uppercase tracking-wider text-[#64748b]">Token Standards</p>
            <p className="text-3xl font-extrabold text-[#0f172a] mt-1">W3C DTCG</p>
            <p className="text-xs text-[#64748b] mt-1 flex items-center gap-1 font-medium">
              <Database className="w-3.5 h-3.5 text-indigo-500" /> Strict spec validation
            </p>
          </div>

          <div className="nexus-card p-5 rounded-2xl border border-[#e2e8f0] bg-white shadow-xs">
            <p className="text-xs font-bold uppercase tracking-wider text-[#64748b]">Audit Events Captured</p>
            <p className="text-3xl font-extrabold text-[#0f172a] mt-1">{data.totalAuditEvents}</p>
            <p className="text-xs text-[#64748b] mt-1 flex items-center gap-1 font-medium">
              <Activity className="w-3.5 h-3.5 text-cyan-500" /> Immutable log storage
            </p>
          </div>
        </div>
      )}

      {/* Compliance Checklist */}
      <div className="nexus-card rounded-2xl border border-[#e2e8f0] bg-white p-6 space-y-4 shadow-xs">
        <h2 className="text-sm font-bold text-[#0f172a] flex items-center gap-2">
          <Shield className="w-4 h-4 text-emerald-600" />
          Continuous Compliance Verification Checks
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {data?.checklist.map((item) => (
            <div key={item.id} className="p-4 rounded-xl border border-[#e2e8f0] bg-[#f8fafc] space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-bold text-xs text-[#0f172a]">{item.name}</span>
                <span className="flex items-center gap-1 text-xs font-semibold text-emerald-700 px-2.5 py-0.5 rounded-full bg-emerald-50 border border-emerald-200">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  {item.score}%
                </span>
              </div>
              <p className="text-xs text-[#475569] leading-relaxed">{item.description}</p>
              {item.recommendation && (
                <div className="flex items-center gap-1.5 text-xs text-amber-700 pt-1 font-medium">
                  <AlertCircle className="w-3.5 h-3.5 shrink-0 text-amber-600" />
                  <span>{item.recommendation}</span>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Audit Trail Log Table */}
      <div className="nexus-card rounded-2xl border border-[#e2e8f0] bg-white overflow-hidden shadow-xs">
        <div className="p-4 border-b border-[#e2e8f0] flex items-center justify-between bg-[#f8fafc]">
          <div className="flex items-center gap-2">
            <FileText className="w-4 h-4 text-[#64748b]" />
            <h3 className="font-bold text-xs uppercase tracking-wider text-[#0f172a]">Recent Immutable Audit Trail</h3>
          </div>
          <span className="text-xs text-[#64748b] font-medium">Persisted in PostgreSQL/PGlite</span>
        </div>

        {data && data.recentEvents.length > 0 ? (
          <div className="divide-y divide-[#e2e8f0] overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-[#f8fafc] text-[#64748b] uppercase text-[10px] tracking-wider border-b border-[#e2e8f0] font-bold">
                <tr>
                  <th className="px-4 py-3">Timestamp</th>
                  <th className="px-4 py-3">Action</th>
                  <th className="px-4 py-3">Resource Type</th>
                  <th className="px-4 py-3">Target ID</th>
                  <th className="px-4 py-3">Actor</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#e2e8f0] text-[#334155]">
                {data.recentEvents.map((ev) => (
                  <tr key={ev.id} className="hover:bg-[#f8fafc] transition-colors">
                    <td className="px-4 py-3 font-mono text-[#64748b]">
                      {new Date(ev.createdAt).toLocaleString()}
                    </td>
                    <td className="px-4 py-3">
                      <span className="px-2 py-0.5 rounded bg-[#f1f5f9] text-[#0f172a] border border-[#cbd5e1] font-mono font-semibold">
                        {ev.action}
                      </span>
                    </td>
                    <td className="px-4 py-3 font-mono font-medium text-[#0f172a]">{ev.resourceType}</td>
                    <td className="px-4 py-3 font-mono text-[#64748b]">{ev.resourceId || '—'}</td>
                    <td className="px-4 py-3 text-[#475569] font-medium">{ev.actorUserId || 'system'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="p-12 text-center text-xs text-[#94a3b8]">
            No audit events logged yet. Administrative actions and token mutations will automatically log here.
          </div>
        )}
      </div>
    </div>
  );
}
