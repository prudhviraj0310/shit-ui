'use client';

import React, { useState, useEffect, useRef } from 'react';
import {
  Search, X, Hash, Layers, BookOpen, Download, Tag,
  ArrowRight, CornerDownLeft
} from 'lucide-react';

interface SearchResult {
  id: string;
  title: string;
  subtitle?: string;
  category: 'token' | 'component' | 'doc' | 'exporter' | 'release';
  badge?: string;
  urlPath?: string;
}

interface UniversalSearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectResult: (urlPath: string) => void;
}

export function UniversalSearchModal({ isOpen, onClose, onSelectResult }: UniversalSearchModalProps) {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<SearchResult[]>([]);
  const [loading, setLoading] = useState(false);
  const [selectedIndex, setSelectedIndex] = useState(0);
  const [activeFilter, setActiveFilter] = useState<string>('all');
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen) {
      setTimeout(() => inputRef.current?.focus(), 50);
      performSearch('');
    } else {
      setQuery('');
      setSelectedIndex(0);
    }
  }, [isOpen]);

  const performSearch = async (q: string) => {
    try {
      setLoading(true);
      const res = await fetch(`/api/search?q=${encodeURIComponent(q)}&limit=30`, {
        headers: { 'x-api-key': 'nexus_api_key_for_testing_min24chars' }
      });
      const data = await res.json();
      if (data.success) {
        setResults(data.results);
        setSelectedIndex(0);
      }
    } catch (e) {
      console.error('Search error', e);
    } finally {
      setLoading(false);
    }
  };

  const handleQueryChange = (val: string) => {
    setQuery(val);
    performSearch(val);
  };

  const filteredResults = results.filter(r => {
    if (activeFilter === 'all') return true;
    return r.category === activeFilter;
  });

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      setSelectedIndex(prev => (prev + 1) % Math.max(1, filteredResults.length));
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setSelectedIndex(prev => (prev - 1 + filteredResults.length) % Math.max(1, filteredResults.length));
    } else if (e.key === 'Enter') {
      e.preventDefault();
      const item = filteredResults[selectedIndex];
      if (item && item.urlPath) {
        onSelectResult(item.urlPath);
        onClose();
      }
    } else if (e.key === 'Escape') {
      onClose();
    }
  };

  if (!isOpen) return null;

  const getCategoryIcon = (cat: string) => {
    switch (cat) {
      case 'token': return <Hash className="w-4 h-4 text-cyan-400" />;
      case 'component': return <Layers className="w-4 h-4 text-indigo-400" />;
      case 'doc': return <BookOpen className="w-4 h-4 text-emerald-400" />;
      case 'exporter': return <Download className="w-4 h-4 text-amber-400" />;
      case 'release': return <Tag className="w-4 h-4 text-purple-400" />;
      default: return <Search className="w-4 h-4 text-zinc-400" />;
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-20 p-4 bg-slate-900/40 backdrop-blur-xs">
      <div
        className="w-full max-w-2xl rounded-2xl border border-[#e2e8f0] bg-white shadow-2xl overflow-hidden flex flex-col max-h-[75vh] animate-in fade-in zoom-in-95 duration-150"
        onKeyDown={handleKeyDown}
      >
        {/* Search Input Bar */}
        <div className="relative flex items-center px-4 py-3.5 border-b border-[#e2e8f0] bg-white">
          <Search className="w-5 h-5 text-[#94a3b8] mr-3 shrink-0" />
          <input
            ref={inputRef}
            type="text"
            placeholder="Search tokens, components, docs, exporters, releases... (Esc to close)"
            value={query}
            onChange={(e) => handleQueryChange(e.target.value)}
            className="flex-1 bg-transparent text-[#0f172a] placeholder-[#94a3b8] text-sm focus:outline-none"
          />
          {query && (
            <button
              onClick={() => handleQueryChange('')}
              className="p-1 rounded-md text-[#94a3b8] hover:text-[#0f172a] cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          )}
          <span className="ml-2 px-1.5 py-0.5 rounded border border-[#cbd5e1] bg-[#f8fafc] text-[10px] text-[#64748b] font-mono shadow-xs">
            ESC
          </span>
        </div>

        {/* Filter Pills */}
        <div className="flex items-center gap-1.5 px-4 py-2 border-b border-[#e2e8f0] bg-[#f8fafc] text-xs overflow-x-auto">
          {['all', 'token', 'component', 'doc', 'exporter', 'release'].map(filter => (
            <button
              key={filter}
              onClick={() => setActiveFilter(filter)}
              className={`px-3 py-1 rounded-lg capitalize transition-all cursor-pointer ${
                activeFilter === filter
                  ? 'bg-white text-indigo-700 font-semibold border border-[#cbd5e1] shadow-2xs'
                  : 'text-[#64748b] hover:text-[#0f172a]'
              }`}
            >
              {filter === 'all' ? 'All Results' : `${filter}s`}
            </button>
          ))}
        </div>

        {/* Results List */}
        <div className="flex-1 overflow-y-auto p-2 divide-y divide-[#f1f5f9]">
          {loading ? (
            <div className="p-8 text-center text-sm text-[#64748b]">
              Searching system catalog...
            </div>
          ) : filteredResults.length > 0 ? (
            filteredResults.map((item, idx) => {
              const isSelected = idx === selectedIndex;
              return (
                <div
                  key={item.id}
                  onClick={() => {
                    if (item.urlPath) {
                      onSelectResult(item.urlPath);
                      onClose();
                    }
                  }}
                  onMouseEnter={() => setSelectedIndex(idx)}
                  className={`px-3.5 py-2.5 rounded-xl cursor-pointer flex items-center justify-between transition-colors ${
                    isSelected ? 'bg-indigo-50/70 border border-indigo-200' : 'hover:bg-[#f8fafc]'
                  }`}
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="p-2 rounded-lg bg-white border border-[#e2e8f0] shadow-2xs shrink-0">
                      {getCategoryIcon(item.category)}
                    </div>
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="font-semibold text-sm truncate text-[#0f172a]">{item.title}</span>
                        {item.badge && (
                          <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-[#f1f5f9] text-[#475569] border border-[#e2e8f0]">
                            {item.badge}
                          </span>
                        )}
                      </div>
                      {item.subtitle && (
                        <p className="text-xs text-[#64748b] truncate mt-0.5">{item.subtitle}</p>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center gap-2 pl-3 shrink-0">
                    {isSelected && (
                      <span className="flex items-center gap-1 text-[11px] text-indigo-600 font-mono font-semibold">
                        <span>Select</span>
                        <CornerDownLeft className="w-3 h-3" />
                      </span>
                    )}
                    <ArrowRight className="w-4 h-4 text-[#94a3b8]" />
                  </div>
                </div>
              );
            })
          ) : (
            <div className="p-8 text-center text-sm text-[#64748b]">
              No results found for &quot;{query}&quot;.
            </div>
          )}
        </div>

        {/* Footer shortcuts */}
        <div className="px-4 py-2.5 border-t border-[#e2e8f0] bg-[#f8fafc] flex items-center justify-between text-[11px] text-[#64748b]">
          <div className="flex items-center gap-3 font-mono">
            <span>↑↓ Navigate</span>
            <span>↵ Select</span>
            <span>Esc Close</span>
          </div>
          <span className="font-semibold text-[#0f172a]">Nexus Universal Search</span>
        </div>
      </div>
    </div>
  );
}
