import { describe, it, expect } from 'vitest';
import {
  parseStorybookIndex,
  extractComponentNameAndCategory,
} from '@/core/components/storybook';

describe('Storybook CSF3 Parser & Ingestion Engine', () => {
  it('extracts component name and category properly from hierarchical titles', () => {
    expect(extractComponentNameAndCategory('Components/Inputs/Button')).toEqual({
      componentName: 'Button',
      category: 'Inputs',
    });

    expect(extractComponentNameAndCategory('Design System/Button')).toEqual({
      componentName: 'Button',
      category: 'Design System',
    });

    expect(extractComponentNameAndCategory('Badge')).toEqual({
      componentName: 'Badge',
      category: 'General',
    });
  });

  it('parses Storybook v7/v8 CSF3 stories.json / index.json structure', async () => {
    const csf3Payload = JSON.stringify({
      v: 4,
      entries: {
        'components-button--primary': {
          id: 'components-button--primary',
          title: 'Components/Button',
          name: 'Primary',
          importPath: './src/components/Button.stories.tsx',
          type: 'story',
          tags: ['autodocs', 'story'],
          args: {
            variant: 'primary',
            size: 'medium',
            disabled: false,
            label: 'Click Here',
          },
          argTypes: {
            variant: { control: { type: 'select' }, options: ['primary', 'secondary'] },
          },
          parameters: {
            docs: { description: { story: 'Main action button' } },
          },
        },
        'components-button--secondary': {
          id: 'components-button--secondary',
          title: 'Components/Button',
          name: 'Secondary',
          type: 'story',
          args: {
            variant: 'secondary',
            size: 'medium',
          },
        },
        'components-card--elevated': {
          id: 'components-card--elevated',
          title: 'Layout/Card',
          name: 'Elevated Card',
          type: 'story',
          args: {
            elevation: 2,
          },
        },
      },
    });

    const parsed = await parseStorybookIndex(csf3Payload, 'https://storybook.example.com');

    expect(parsed.version).toBe(4);
    expect(parsed.totalStories).toBe(3);
    expect(parsed.totalComponents).toBe(2);

    const buttonGroup = parsed.components.find((c) => c.componentName === 'Button');
    expect(buttonGroup).toBeDefined();
    expect(buttonGroup?.stories).toHaveLength(2);
    expect(buttonGroup?.stories[0].iframeUrl).toBe(
      'https://storybook.example.com/iframe.html?id=components-button--primary&viewMode=story'
    );
    expect(buttonGroup?.stories[0].args?.variant).toBe('primary');

    const cardGroup = parsed.components.find((c) => c.componentName === 'Card');
    expect(cardGroup).toBeDefined();
    expect(cardGroup?.category).toBe('Layout');
  });

  it('filters out docs-only entries and retains only component stories', async () => {
    const payloadWithDocs = JSON.stringify({
      v: 4,
      entries: {
        'intro--docs': {
          id: 'intro--docs',
          title: 'Introduction',
          type: 'docs',
        },
        'components-badge--default': {
          id: 'components-badge--default',
          title: 'Components/Badge',
          name: 'Default',
          type: 'story',
        },
      },
    });

    const parsed = await parseStorybookIndex(payloadWithDocs);
    expect(parsed.totalStories).toBe(1);
    expect(parsed.stories[0].name).toBe('Default');
  });
});
