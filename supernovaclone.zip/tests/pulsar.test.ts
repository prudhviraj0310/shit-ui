import { describe, it, expect } from 'vitest';
import {
  PulsarEngine,
  getPulsarEngine,
  toCamelCase,
  toPascalCase,
  toKebabCase,
  toSnakeCase,
  toUpperSnakeCase,
  toTokenPath,
  BUILTIN_TEMPLATES,
} from '../src/core/pulsar/engine';
import { FlatToken } from '../src/core/tokens/types';

describe('Pulsar Custom Exporter Scripting Engine', () => {
  const sampleTokens: FlatToken[] = [
    {
      id: 'tok-1',
      name: 'primary',
      path: 'color.brand.primary',
      category: 'color',
      type: 'color',
      rawValue: '#3b82f6',
      resolvedValue: '#3b82f6',
      isAlias: false,
    },
    {
      id: 'tok-2',
      name: 'secondary',
      path: 'color.brand.secondary',
      category: 'color',
      type: 'color',
      rawValue: '#10b981',
      resolvedValue: '#10b981',
      isAlias: false,
    },
    {
      id: 'tok-3',
      name: 'md',
      path: 'spacing.scale.md',
      category: 'spacing',
      type: 'dimension',
      rawValue: '16px',
      resolvedValue: '16px',
      isAlias: false,
    },
    {
      id: 'tok-4',
      name: 'lg',
      path: 'spacing.scale.lg',
      category: 'spacing',
      type: 'dimension',
      rawValue: '24px',
      resolvedValue: '24px',
      isAlias: false,
    },
    {
      id: 'tok-5',
      name: 'h1',
      path: 'typography.heading.h1',
      category: 'typography',
      type: 'typography',
      rawValue: '32px',
      resolvedValue: '32px',
      isAlias: false,
    },
  ];

  describe('String Transformation Helpers', () => {
    it('correctly transforms to camelCase', () => {
      expect(toCamelCase('color.brand.primary')).toBe('colorBrandPrimary');
      expect(toCamelCase('spacing-scale-large')).toBe('spacingScaleLarge');
      expect(toCamelCase('my_custom_token')).toBe('myCustomToken');
    });

    it('correctly transforms to PascalCase', () => {
      expect(toPascalCase('color.brand.primary')).toBe('ColorBrandPrimary');
      expect(toPascalCase('button-primary-active')).toBe('ButtonPrimaryActive');
    });

    it('correctly transforms to kebab-case', () => {
      expect(toKebabCase('color.brandPrimary')).toBe('color-brand-primary');
      expect(toKebabCase('spacingScaleLarge')).toBe('spacing-scale-large');
    });

    it('correctly transforms to snake_case', () => {
      expect(toSnakeCase('color.brandPrimary')).toBe('color_brand_primary');
      expect(toSnakeCase('spacing-scale-lg')).toBe('spacing_scale_lg');
    });

    it('correctly transforms to UPPER_SNAKE_CASE', () => {
      expect(toUpperSnakeCase('color.brandPrimary')).toBe('COLOR_BRAND_PRIMARY');
      expect(toUpperSnakeCase('spacing.scale.md')).toBe('SPACING_SCALE_MD');
    });

    it('formats token path properly', () => {
      expect(toTokenPath('color/brand//primary')).toBe('color.brand.primary');
    });
  });

  describe('Template Execution and Filtering', () => {
    const engine = new PulsarEngine();

    it('executes simple token loop with filters via executeRaw', () => {
      const template = `// Colors
{% for token in tokens|filter("color") %}
$color-{{ token.path | kebabCase }}: {{ token.rawValue }};
{% endfor %}`;

      const result = engine.executeRaw(template, sampleTokens);
      expect(result.success).toBe(true);
      expect(result.output).toContain('$color-color-brand-primary: #3b82f6;');
      expect(result.output).toContain('$color-color-brand-secondary: #10b981;');
      expect(result.output).not.toContain('spacing');
      expect(result.stats.tokensProcessed).toBe(5);
    });

    it('executes conditional statements', () => {
      const template = `{% for token in tokens %}
{% if token.category == "spacing" %}
spacing: {{ token.path | camelCase }} = {{ token.rawValue }};
{% endif %}
{% endfor %}`;

      const result = engine.executeRaw(template, sampleTokens);
      expect(result.success).toBe(true);
      expect(result.output).toContain('spacingScaleMd');
      expect(result.output).toContain('16px');
      expect(result.output).toContain('spacingScaleLg');
      expect(result.output).toContain('24px');
    });

    it('supports built-in transform functions like stripUnit', () => {
      const template = `{% for token in tokens|filter("spacing") %}
{{ token.path | camelCase }}: {{ token.rawValue | stripUnit }};
{% endfor %}`;

      const result = engine.executeRaw(template, sampleTokens);
      expect(result.success).toBe(true);
      expect(result.output).toContain('16');
      expect(result.output).toContain('24');
    });
  });

  describe('Built-in Exporter Templates', () => {
    const engine = getPulsarEngine();

    it('verifies all built-in templates are registered', () => {
      const registered = engine.listTemplates();
      expect(registered.length).toBeGreaterThanOrEqual(6);
      const ids = registered.map((t) => t.id);
      expect(ids).toContain('scss-variables');
      expect(ids).toContain('flutter-theme');
      expect(ids).toContain('android-xml');
      expect(ids).toContain('css-modules');
      expect(ids).toContain('figma-tokens-json');
      expect(ids).toContain('style-dictionary');
    });

    it('executes SCSS Variables built-in template', () => {
      const result = engine.execute('scss-variables', sampleTokens);
      expect(result.success).toBe(true);
      expect(result.fileName).toBe('_tokens.scss');
      expect(result.output).toContain('$nexus-');
      expect(result.output).toContain('#3b82f6');
      expect(result.output).toContain('16px');
    });

    it('executes Flutter ThemeData built-in template', () => {
      const result = engine.execute('flutter-theme', sampleTokens);
      expect(result.success).toBe(true);
      expect(result.fileName).toBe('design_tokens.dart');
      expect(result.output).toContain('class AppTokens');
      expect(result.output).toContain('Color(0xFF');
    });

    it('executes Android XML built-in template', () => {
      const result = engine.execute('android-xml', sampleTokens);
      expect(result.success).toBe(true);
      expect(result.fileName).toBe('tokens.xml');
      expect(result.output).toContain('<resources>');
      expect(result.output).toContain('<color name=');
      expect(result.output).toContain('#3b82f6');
      expect(result.output).toContain('</resources>');
    });

    it('executes CSS Modules built-in template', () => {
      const result = engine.execute('css-modules', sampleTokens);
      expect(result.success).toBe(true);
      expect(result.fileName).toBe('tokens.module.css');
      expect(result.output).toContain(':root {');
      expect(result.output).toContain('#3b82f6');
    });

    it('executes Style Dictionary built-in template', () => {
      const result = engine.execute('style-dictionary', sampleTokens);
      expect(result.success).toBe(true);
      expect(result.fileName).toBe('tokens.style-dictionary.json');
      expect(result.output).toContain('"color.brand.primary"');
      expect(result.output).toContain('#3b82f6');
    });
  });
});
