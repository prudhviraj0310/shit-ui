import { describe, it, expect } from 'vitest';
import { resolveMultiTenantRouting, proxy } from '@/proxy';
import { NextRequest } from 'next/server';

describe('Multi-Tenant Custom Domain Routing & Edge Hosting', () => {
  it('detects *.designsystem.local custom tenant subdomains', () => {
    const req = new NextRequest('http://acme.designsystem.local/docs', {
      headers: { host: 'acme.designsystem.local' },
    });

    const info = resolveMultiTenantRouting(req);
    expect(info.subdomain).toBe('acme');
    expect(info.isCustomDomain).toBe(true);
    expect(info.tenantId).toBe('ds-acme');
  });

  it('detects custom headers x-custom-domain or x-design-system', () => {
    const req = new NextRequest('http://localhost:3000/docs', {
      headers: { 'x-custom-domain': 'uber-design' },
    });

    const info = resolveMultiTenantRouting(req);
    expect(info.subdomain).toBe('uber-design');
    expect(info.isCustomDomain).toBe(true);
  });

  it('detects sealed release documentation requests for edge CDN caching', () => {
    const sealedReq1 = new NextRequest('http://localhost:3000/docs?version=1.0.0');
    expect(resolveMultiTenantRouting(sealedReq1).isSealedRelease).toBe(true);

    const sealedReq2 = new NextRequest('http://localhost:3000/api/releases/rel-123');
    expect(resolveMultiTenantRouting(sealedReq2).isSealedRelease).toBe(true);

    const draftReq = new NextRequest('http://localhost:3000/docs?version=Draft');
    expect(resolveMultiTenantRouting(draftReq).isSealedRelease).toBe(false);
  });

  it('applies Cache-Control public, s-maxage=3600 edge caching headers to sealed releases', () => {
    const sealedReq = new NextRequest('http://localhost:3000/docs?version=1.0.0');
    const response = proxy(sealedReq);

    expect(response.headers.get('Cache-Control')).toBe(
      'public, s-maxage=3600, stale-while-revalidate=86400'
    );
  });

  it('enforces password protection when x-require-doc-password is set without credentials', () => {
    const protectedReq = new NextRequest('http://localhost:3000/docs/secret-page', {
      headers: {
        'x-require-doc-password': 'true',
      },
    });

    const response = proxy(protectedReq);
    expect(response.status).toBe(401);
  });
});
