import { describe, it, expect } from 'vitest';
import { validateDocBlocks, renderDocBlocksToHtml } from '@/core/docs/blocks';
import { DocBlock } from '@/core/docs/types';

describe('Notion-Grade Documentation Block Canvas Engine', () => {
  describe('validateDocBlocks', () => {
    it('validates DoDontBlock requiring doItem and dontItem', () => {
      const validBlock: DocBlock = {
        id: 'dd-1',
        type: 'do_dont',
        doItem: { text: 'Use semantic tokens' },
        dontItem: { text: 'Do not hardcode hex colors' },
      };

      const result = validateDocBlocks([validBlock]);
      expect(result.valid).toBe(true);
      expect(result.errors).toHaveLength(0);

      const invalidBlock: any = {
        id: 'dd-2',
        type: 'do_dont',
        doItem: { text: 'Only do item' },
      };
      const invalidResult = validateDocBlocks([invalidBlock]);
      expect(invalidResult.valid).toBe(false);
      expect(invalidResult.errors[0]).toContain("requires both 'doItem' and 'dontItem'");
    });

    it('validates InteractivePlaygroundBlock requiring componentName', () => {
      const validPlayground: DocBlock = {
        id: 'play-1',
        type: 'interactive_playground',
        componentName: 'Button',
      };
      expect(validateDocBlocks([validPlayground]).valid).toBe(true);

      const invalidPlayground: any = {
        id: 'play-2',
        type: 'interactive_playground',
      };
      expect(validateDocBlocks([invalidPlayground]).valid).toBe(false);
    });

    it('validates callout types including danger, warning, error, info, success', () => {
      const dangerCallout: DocBlock = {
        id: 'call-1',
        type: 'callout',
        calloutType: 'danger' as any,
        text: 'Critical breaking change ahead',
      };
      expect(validateDocBlocks([dangerCallout]).valid).toBe(true);
    });
  });

  describe('renderDocBlocksToHtml', () => {
    it('renders Do/Dont block with emerald and rose comparison cards', () => {
      const block: DocBlock = {
        id: 'dd-1',
        type: 'do_dont',
        title: 'Token Usage Rule',
        doItem: {
          title: 'Semantic Token',
          text: 'Use color.brand.primary',
          tokenValue: '#06b6d4',
        },
        dontItem: {
          title: 'Raw Hex',
          text: 'Do not use raw #000000',
          tokenValue: '#ff0055',
        },
      };

      const html = renderDocBlocksToHtml([block]);
      expect(html).toContain('doc-dodont-container');
      expect(html).toContain('doc-dodont-card doc-do');
      expect(html).toContain('doc-dodont-card doc-dont');
      expect(html).toContain('DO');
      expect(html).toContain("DON'T");
      expect(html).toContain('Token Usage Rule');
      expect(html).toContain('#06b6d4');
      expect(html).toContain('#ff0055');
    });

    it('renders InteractivePlayground block with dynamic prop controls markup', () => {
      const playground: DocBlock = {
        id: 'play-1',
        type: 'interactive_playground',
        componentName: 'Button',
        defaultProps: {
          variant: 'primary',
          size: 'medium',
          children: 'Submit Button',
        },
      };

      const html = renderDocBlocksToHtml([playground]);
      expect(html).toContain('doc-interactive-playground');
      expect(html).toContain('Interactive Playground: Button');
      expect(html).toContain('Submit Button');
      expect(html).toContain('Dynamic Prop Controls');
    });

    it('renders TokenTable block with embedded table and copy button', () => {
      const tableBlock: DocBlock = {
        id: 'tok-table-1',
        type: 'token_table',
        title: 'Core Colors',
      };

      const context = {
        tokens: [
          { path: 'color.brand.primary', resolvedValue: '#06b6d4', type: 'color' },
        ],
      };

      const html = renderDocBlocksToHtml([tableBlock], context);
      expect(html).toContain('doc-token-table-wrapper');
      expect(html).toContain('Core Colors');
      expect(html).toContain('color.brand.primary');
      expect(html).toContain('#06b6d4');
      expect(html).toContain('Copy');
    });

    it('renders AssetGrid block with searchable vector assets', () => {
      const assetBlock: DocBlock = {
        id: 'asset-1',
        type: 'asset_grid',
        category: 'icons',
      };

      const html = renderDocBlocksToHtml([assetBlock]);
      expect(html).toContain('doc-asset-grid-container');
      expect(html).toContain('doc-asset-search-input');
      expect(html).toContain('ArrowRight');
      expect(html).toContain('CheckCircle');
    });

    it('renders ContextMcp block matching Supernova AI agent gateway', () => {
      const mcpBlock: DocBlock = {
        id: 'mcp-1',
        type: 'context_mcp',
        title: 'Nexus AI Context Engine',
        description: 'Connect Cursor and Claude Code',
        mcpUrl: 'http://localhost:3000/api/mcp',
      };

      const html = renderDocBlocksToHtml([mcpBlock]);
      expect(html).toContain('doc-mcp-card');
      expect(html).toContain('Nexus AI Context Engine');
      expect(html).toContain('Live Agent Gateway');
      expect(html).toContain('http://localhost:3000/api/mcp');
    });

    it('renders ComponentHealthMatrix block for design-to-code parity', () => {
      const healthBlock: DocBlock = {
        id: 'health-1',
        type: 'component_health_matrix',
        title: 'Component Health & Parity Matrix',
      };

      const html = renderDocBlocksToHtml([healthBlock]);
      expect(html).toContain('doc-health-matrix');
      expect(html).toContain('Component Health &amp; Parity Matrix');
      expect(html).toContain('100% System Parity');
    });
  });
});
