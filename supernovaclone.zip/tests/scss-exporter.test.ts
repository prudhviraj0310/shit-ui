import { describe, it, expect } from 'vitest';
import { exportToScss, tokenPathToScssVar } from '../src/core/exporters/scss';
import { executeExporterWithManifest } from '../src/core/exporters/manifest';
import { FlatToken } from '../src/core/tokens/types';

describe('Supernova-Grade SCSS Exporter', () => {
  const sampleTokens: FlatToken[] = [
    {
      name: 'slate-900',
      path: 'color.primitive.slate.900',
      category: 'color',
      type: 'color',
      rawValue: '#0f172a',
      resolvedValue: '#0f172a',
      isAlias: false,
      isDeprecated: false,
      description: 'Primary dark background',
    },
    {
      name: 'text-primary',
      path: 'color.text.primary',
      category: 'color',
      type: 'color',
      rawValue: '{color.primitive.slate.900}',
      resolvedValue: '#0f172a',
      isAlias: true,
      aliasTarget: 'color.primitive.slate.900',
      isDeprecated: false,
      description: 'Main text color',
    },
    {
      name: 'spacing-md',
      path: 'spacing.md',
      category: 'spacing',
      type: 'dimension',
      rawValue: '16px',
      resolvedValue: '16px',
      isAlias: false,
      isDeprecated: false,
    },
    {
      name: 'heading-1',
      path: 'typography.heading.1',
      category: 'typography',
      type: 'typography',
      rawValue: {
        fontFamily: 'Inter',
        fontSize: '32px',
        fontWeight: '700',
        lineHeight: '1.25',
      },
      resolvedValue: {
        fontFamily: 'Inter',
        fontSize: '32px',
        fontWeight: '700',
        lineHeight: '1.25',
      },
      isAlias: false,
      isDeprecated: false,
    },
    {
      name: 'elevation-sm',
      path: 'shadow.elevation.sm',
      category: 'shadow',
      type: 'shadow',
      rawValue: '0 1px 2px 0 rgba(0, 0, 0, 0.05)',
      resolvedValue: '0 1px 2px 0 rgba(0, 0, 0, 0.05)',
      isAlias: false,
      isDeprecated: false,
    },
    {
      name: 'border-card',
      path: 'border.card',
      category: 'border',
      type: 'border',
      rawValue: '1px solid #e2e8f0',
      resolvedValue: '1px solid #e2e8f0',
      isAlias: false,
      isDeprecated: false,
    },
  ];

  it('converts token paths to SCSS variable names with prefix', () => {
    expect(tokenPathToScssVar('color.text.primary', 'nexus')).toBe('$nexus-color-text-primary');
    expect(tokenPathToScssVar('spacing.md')).toBe('$spacing-md');
  });

  it('exports SCSS variables with resolved alias references', () => {
    const file = exportToScss(sampleTokens, { prefix: 'nexus' });
    expect(file.filename).toBe('_tokens.scss');
    expect(file.format).toBe('scss');

    // Primitive value
    expect(file.content).toContain('$nexus-color-primitive-slate-900: #0f172a !default;');
    // Alias references target SCSS variable
    expect(file.content).toContain('$nexus-color-text-primary: $nexus-color-primitive-slate-900 !default;');
    expect(file.content).toContain('// Main text color');
  });

  it('generates SCSS mixins for typography, shadows, and borders', () => {
    const file = exportToScss(sampleTokens, { prefix: 'nexus', includeMixins: true });

    // Typography mixin
    expect(file.content).toContain('@mixin nexus-typography-heading-1 {');
    expect(file.content).toContain('font-family: Inter;');
    expect(file.content).toContain('font-size: 32px;');
    expect(file.content).toContain('font-weight: 700;');

    // Shadow mixin
    expect(file.content).toContain('@mixin nexus-shadow-elevation-sm {');
    expect(file.content).toContain('box-shadow: 0 1px 2px 0 rgba(0, 0, 0, 0.05);');

    // Border mixin
    expect(file.content).toContain('@mixin nexus-border-card {');
    expect(file.content).toContain('border: 1px solid #e2e8f0;');
  });

  it('generates Sass nested token map and token getter function', () => {
    const file = exportToScss(sampleTokens, { prefix: 'nexus', includeMaps: true, includeFunctions: true });

    expect(file.content).toContain('$nexus-tokens: (');
    expect(file.content).toContain('"color": (');
    expect(file.content).toContain('"typography": (');
    expect(file.content).toContain('@function nexus-token($keys...)');
  });

  it('integrates seamlessly with executeExporterWithManifest', () => {
    const result = executeExporterWithManifest('scss', sampleTokens, { prefix: 'acme' });
    expect(result.filename).toBe('_tokens.scss');
    expect(result.format).toBe('scss');
    expect(result.content).toContain('$acme-color-primitive-slate-900: #0f172a !default;');
  });
});
