import { describe, it, expect, vi } from 'vitest';
import {
  parseColorToFigmaRgba,
  parseDimensionToFloat,
  buildFigmaVariablePushPayload,
  pushVariablesToFigma,
} from '@/core/figma/push';
import { FlatToken } from '@/core/tokens/types';

describe('Bi-Directional Figma Variable Push Engine', () => {
  describe('Color & Dimension Transformers', () => {
    it('correctly converts hex colors to 0..1 Figma RGBA floats', () => {
      const hex6 = parseColorToFigmaRgba('#00ff00');
      expect(hex6.r).toBe(0);
      expect(hex6.g).toBe(1);
      expect(hex6.b).toBe(0);
      expect(hex6.a).toBe(1);

      const hex3 = parseColorToFigmaRgba('#fff');
      expect(hex3.r).toBe(1);
      expect(hex3.g).toBe(1);
      expect(hex3.b).toBe(1);

      const hex8 = parseColorToFigmaRgba('#00000080');
      expect(hex8.a).toBeCloseTo(0.5, 1);
    });

    it('correctly converts rgba string to Figma RGBA floats', () => {
      const rgba = parseColorToFigmaRgba('rgba(255, 128, 0, 0.5)');
      expect(rgba.r).toBe(1);
      expect(rgba.g).toBeCloseTo(0.5, 1);
      expect(rgba.b).toBe(0);
      expect(rgba.a).toBe(0.5);
    });

    it('converts px and rem dimensions to numeric floats', () => {
      expect(parseDimensionToFloat(24)).toBe(24);
      expect(parseDimensionToFloat('16px')).toBe(16);
      expect(parseDimensionToFloat('1.5rem')).toBe(24);
      expect(parseDimensionToFloat('2rem')).toBe(32);
    });
  });

  describe('buildFigmaVariablePushPayload', () => {
    const testTokens: FlatToken[] = [
      {
        id: 'tok-1',
        persistentId: 'pid-1',
        name: 'Brand Primary',
        path: 'color.brand.primary',
        category: 'color',
        type: 'color',
        rawValue: '#06b6d4',
        resolvedValue: '#06b6d4',
        isAlias: false,
        description: 'Primary cyan token',
      },
      {
        id: 'tok-2',
        persistentId: 'pid-2',
        name: 'Brand Accent',
        path: 'color.brand.accent',
        category: 'color',
        type: 'color',
        rawValue: '{color.brand.primary}',
        resolvedValue: '#06b6d4',
        isAlias: true,
        aliasTarget: 'color.brand.primary',
      },
      {
        id: 'tok-3',
        persistentId: 'pid-3',
        name: 'Spacing MD',
        path: 'spacing.md',
        category: 'spacing',
        type: 'dimension',
        rawValue: '16px',
        resolvedValue: '16px',
        isAlias: false,
      },
    ];


    it('builds valid CREATE actions for variables, modes, and collections', () => {
      const { payload, createdCount, updatedCount } = buildFigmaVariablePushPayload(
        testTokens,
        undefined,
        'Nexus Design OS'
      );

      expect(createdCount).toBe(3);
      expect(updatedCount).toBe(0);
      expect(payload.variableCollections).toBeDefined();
      expect(payload.variableCollections![0].name).toBe('Nexus Design OS');
      expect(payload.variables).toHaveLength(3);

      // Verify color variable
      const colorVar = payload.variables!.find((v) => v.name === 'color/brand/primary');
      expect(colorVar).toBeDefined();
      expect(colorVar!.resolvedType).toBe('COLOR');

      // Verify dimension variable
      const spacingVar = payload.variables!.find((v) => v.name === 'spacing/md');
      expect(spacingVar).toBeDefined();
      expect(spacingVar!.resolvedType).toBe('FLOAT');

      // Verify variable mode values
      expect(payload.variableModeValues).toHaveLength(3);
      const spacingVal = payload.variableModeValues!.find((mv) => mv.variableId === spacingVar!.id);
      expect(spacingVal?.value).toBe(16);

      // Verify alias mode value
      const accentVar = payload.variables!.find((v) => v.name === 'color/brand/accent');
      const accentVal = payload.variableModeValues!.find((mv) => mv.variableId === accentVar!.id);
      expect(accentVal?.value).toEqual({
        type: 'VARIABLE_ALIAS',
        id: colorVar!.id,
      });
    });

    it('differentiates CREATE and UPDATE when existing variables are passed', () => {
      const existingData = {
        variableCollections: {
          'col-123': {
            id: 'col-123',
            name: 'Nexus Design OS',
            modes: [{ modeId: 'm-default', name: 'Default' }],
            defaultModeId: 'm-default',
          },
        },
        variables: {
          'var-existing-1': {
            id: 'var-existing-1',
            name: 'color/brand/primary',
            resolvedType: 'COLOR',
          },
        },
      };

      const { payload, createdCount, updatedCount } = buildFigmaVariablePushPayload(
        testTokens,
        existingData,
        'Nexus Design OS'
      );

      expect(createdCount).toBe(2);
      expect(updatedCount).toBe(1);

      const primaryVar = payload.variables!.find((v) => v.name === 'color/brand/primary');
      expect(primaryVar?.action).toBe('UPDATE');
      expect(primaryVar?.id).toBe('var-existing-1');
    });
  });

  describe('pushVariablesToFigma dry run and execution', () => {
    it('executes dry run successfully without sending live network mutation', async () => {
      const tokens: FlatToken[] = [
        {
          id: 't1',
          persistentId: 'p1',
          name: 'Primary',
          path: 'color.primary',
          category: 'color',
          type: 'color',
          rawValue: '#ff0000',
          resolvedValue: '#ff0000',
          isAlias: false,
        },

      ];

      const result = await pushVariablesToFigma('test-file-key', tokens, 'test-secret', {
        dryRun: true,
      });

      expect(result.success).toBe(true);
      expect(result.dryRun).toBe(true);
      expect(result.pushedCount).toBe(1);
      expect(result.createdCount).toBe(1);
      expect(result.payload.variables).toHaveLength(1);
    });

    it('throws error when file key or tokens are missing', async () => {
      await expect(pushVariablesToFigma('', [], '')).rejects.toThrow('Figma file key is required.');
      await expect(pushVariablesToFigma('file-key', [], '')).rejects.toThrow('No tokens provided');
    });
  });
});
