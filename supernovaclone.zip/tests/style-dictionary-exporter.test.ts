import { describe, it, expect } from 'vitest';
import { exportToStyleDictionary, exportStyleDictionaryConfig, toStyleDictionaryAlias } from '../src/core/exporters/style-dictionary';
import { executeExporterWithManifest } from '../src/core/exporters/manifest';
import { FlatToken } from '../src/core/tokens/types';

describe('Supernova-Grade Style Dictionary Exporter', () => {
  const sampleTokens: FlatToken[] = [
    {
      name: 'blue-500',
      path: 'color.brand.blue.500',
      category: 'color',
      type: 'color',
      rawValue: '#3b82f6',
      resolvedValue: '#3b82f6',
      isAlias: false,
      isDeprecated: false,
      description: 'Brand blue',
    },
    {
      name: 'btn-bg',
      path: 'color.button.primary.bg',
      category: 'color',
      type: 'color',
      rawValue: '{color.brand.blue.500}',
      resolvedValue: '#3b82f6',
      isAlias: true,
      aliasTarget: 'color.brand.blue.500',
      isDeprecated: false,
    },
    {
      name: 'spacing-lg',
      path: 'spacing.scale.lg',
      category: 'spacing',
      type: 'dimension',
      rawValue: '24px',
      resolvedValue: '24px',
      isAlias: false,
      isDeprecated: false,
    },
  ];

  it('formats aliases according to Style Dictionary reference syntax', () => {
    expect(toStyleDictionaryAlias('color.brand.blue.500')).toBe('{color.brand.blue.500.value}');
    expect(toStyleDictionaryAlias('{color.brand.blue.500}')).toBe('{color.brand.blue.500.value}');
  });

  it('generates hierarchical Style Dictionary token JSON tree', () => {
    const file = exportToStyleDictionary(sampleTokens);
    expect(file.filename).toBe('tokens.style-dictionary.json');
    expect(file.format).toBe('json');

    const tree = JSON.parse(file.content);
    expect(tree.color.brand.blue['500'].value).toBe('#3b82f6');
    expect(tree.color.brand.blue['500'].type).toBe('color');
    expect(tree.color.brand.blue['500'].comment).toBe('Brand blue');

    // Style dictionary alias reference
    expect(tree.color.button.primary.bg.value).toBe('{color.brand.blue.500.value}');
    expect(tree.spacing.scale.lg.value).toBe('24px');
    expect(tree.spacing.scale.lg.type).toBe('dimension');
  });

  it('generates Style Dictionary config JSON with multiple build platforms', () => {
    const file = exportStyleDictionaryConfig();
    expect(file.filename).toBe('style-dictionary.config.json');

    const config = JSON.parse(file.content);
    expect(config.source).toContain('tokens.style-dictionary.json');
    expect(config.platforms.css).toBeDefined();
    expect(config.platforms.scss).toBeDefined();
    expect(config.platforms.javascript).toBeDefined();
    expect(config.platforms['ios-swift']).toBeDefined();
    expect(config.platforms.compose).toBeDefined();
  });

  it('executes via executeExporterWithManifest', () => {
    const file = executeExporterWithManifest('style-dictionary', sampleTokens);
    expect(file.filename).toBe('tokens.style-dictionary.json');
    const tree = JSON.parse(file.content);
    expect(tree.color.brand.blue['500'].value).toBe('#3b82f6');
  });
});
