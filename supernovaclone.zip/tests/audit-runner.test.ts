import { describe, it, expect, beforeEach } from 'vitest';
import { getDb, initializeSchema } from '../src/db/index';
import { seedDatabase } from '../src/db/seed';
import {
  workspaces,
  designSystems,
  tokens,
  themes,
  tokenOverrides,
} from '../src/db/schema';
import { eq, and } from 'drizzle-orm';
import { VersionManager } from '../src/core/versions/version-manager';
import { TokenBranchManager } from '../src/core/tokens/branching';
import { resolveTokenAliases } from '../src/core/tokens/resolver';
import { exportToCss as exportCss } from '../src/core/exporters/css';
import { exportToTailwind as exportTailwindTheme } from '../src/core/exporters/tailwind';
import { exportToTypeScript } from '../src/core/exporters/typescript';
import { exportToSwift as exportSwiftTokens } from '../src/core/exporters/swift';
import { exportToKotlin as exportKotlinTokens } from '../src/core/exporters/kotlin';
import { exportToJson as exportTokensDTCG } from '../src/core/exporters/json';

import { getPulsarEngine } from '../src/core/pulsar/engine';
import { parseDTCGTree } from '../src/core/tokens/parser';
import { existsSync, rmSync, mkdirSync } from 'node:fs';
import { join } from 'node:path';

describe('Auditor Independent Verification Suite (Phases 3, 4, 5, 6)', () => {
  let dbHelper: any;
  let db: any;

  beforeEach(async () => {
    dbHelper = await getDb(':memory:');
    db = dbHelper.db;
    await seedDatabase(dbHelper);
  });

  // =========================================================================
  // PHASE 3 — DATA INTEGRITY
  // =========================================================================
  describe('Phase 3: Data Integrity', () => {
    it('1. Repeated imports: idempotent upsert without duplicate key collision', async () => {
      const dtcgJson = {
        color: {
          brand: {
            primary: { $value: '#6366f1', $type: 'color' },
          },
        },
      };

      const parsedTokens = parseDTCGTree(dtcgJson);
      expect(parsedTokens.length).toBe(1);

      // First insert
      await db.insert(tokens).values({
        id: 'tok-test-idempotent',
        designSystemId: 'ds-nova-design',
        name: parsedTokens[0].name,
        path: parsedTokens[0].path,
        category: parsedTokens[0].category,
        type: parsedTokens[0].type,
        rawValue: parsedTokens[0].rawValue,
        resolvedValue: parsedTokens[0].resolvedValue,
      });

      // Second import: updating existing token path
      const existing = await db
        .select()
        .from(tokens)
        .where(and(eq(tokens.designSystemId, 'ds-nova-design'), eq(tokens.path, 'color.brand.primary')));
      expect(existing.length).toBeGreaterThanOrEqual(1);

      // Verify update doesn't throw or duplicate
      await db
        .update(tokens)
        .set({ rawValue: '#4f46e5', resolvedValue: '#4f46e5' })
        .where(eq(tokens.id, 'tok-test-idempotent'));

      const updated = await db.select().from(tokens).where(eq(tokens.id, 'tok-test-idempotent'));
      expect(updated[0].resolvedValue).toBe('#4f46e5');
    });

    it('2. Token renames: broken alias detection and missing reference handling', async () => {
      const { resolveTokenAliases } = await import('../src/core/tokens/resolver');
      const testTokens: any[] = [
        {
          id: '1',
          name: 'blue',
          path: 'color.base.blue',
          category: 'color',
          type: 'color',
          rawValue: '#0000ff',
          resolvedValue: '#0000ff',
          isAlias: false,
        },
        {
          id: '2',
          name: 'primary',
          path: 'color.brand.primary',
          category: 'color',
          type: 'color',
          rawValue: '{color.base.blue}',
          resolvedValue: '',
          isAlias: true,
          aliasTarget: 'color.base.blue',
        },
      ];

      // Resolve before rename
      const res1 = resolveTokenAliases(testTokens);
      expect(res1.tokens[1].resolvedValue).toBe('#0000ff');
      expect(res1.unresolvedAliases.length).toBe(0);

      // Rename base token path
      testTokens[0].path = 'color.base.renamedBlue';

      // Resolve after rename: alias target is now missing
      const res2 = resolveTokenAliases(testTokens);
      expect(res2.unresolvedAliases.some((a: any) => a.path === 'color.brand.primary')).toBe(true);
    });

    it('3. Alias dependencies: deep chains and circular dependency detection', async () => {
      const { resolveTokenAliases } = await import('../src/core/tokens/resolver');
      // 4-hop chain: d -> c -> b -> a -> #123456
      const chainTokens: any[] = [
        { id: '1', path: 'tok.a', rawValue: '#123456', resolvedValue: '#123456', type: 'color', category: 'color', isAlias: false },
        { id: '2', path: 'tok.b', rawValue: '{tok.a}', resolvedValue: '', type: 'color', category: 'color', isAlias: true, aliasTarget: 'tok.a' },
        { id: '3', path: 'tok.c', rawValue: '{tok.b}', resolvedValue: '', type: 'color', category: 'color', isAlias: true, aliasTarget: 'tok.b' },
        { id: '4', path: 'tok.d', rawValue: '{tok.c}', resolvedValue: '', type: 'color', category: 'color', isAlias: true, aliasTarget: 'tok.c' },
      ];

      const resolvedChain = resolveTokenAliases(chainTokens);
      const tokD = resolvedChain.tokens.find(t => t.path === 'tok.d');
      expect(tokD?.resolvedValue).toBe('#123456');

      // Circular chain: x -> y -> x
      const circularTokens: any[] = [
        { id: 'c1', path: 'loop.x', rawValue: '{loop.y}', resolvedValue: '', type: 'color', category: 'color', isAlias: true, aliasTarget: 'loop.y' },
        { id: 'c2', path: 'loop.y', rawValue: '{loop.x}', resolvedValue: '', type: 'color', category: 'color', isAlias: true, aliasTarget: 'loop.x' },
      ];

      const circularResult = resolveTokenAliases(circularTokens);
      expect(circularResult.cycles.length).toBeGreaterThan(0);
    });

    it('4. Theme and Brand isolation: modifying theme A does NOT alter theme B', async () => {
      // Create two themes
      await db.insert(themes).values([
        { id: 'thm-light', designSystemId: 'ds-nova-design', name: 'Light', codeName: 'light' },
        { id: 'thm-dark', designSystemId: 'ds-nova-design', name: 'Dark', codeName: 'dark' },
      ]);

      // Set override on thm-light
      await db.insert(tokenOverrides).values({
        id: 'ov-light',
        themeId: 'thm-light',
        tokenPath: 'color.background',
        rawValue: '#ffffff',
        resolvedValue: '#ffffff',
      });

      // Set override on thm-dark
      await db.insert(tokenOverrides).values({
        id: 'ov-dark',
        themeId: 'thm-dark',
        tokenPath: 'color.background',
        rawValue: '#000000',
        resolvedValue: '#000000',
      });

      // Modify thm-light
      await db.update(tokenOverrides).set({ resolvedValue: '#f8fafc' }).where(eq(tokenOverrides.id, 'ov-light'));

      // Verify thm-dark remains #000000
      const darkOverride = await db.select().from(tokenOverrides).where(eq(tokenOverrides.id, 'ov-dark'));
      expect(darkOverride[0].resolvedValue).toBe('#000000');
    });

    it('5. Failed branch merges: conflict detection aborts cleanly', async () => {
      const branchManager = new TokenBranchManager(db);
      const branch = await branchManager.createBranch(
        'ds-nova-design',
        'test-conflict-branch'
      );

      // Branch diff calculation
      const diff = await branchManager.diffBranches('ds-nova-design', 'Draft', 'test-conflict-branch');
      expect(diff).toHaveProperty('addedCount');
      expect(diff).toHaveProperty('modifiedCount');
      expect(diff).toHaveProperty('deletedCount');
      expect(diff.totalChanges).toBe(0);

      // Attempting to merge a non-existent branch throws cleanly
      await expect(branchManager.mergeBranch('ds-nova-design', 'non-existent-branch')).rejects.toThrow();
    });

    it('6. Release snapshot immutability: modifying draft does NOT mutate release snapshot', async () => {
      const vm = new VersionManager(db);
      const rel = await vm.releaseVersion({
        designSystemId: 'ds-nova-design',
        version: '1.5.0',
        title: 'Release 1.5.0 Snapshot',
      });

      // Find token in release snapshot
      const snapshotTokens = await db.select().from(tokens).where(eq(tokens.versionId, rel.version.id));
      const targetSnapshotToken = snapshotTokens[0];
      const originalValue = targetSnapshotToken.resolvedValue;

      // Now modify the draft token with same path
      await db
        .update(tokens)
        .set({ resolvedValue: '#999999' })
        .where(and(eq(tokens.designSystemId, 'ds-nova-design'), eq(tokens.path, targetSnapshotToken.path), eq(tokens.versionId, 'ver-draft-ds-nova-design')));

      // Verify release snapshot token remains completely unchanged
      const verifySnapshot = await db.select().from(tokens).where(eq(tokens.id, targetSnapshotToken.id));
      expect(verifySnapshot[0].resolvedValue).toBe(originalValue);
    });

    it('7. Application restart persistence: data survives database re-opening', async () => {
      const testDir = join(process.cwd(), '.data', 'test-persistence-db');
      if (existsSync(testDir)) rmSync(testDir, { recursive: true, force: true });
      mkdirSync(testDir, { recursive: true });

      try {
        // 1. Open first instance
        const client1 = new (await import('@electric-sql/pglite')).PGlite(testDir);
        const { drizzle } = await import('drizzle-orm/pglite');
        const db1 = drizzle(client1, { schema: await import('../src/db/schema') });
        await initializeSchema(client1);
        await db1.insert(workspaces).values({
          id: 'ws-persistence-test',
          name: 'Persistent Workspace',
          slug: 'pers-ws',
        });
        await client1.close();

        // 2. Re-open from same directory (simulated restart)
        const client2 = new (await import('@electric-sql/pglite')).PGlite(testDir);
        const db2 = drizzle(client2, { schema: await import('../src/db/schema') });
        const rows = await db2.select().from(workspaces).where(eq(workspaces.id, 'ws-persistence-test'));
        expect(rows.length).toBe(1);
        expect(rows[0].name).toBe('Persistent Workspace');
        await client2.close();
      } finally {
        if (existsSync(testDir)) rmSync(testDir, { recursive: true, force: true });
      }
    });

    it('8. Migration idempotency: running migrations twice does not fail or corrupt schema', async () => {
      // Run initializeSchema on already seeded database
      await expect(initializeSchema(dbHelper.client)).resolves.not.toThrow();
      const allDs = await db.select().from(designSystems);
      expect(allDs.length).toBeGreaterThan(0);
    });

    it('9. Transaction atomicity: failures do not leave dirty orphan records', async () => {
      let threw = false;
      try {
        await db.transaction(async (tx: any) => {
          await tx.insert(tokens).values({
            id: 'tok-orphan-test',
            designSystemId: 'ds-nova-design',
            name: 'orphan',
            path: 'orphan.test',
            category: 'color',
            type: 'color',
            rawValue: '#000',
            resolvedValue: '#000',
          });
          throw new Error('Simulated crash inside transaction');
        });
      } catch (err: any) {
        threw = true;
        expect(err.message).toContain('Simulated crash');
      }

      expect(threw).toBe(true);
      const orphanCheck = await db.select().from(tokens).where(eq(tokens.id, 'tok-orphan-test'));
      expect(orphanCheck.length).toBe(0);
    });
  });

  // =========================================================================
  // PHASE 4 — EXPORT CONFORMANCE
  // =========================================================================
  describe('Phase 4: Export Conformance', () => {
    const sampleTokens: any[] = [
      {
        name: 'primary',
        path: 'color.brand.primary',
        category: 'color',
        type: 'color',
        rawValue: '#6366f1',
        resolvedValue: '#6366f1',
      },
      {
        name: 'sm',
        path: 'spacing.sm',
        category: 'spacing',
        type: 'dimension',
        rawValue: '8px',
        resolvedValue: '8px',
      },
      {
        name: 'base',
        path: 'typography.body',
        category: 'typography',
        type: 'typography',
        isComposite: true,
        rawValue: { fontFamily: 'Inter', fontSize: '16px', lineHeight: '24px' },
        resolvedValue: { fontFamily: 'Inter', fontSize: '16px', lineHeight: '24px' },
      },
    ];

    it('generates valid CSS custom properties', async () => {
      const { exportToCss } = await import('../src/core/exporters/css');
      const res = exportToCss(sampleTokens);
      expect(res.content).toContain(':root {');
      expect(res.content).toContain('--color-brand-primary: #6366f1;');
      expect(res.content).toContain('--spacing-sm: 8px;');
    });

    it('generates valid Tailwind v4 @theme CSS block', async () => {
      const { exportToTailwindV4 } = await import('../src/core/exporters/tailwind');
      const res = exportToTailwindV4(sampleTokens);
      expect(res.content).toContain('@theme {');
      expect(res.content).toContain('--color-brand-primary: var(--nexus-color-brand-primary);');
    });

    it('generates valid TypeScript typed tokens', async () => {
      const { exportToTypeScript } = await import('../src/core/exporters/typescript');
      const res = exportToTypeScript(sampleTokens);
      expect(res.content).toContain('export const tokens =');
      expect(res.content).toContain('as const;');
      expect(res.content).toContain('export type DesignTokens = typeof tokens;');
    });

    it('generates Swift struct output for iOS', async () => {
      const { exportToSwift } = await import('../src/core/exporters/swift');
      const res = exportToSwift(sampleTokens);
      expect(res.content).toContain('import SwiftUI');
      expect(res.content).toContain('public struct NovaTokens');
      expect(res.content).toContain('Color');
    });

    it('generates Kotlin object output for Android Jetpack Compose', async () => {
      const { exportToKotlin } = await import('../src/core/exporters/kotlin');
      const res = exportToKotlin(sampleTokens);
      expect(res.content).toContain('package com.novadesign.tokens');
      expect(res.content).toContain('object NovaColors');
      expect(res.content).toContain('val BrandPrimary = Color(0xFF6366F1L)');
    });

    it('exports DTCG compliant JSON specification', async () => {
      const { exportToJson } = await import('../src/core/exporters/json');
      const res = exportToJson(sampleTokens);
      const parsed = JSON.parse(res.content);
      expect(parsed).toHaveProperty('color');
      expect(parsed.color.brand.primary).toHaveProperty('$value', '#6366f1');
      expect(parsed.color.brand.primary).toHaveProperty('$type', 'color');
    });

    it('evaluates custom Pulsar template execution', () => {
      const engine = getPulsarEngine();
      const template = '// Generated Tokens\n{% for token in tokens|filter("color") %}${{ token.path | kebabCase }}: {{ token.resolvedValue }};\n{% endfor %}';
      const result = engine.executeRaw(template, sampleTokens);
      expect(result.success).toBe(true);
      expect(result.output).toContain('$color-brand-primary: #6366f1;');
    });

    it('handles empty token array gracefully without throwing', async () => {
      const { exportToCss } = await import('../src/core/exporters/css');
      const { exportToTailwindV4 } = await import('../src/core/exporters/tailwind');
      const { exportToTypeScript } = await import('../src/core/exporters/typescript');
      const { exportToSwift } = await import('../src/core/exporters/swift');
      const { exportToKotlin } = await import('../src/core/exporters/kotlin');

      expect(() => exportToCss([])).not.toThrow();
      expect(() => exportToTailwindV4([])).not.toThrow();
      expect(() => exportToTypeScript([])).not.toThrow();
      expect(() => exportToSwift([])).not.toThrow();
      expect(() => exportToKotlin([])).not.toThrow();
    });
  });

  // =========================================================================
  // PHASE 6 — RELEASE AND RECOVERY
  // =========================================================================
  describe('Phase 6: Release and Recovery', () => {
    it('creates 2 sequential releases, modifies draft, and verifies rollback completeness', async () => {
      const vm = new VersionManager(db);

      // Release 1.0.0
      const rel1 = await vm.releaseVersion({
        designSystemId: 'ds-nova-design',
        version: '1.0.0',
        title: 'Release 1.0.0',
      });
      expect(rel1.version.name).toBe('1.0.0');

      // Modify draft token
      await db
        .update(tokens)
        .set({ resolvedValue: '#111111' })
        .where(and(eq(tokens.designSystemId, 'ds-nova-design'), eq(tokens.path, 'color.brand.primary'), eq(tokens.versionId, 'ver-draft-ds-nova-design')));

      // Release 2.0.0
      const rel2 = await vm.releaseVersion({
        designSystemId: 'ds-nova-design',
        version: '2.0.0',
        title: 'Release 2.0.0',
      });
      expect(rel2.version.name).toBe('2.0.0');

      // Verify release 1.0.0 snapshot still has the original seeded value (#3b82f6)
      const r1Tokens = await db.select().from(tokens).where(and(eq(tokens.versionId, rel1.version.id), eq(tokens.path, 'color.brand.primary')));
      expect(r1Tokens[0].resolvedValue).toBe('#3b82f6');

      // Modify draft to something dirty
      await db
        .update(tokens)
        .set({ resolvedValue: '#dirty99' })
        .where(and(eq(tokens.designSystemId, 'ds-nova-design'), eq(tokens.path, 'color.brand.primary'), eq(tokens.versionId, 'ver-draft-ds-nova-design')));

      // Rollback to Release 1.0.0
      const rollback = await vm.rollbackToVersion('ds-nova-design', '1.0.0');
      expect(rollback.restoredFrom.name).toBe('1.0.0');

      // Verify draft tokens now match Release 1.0.0 exactly (#3b82f6)
      const restoredDraft = await db
        .select()
        .from(tokens)
        .where(and(eq(tokens.designSystemId, 'ds-nova-design'), eq(tokens.path, 'color.brand.primary'), eq(tokens.versionId, 'ver-draft-ds-nova-design')));
      expect(restoredDraft[0].resolvedValue).toBe('#3b82f6');
    });
  });
});
