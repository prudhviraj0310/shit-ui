import { describe, it, expect } from 'vitest';
import { GET as getProviders } from '@/app/api/auth/providers/route';
import { GET as getCsrf } from '@/app/api/auth/csrf/route';
import { GET as getOauthConfig } from '@/app/api/auth/oauth/config/route';
import { inferCategory, inferType } from '@/core/tokens/parser';
import { validateDocBlocks, renderDocBlocksToHtml } from '@/core/docs/blocks';
import { DocBlock } from '@/core/docs/types';
import fs from 'fs';
import path from 'path';

describe('Supernova REA Evidence & Architectural Parity Verification', () => {
  describe('Cognito PKCE & NextAuth Identity Endpoints (Sections 5.1 & 5.2)', () => {
    it('serves SupernovaAuth provider metadata matching REA wire capture', async () => {
      const res = await getProviders();
      expect(res.status).toBe(200);

      const json = await res.json();
      expect(json.supernovaauth).toBeDefined();
      expect(json.supernovaauth.id).toBe('supernovaauth');
      expect(json.supernovaauth.name).toBe('Supernova Auth');
      expect(json.supernovaauth.type).toBe('oauth');
      expect(json.supernovaauth.signinUrl).toContain('/api/auth/signin/supernovaauth');
      expect(json.supernovaauth.callbackUrl).toContain('/api/auth/callback/supernovaauth');
      expect(json.google).toBeDefined();
      expect(json.saml).toBeDefined();
    });

    it('generates secure CSRF token with encrypted cookie for auth handshake', async () => {
      const res = await getCsrf();
      expect(res.status).toBe(200);

      const json = await res.json();
      expect(json.csrfToken).toBeDefined();
      expect(typeof json.csrfToken).toBe('string');
      expect(json.csrfToken.length).toBe(64); // 32 bytes hex
    });

    it('exposes Cognito OAuth PKCE discovery configuration matching live app capture', async () => {
      const res = await getOauthConfig();
      expect(res.status).toBe(200);

      const json = await res.json();
      expect(json.clientId).toBe('7n7icqdn6k338k14u2hm19ca99');
      expect(json.userPoolPasswordClientId).toBe('10gekqg01kcq7ct83rbd5lrutq');
      expect(json.challengeMethod).toBe('S256');
      expect(json.responseType).toBe('code');
      expect(json.redirectUri).toBe('/api/auth/callback/supernovaauth');
    });
  });

  describe('11 Core Token Types AST Compatibility (Section 6.1)', () => {
    it('infers blur, radius, font, and text token categories correctly', () => {
      expect(inferCategory('blur.background.modal', 'blur')).toBe('blur');
      expect(inferCategory('radius.card.base', 'radius')).toBe('borderRadius');
      expect(inferCategory('font.body.semibold', 'font')).toBe('typography');
      expect(inferCategory('text.button.submit', 'text')).toBe('typography');
      expect(inferCategory('measure.spacing.xs', 'measure')).toBe('sizing');
    });

    it('infers blur token types for structured blur objects', () => {
      const blurType = inferType({ radius: { value: 20, unit: 'px' }, type: 'background' }, 'blur');
      expect(blurType).toBe('blur');
    });
  });

  describe('Living Documentation AST Extensions (Section 7)', () => {
    it('validates PromptTemplate, PropsTable, StorybookEmbed, and VersionDiff blocks', () => {
      const promptBlock: DocBlock = {
        id: 'pt-1',
        type: 'prompt_template',
        title: 'Generate UI Component',
        prompt: 'Generate a button adhering to tokens {{color.brand.primary}}',
      };

      const propsBlock: DocBlock = {
        id: 'props-1',
        type: 'props_table',
        componentName: 'Badge',
        props: [
          { name: 'variant', type: "'success' | 'warning'", required: true, description: 'Visual style' },
          { name: 'children', type: 'ReactNode', required: true, description: 'Label content' },
        ],
      };

      const storybookBlock: DocBlock = {
        id: 'sb-1',
        type: 'storybook_embed',
        url: 'https://storybook.example.com/iframe.html?id=badge--primary',
      };

      const diffBlock: DocBlock = {
        id: 'diff-1',
        type: 'version_diff',
        changes: [
          { path: 'color.brand.primary', changeType: 'changed', oldValue: '#1d4ed8', newValue: '#2b70f7' },
        ],
      };

      const result = validateDocBlocks([promptBlock, propsBlock, storybookBlock, diffBlock]);
      expect(result.valid).toBe(true);
      expect(result.errors).toHaveLength(0);
    });

    it('renders PromptTemplate, PropsTable, StorybookEmbed, and VersionDiff to HTML', () => {
      const blocks: DocBlock[] = [
        {
          id: 'pt-1',
          type: 'prompt_template',
          title: 'AI Code Generator',
          prompt: 'Write CSS adhering to tokens',
        },
        {
          id: 'props-1',
          type: 'props_table',
          componentName: 'Modal',
          props: [
            { name: 'isOpen', type: 'boolean', required: true, description: 'Visibility toggle' },
          ],
        },
        {
          id: 'sb-1',
          type: 'storybook_embed',
          url: 'https://storybook.example.com/iframe.html',
          title: 'Modal Default',
        },
        {
          id: 'diff-1',
          type: 'version_diff',
          fromVersion: 'v1.0.0',
          toVersion: 'v2.0.0',
          changes: [
            { path: 'color.primary', changeType: 'added', newValue: '#2b70f7' },
          ],
        },
      ];

      const html = renderDocBlocksToHtml(blocks);
      expect(html).toContain('doc-prompt-template-card');
      expect(html).toContain('AI Code Generator');
      expect(html).toContain('doc-props-table-card');
      expect(html).toContain('Modal API Props');
      expect(html).toContain('isOpen');
      expect(html).toContain('doc-storybook-embed');
      expect(html).toContain('Modal Default');
      expect(html).toContain('doc-version-diff');
      expect(html).toContain('color.primary');
    });
  });

  describe('Dark Matter Design System Tokens (Section 5.3)', () => {
    it('verifies Dark Matter CSS custom property rules exist in globals.css', () => {
      const cssPath = path.join(process.cwd(), 'src/app/globals.css');
      const cssContent = fs.readFileSync(cssPath, 'utf-8');

      expect(cssContent).toContain('[data-dm-theme="darkmatter"]');
      expect(cssContent).toContain('--dm-color-primary-500: #2b70f7');
      expect(cssContent).toContain('--dm-color-background-canvas: #0e1117');
      expect(cssContent).toContain('--dm-color-surface-elevated: #161b22');
      expect(cssContent).toContain('--dm-border-radius-base: 6px');
      expect(cssContent).toContain('--dm-shadow-elevation-1: 0 1px 3px rgba(0, 0, 0, 0.24)');
    });
  });
});
