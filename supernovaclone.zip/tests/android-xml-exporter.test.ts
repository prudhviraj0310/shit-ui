import { describe, it, expect } from 'vitest';
import { exportToAndroidXml } from '../src/core/exporters/android-xml';
import { executeExporterWithManifest } from '../src/core/exporters/manifest';
import { FlatToken } from '../src/core/tokens/types';

describe('Supernova-Grade Android XML Exporter', () => {
  const sampleTokens: FlatToken[] = [
    {
      name: 'primary',
      path: 'color.brand.primary',
      category: 'color',
      type: 'color',
      rawValue: '#3B82F6',
      resolvedValue: '#3B82F6',
      isAlias: false,
      isDeprecated: false,
    },
    {
      name: 'primary-alias',
      path: 'color.interactive.primary',
      category: 'color',
      type: 'color',
      rawValue: '{color.brand.primary}',
      resolvedValue: '#3B82F6',
      isAlias: true,
      aliasTarget: 'color.brand.primary',
      isDeprecated: false,
    },
    {
      name: 'spacing-md',
      path: 'spacing.md',
      category: 'spacing',
      type: 'dimension',
      rawValue: '16px',
      resolvedValue: '16px',
      isAlias: false,
      isDeprecated: false,
    },
    {
      name: 'headline',
      path: 'typography.headline',
      category: 'typography',
      type: 'typography',
      rawValue: {
        fontFamily: 'Roboto',
        fontSize: '24sp',
        fontWeight: 'bold',
      },
      resolvedValue: {
        fontFamily: 'Roboto',
        fontSize: '24sp',
        fontWeight: 'bold',
      },
      isAlias: false,
      isDeprecated: false,
    },
  ];

  it('generates standard Android XML resource structure', () => {
    const file = exportToAndroidXml(sampleTokens, { prefix: 'nexus' });
    expect(file.filename).toBe('tokens.xml');
    expect(file.format).toBe('xml');

    expect(file.content).toContain('<?xml version="1.0" encoding="utf-8"?>');
    expect(file.content).toContain('<resources>');
    expect(file.content).toContain('<color name="nexus_color_brand_primary">#3B82F6</color>');
    expect(file.content).toContain('<color name="nexus_color_interactive_primary">@color/nexus_color_brand_primary</color>');
    expect(file.content).toContain('<dimen name="nexus_spacing_md">16dp</dimen>');
    expect(file.content).toContain('<style name="TextAppearance.Nova.TypographyHeadline">');
    expect(file.content).toContain('<item name="android:textSize">24sp</item>');
    expect(file.content).toContain('<item name="android:fontFamily">Roboto</item>');
    expect(file.content).toContain('<item name="android:textStyle">bold</item>');
    expect(file.content).toContain('</resources>');
  });

  it('executes via executeExporterWithManifest', () => {
    const file = executeExporterWithManifest('android-xml', sampleTokens, { prefix: 'sys' });
    expect(file.filename).toBe('tokens.xml');
    expect(file.content).toContain('<color name="sys_color_brand_primary">#3B82F6</color>');
  });
});
