import { describe, it, expect } from 'vitest';
import { exportToFlutter } from '../src/core/exporters/flutter';
import { executeExporterWithManifest } from '../src/core/exporters/manifest';
import { FlatToken } from '../src/core/tokens/types';

describe('Supernova-Grade Flutter / Dart Exporter', () => {
  const sampleTokens: FlatToken[] = [
    {
      name: 'primary',
      path: 'color.brand.primary',
      category: 'color',
      type: 'color',
      rawValue: '#3B82F6',
      resolvedValue: '#3B82F6',
      isAlias: false,
      isDeprecated: false,
      description: 'Primary brand color',
    },
    {
      name: 'primary-hover',
      path: 'color.brand.primary.hover',
      category: 'color',
      type: 'color',
      rawValue: '{color.brand.primary}',
      resolvedValue: '#3B82F6',
      isAlias: true,
      aliasTarget: 'color.brand.primary',
      isDeprecated: false,
    },
    {
      name: 'spacing-sm',
      path: 'spacing.sm',
      category: 'spacing',
      type: 'dimension',
      rawValue: '8px',
      resolvedValue: '8px',
      isAlias: false,
      isDeprecated: false,
    },
    {
      name: 'radius-md',
      path: 'radius.md',
      category: 'borderRadius',
      type: 'dimension',
      rawValue: '12px',
      resolvedValue: '12px',
      isAlias: false,
      isDeprecated: false,
    },
    {
      name: 'display',
      path: 'typography.display',
      category: 'typography',
      type: 'typography',
      rawValue: {
        fontFamily: 'Inter',
        fontSize: '28px',
        fontWeight: '700',
        lineHeight: '34px',
      },
      resolvedValue: {
        fontFamily: 'Inter',
        fontSize: '28px',
        fontWeight: '700',
        lineHeight: '34px',
      },
      isAlias: false,
      isDeprecated: false,
    },
  ];

  it('exports Flutter Dart classes with AppColors, AppSpacing, and AppTypography', () => {
    const file = exportToFlutter(sampleTokens, { classNamePrefix: 'Nova' });
    expect(file.filename).toBe('design_tokens.dart');
    expect(file.format).toBe('dart');

    // Flutter colors
    expect(file.content).toContain('class NovaColors {');
    expect(file.content).toContain('static const Color colorBrandPrimary = Color(0xFF3B82F6);');
    // Flutter Spacing
    expect(file.content).toContain('class NovaSpacing {');
    expect(file.content).toContain('static const double spacingSm = 8.0;');
    // Flutter Radii
    expect(file.content).toContain('class NovaRadii {');
    expect(file.content).toContain('static const BorderRadius radiusMd = BorderRadius.all(Radius.circular(12.0));');
    // Flutter Typography
    expect(file.content).toContain('class NovaTypography {');
    expect(file.content).toContain('fontFamily: \'Inter\',');
    expect(file.content).toContain('fontSize: 28.0,');
    expect(file.content).toContain('fontWeight: FontWeight.w700,');
    // Flutter ThemeData
    expect(file.content).toContain('class NovaTheme {');
    expect(file.content).toContain('static ThemeData get lightTheme');
  });

  it('executes via executeExporterWithManifest', () => {
    const file = executeExporterWithManifest('flutter', sampleTokens, { classNamePrefix: 'Super' });
    expect(file.filename).toBe('design_tokens.dart');
    expect(file.content).toContain('class SuperColors');
  });
});
