import { describe, it, expect, beforeEach } from 'vitest';
import { AnalyticsEngine } from '../src/core/analytics/engine';
import { CollabRoom, transformOperation, EditOperation } from '../src/core/collaboration/realtime';
import { HandoffGenerator } from '../src/core/handoff/generator';
import { DocEngine, createBlock, SLASH_COMMANDS } from '../src/core/docs/editor';
import { OAuthProvider, PROVIDER_METADATA } from '../src/core/auth/sso';
import { FlatToken } from '../src/core/tokens/types';

describe('Advanced Enterprise Capabilities', () => {
  const sampleTokens: FlatToken[] = [
    {
      id: 'tok-1',
      name: 'primary',
      path: 'color.brand.primary',
      category: 'color',
      type: 'color',
      rawValue: '#2563eb',
      resolvedValue: '#2563eb',
      isAlias: false,
    },
    {
      id: 'tok-2',
      name: 'lg',
      path: 'spacing.layout.lg',
      category: 'spacing',
      type: 'dimension',
      rawValue: '24px',
      resolvedValue: '24px',
      isAlias: false,
    },
  ];

  describe('1. Analytics & Token Adoption Engine', () => {
    let analytics: AnalyticsEngine;

    beforeEach(() => {
      analytics = new AnalyticsEngine();
    });

    it('tracks events and computes adoption metrics', () => {
      analytics.track('token_created', {
        workspaceId: 'ws-1',
        designSystemId: 'ds-1',
        userId: 'user-alice',
        metadata: { category: 'color' },
      });
      analytics.track('token_created', {
        workspaceId: 'ws-1',
        designSystemId: 'ds-1',
        userId: 'user-bob',
        metadata: { category: 'spacing' },
      });
      analytics.track('export_generated', {
        workspaceId: 'ws-1',
        designSystemId: 'ds-1',
        userId: 'user-alice',
        metadata: { format: 'css' },
      });
      analytics.track('compliance_check', {
        workspaceId: 'ws-1',
        designSystemId: 'ds-1',
        metadata: { score: 92 },
      });

      const metrics = analytics.getAdoptionMetrics('ws-1', 'ds-1');
      expect(metrics.totalExports).toBe(1);
      expect(metrics.exportsByFormat['css']).toBe(1);
      expect(metrics.complianceScore).toBe(92);
      expect(metrics.activeUsers).toBe(2);
      expect(metrics.adoptionRate).toBeGreaterThan(0);
    });

    it('generates dashboard dataset with time series via getDashboard', () => {
      analytics.track('token_created', {
        workspaceId: 'ws-1',
        designSystemId: 'ds-1',
        userId: 'user-alice',
        metadata: { category: 'color' },
      });

      const dashboard = analytics.getDashboard('ws-1', 'ds-1');
      expect(dashboard).toBeDefined();
      expect(dashboard.adoption).toBeDefined();
      expect(dashboard.tokenGrowth.length).toBeGreaterThan(0);
      expect(dashboard.recentActivity.length).toBeGreaterThan(0);
    });
  });

  describe('2. Real-Time Collaboration & Operational Transform (OT)', () => {
    let room: CollabRoom;

    beforeEach(() => {
      room = new CollabRoom('ds-1');
    });

    it('manages user presence and joins/leaves cleanly', () => {
      const user = room.join({
        id: 'user-1',
        name: 'Sarah Connor',
        email: 'sarah@skynet.com',
      });

      expect(user.status).toBe('online');
      expect(user.color).toBeDefined();

      const presence = room.getPresence();
      expect(presence.length).toBe(1);
      expect(presence[0].id).toBe('user-1');

      room.updateCursor('user-1', { view: 'tokens', elementId: 'color.brand.primary' });
      expect(room.getPresence()[0].cursor?.elementId).toBe('color.brand.primary');

      room.leave('user-1');
      expect(room.getPresence().length).toBe(0);
    });

    it('acquires and releases resource locks with owner checks', () => {
      // acquireLock(userId, resourceType, resourceId) — returns ResourceLock | null
      const lock = room.acquireLock('user-1', 'token', 'color.brand.primary');
      expect(lock).not.toBeNull();
      expect(lock!.lockedBy).toBe('user-1');

      // Second user cannot acquire the same locked resource
      const secondAttempt = room.acquireLock('user-2', 'token', 'color.brand.primary');
      expect(secondAttempt).toBeNull();

      // Non-owner cannot release the lock
      const unauthorizedRelease = room.releaseLock('user-2', 'token', 'color.brand.primary');
      expect(unauthorizedRelease).toBe(false);

      // Owner releases the lock
      const authorizedRelease = room.releaseLock('user-1', 'token', 'color.brand.primary');
      expect(authorizedRelease).toBe(true);

      // After release, another user can acquire
      const reacquired = room.acquireLock('user-2', 'token', 'color.brand.primary');
      expect(reacquired).not.toBeNull();
      expect(reacquired!.lockedBy).toBe('user-2');
    });

    it('transforms concurrent operations correctly', () => {
      const op1: EditOperation = {
        type: 'update',
        path: 'tokens/color.brand.primary/rawValue',
        value: '#ff0000',
        userId: 'user-1',
        timestamp: 1000,
      };

      const op2: EditOperation = {
        type: 'update',
        path: 'tokens/color.brand.primary/rawValue',
        value: '#00ff00',
        userId: 'user-2',
        timestamp: 1050,
      };

      // Later timestamp wins in last-writer-wins; earlier op gets transformed
      const transformed = transformOperation(op1, op2);
      expect(transformed.previousValue).toBe('#00ff00');
    });

    it('transforms operations on independent paths as no-ops', () => {
      const op1: EditOperation = {
        type: 'update',
        path: 'tokens/color.brand.primary/rawValue',
        value: '#ff0000',
        userId: 'user-1',
        timestamp: 1000,
      };

      const op2: EditOperation = {
        type: 'update',
        path: 'tokens/spacing.layout.lg/rawValue',
        value: '32px',
        userId: 'user-2',
        timestamp: 1050,
      };

      // Different paths → op1 returned unchanged
      const transformed = transformOperation(op1, op2);
      expect(transformed).toBe(op1);
    });
  });

  describe('3. Design Handoff Specification Generator', () => {
    const generator = new HandoffGenerator();

    it('generates multi-platform token references', () => {
      const specs = generator.generateTokenSpecs(sampleTokens);
      expect(specs.length).toBe(2);

      const colorSpec = specs[0];
      expect(colorSpec.path).toBe('color.brand.primary');
      expect(colorSpec.platforms.web).toBe('var(--nova-color-brand-primary)');
      // iOS uses NovaTokens.Colors.xxx
      expect(colorSpec.platforms.ios).toContain('NovaTokens');
      // Android uses NovaColors.Xxx
      expect(colorSpec.platforms.android).toContain('Nova');
      // Flutter uses AppTokens.xxx
      expect(colorSpec.platforms.flutter).toContain('AppTokens');
    });

    it('generates component spec sheets with code snippets', () => {
      const componentSpec = generator.generateComponentSpec(
        {
          name: 'Button',
          description: 'Standard interactive button component',
          props: [
            { name: 'variant', type: "'primary' | 'secondary'", required: true, description: 'Visual style' },
            { name: 'disabled', type: 'boolean', required: false, default: 'false', description: 'Disable state' },
          ],
          variants: [
            { name: 'Primary', props: { variant: 'primary' }, description: 'Primary action button' },
          ],
          tokens: ['color.brand.primary', 'spacing.layout.lg'],
        },
        sampleTokens
      );

      expect(componentSpec.name).toBe('Button');
      expect(componentSpec.status).toBe('ready');
      expect(componentSpec.category).toBe('actions');
      // generateCodeSnippets produces 3 (react, vue, html)
      expect(componentSpec.codeSnippets.length).toBe(3);
      const reactSnippet = componentSpec.codeSnippets.find((s) => s.platform === 'react');
      expect(reactSnippet).toBeDefined();
      expect(reactSnippet?.code).toContain('<Button');
      expect(componentSpec.measurements.length).toBeGreaterThan(0);
      expect(componentSpec.dosDonts.length).toBeGreaterThan(0);
    });

    it('provides platform implementation guides', () => {
      const guides = generator.generatePlatformGuides();
      expect(guides.length).toBe(4);
      const webGuide = guides.find((g) => g.platform === 'web');
      expect(webGuide?.installCommand).toBe('npm install @nexus-design/tokens');
      const iosGuide = guides.find((g) => g.platform === 'ios');
      expect(iosGuide).toBeDefined();
      const flutterGuide = guides.find((g) => g.platform === 'flutter');
      expect(flutterGuide).toBeDefined();
    });

    it('generates a complete handoff spec with accessibility notes', () => {
      const handoff = generator.generateFullHandoff(sampleTokens, [{
        name: 'Button',
        description: 'Primary CTA',
        props: [{ name: 'variant', type: 'string', required: true, description: 'Visual variant' }],
        variants: [],
        tokens: ['color.brand.primary'],
      }]);

      expect(handoff.id).toMatch(/^handoff-/);
      expect(handoff.tokens.length).toBe(2);
      expect(handoff.components.length).toBe(1);
      expect(handoff.platforms.length).toBe(4);
      expect(handoff.accessibility.length).toBeGreaterThan(0);
    });
  });

  describe('4. Notion-like Rich Document Editor Engine', () => {
    let docEngine: DocEngine;

    beforeEach(() => {
      docEngine = new DocEngine();
    });

    it('creates and manages documentation pages', () => {
      const page = docEngine.createPage({
        title: 'Component Guidelines',
        designSystemId: 'ds-1',
        createdBy: 'user-1',
      });

      expect(page.id).toBeDefined();
      expect(page.title).toBe('Component Guidelines');
      expect(page.slug).toBe('component-guidelines');
      // createPage auto-adds a heading1 block
      expect(page.blocks.length).toBe(1);

      const retrieved = docEngine.getPage(page.id);
      expect(retrieved?.id).toBe(page.id);

      const list = docEngine.listPages('ds-1');
      expect(list.length).toBe(1);
    });

    it('manipulates blocks via addBlock(pageId, type, content, properties)', () => {
      const page = docEngine.createPage({
        title: 'Typography Overview',
        designSystemId: 'ds-1',
        createdBy: 'user-1',
      });

      // addBlock(pageId, type, content, properties) — not a block object
      const block = docEngine.addBlock(page.id, 'callout', 'Use semantic headings everywhere', { variant: 'tip' });
      expect(block).toBeDefined();
      expect(block!.type).toBe('callout');
      expect(block!.content).toBe('Use semantic headings everywhere');

      const updatedPage = docEngine.getPage(page.id);
      expect(updatedPage?.blocks.length).toBe(2);
      expect(updatedPage?.blocks[1].type).toBe('callout');

      // Slash commands registry
      expect(SLASH_COMMANDS.length).toBeGreaterThanOrEqual(15);
      const swatchCommand = SLASH_COMMANDS.find((cmd) => cmd.id === 'token-swatch');
      expect(swatchCommand).toBeDefined();
      expect(swatchCommand?.blockType).toBe('token_swatch');
    });

    it('exports page to markdown via pageToMarkdown', () => {
      const page = docEngine.createPage({
        title: 'Quick Start',
        designSystemId: 'ds-1',
        createdBy: 'user-1',
      });

      docEngine.addBlock(page.id, 'paragraph', 'Welcome to Nexus Design OS.');
      docEngine.addBlock(page.id, 'code', 'npm run build', { language: 'bash' });

      const markdown = docEngine.pageToMarkdown(page.id);
      expect(markdown).toContain('# Quick Start');
      expect(markdown).toContain('Welcome to Nexus Design OS.');
      expect(markdown).toContain('```bash');
      expect(markdown).toContain('npm run build');
    });

    it('imports markdown into a structured doc page', () => {
      const markdown = `# Design Tokens Guide

Use design tokens for all visual properties.

\`\`\`css
:root { --color-primary: #3b82f6; }
\`\`\`

---
`;

      const page = docEngine.markdownToPage(markdown, 'ds-1', 'user-1');
      expect(page.title).toBe('Design Tokens Guide');
      expect(page.blocks.length).toBeGreaterThanOrEqual(4);

      const heading = page.blocks.find(b => b.type === 'heading1');
      expect(heading?.content).toBe('Design Tokens Guide');

      const codeBlock = page.blocks.find(b => b.type === 'code');
      expect(codeBlock?.content).toContain('--color-primary');
    });

    it('searches slash commands by keyword', () => {
      const results = docEngine.searchCommands('color');
      expect(results.length).toBeGreaterThan(0);
      expect(results.some(r => r.id === 'color-palette')).toBe(true);
    });
  });

  describe('5. Enterprise SSO & OAuth Providers', () => {
    it('provides configurations for major identity providers', () => {
      expect(PROVIDER_METADATA.google).toBeDefined();
      expect(PROVIDER_METADATA.github).toBeDefined();
      expect(PROVIDER_METADATA.gitlab).toBeDefined();
      expect(PROVIDER_METADATA.microsoft).toBeDefined();
    });

    it('generates secure OAuth authorization URLs with state and scopes', () => {
      const provider = new OAuthProvider({
        provider: 'google',
        clientId: 'client-id-test-123',
        clientSecret: 'secret-xyz',
        redirectUri: 'https://app.nexusdesign.io/api/sso/callback',
        scopes: ['openid', 'email', 'profile'],
      });

      const authUrl = provider.getAuthorizationUrl('random-state-nonce-456');
      expect(authUrl).toContain('https://accounts.google.com/o/oauth2/v2/auth');
      expect(authUrl).toContain('client_id=client-id-test-123');
      expect(authUrl).toContain('state=random-state-nonce-456');
      expect(authUrl).toContain('redirect_uri=');
    });

    it('generates GitHub OAuth URL with correct scopes', () => {
      const provider = new OAuthProvider({
        provider: 'github',
        clientId: 'gh-client-id',
        clientSecret: 'gh-secret',
        redirectUri: 'http://localhost:3000/api/sso/callback',
      });

      const authUrl = provider.getAuthorizationUrl('csrf-state-789');
      expect(authUrl).toContain('https://github.com/login/oauth/authorize');
      expect(authUrl).toContain('client_id=gh-client-id');
      expect(authUrl).toContain('read%3Auser');
    });
  });
});
