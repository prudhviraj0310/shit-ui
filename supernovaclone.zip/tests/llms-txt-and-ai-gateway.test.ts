import { describe, it, expect, beforeAll } from 'vitest';
import { GET as getLlmsTxt } from '@/app/llms.txt/route';
import { resolveAliases } from '@/core/tokens/resolver';
import { FlatToken } from '@/core/tokens/types';
import { getDb } from '@/db';
import { seedDatabase } from '@/db/seed';

describe('Supernova AI Agent Intelligence & /llms.txt Integration', () => {
  beforeAll(async () => {
    await getDb();
    await seedDatabase();
  });

  it('serves dynamic /llms.txt machine-readable index for LLMs and AI coding agents', async () => {
    const res = await getLlmsTxt();
    expect(res.status).toBe(200);
    expect(res.headers.get('content-type')).toContain('text/plain');

    const body = await res.text();
    expect(body).toContain('LLMs & AI Coding Agents Index');
    expect(body).toContain('mcpServers');
    expect(body).toContain('.cursor/mcp.json');
    expect(body).toContain('claude_desktop_config.json');
    expect(body).toContain('/api/tokens');
    expect(body).toContain('/api/components');
    expect(body).toContain('Exporters Available');
    expect(body).toContain('Living Documentation Portal');
  });

  it('enforces 500-level recursion ceiling and fallthrough semantics matching Supernova AST', () => {
    const circularA: FlatToken = {
      name: 'tok-a',
      path: 'color.loop.a',
      category: 'color',
      type: 'color',
      rawValue: '{color.loop.b}',
      resolvedValue: '',
      isAlias: true,
      aliasTarget: 'color.loop.b',
      isDeprecated: false,
    };
    const circularB: FlatToken = {
      name: 'tok-b',
      path: 'color.loop.b',
      category: 'color',
      type: 'color',
      rawValue: '{color.loop.a}',
      resolvedValue: '',
      isAlias: true,
      aliasTarget: 'color.loop.a',
      isDeprecated: false,
    };

    const res = resolveAliases([circularA, circularB]);
    expect(res.cycles.length).toBeGreaterThan(0);
    expect(res.tokens.some((t) => String(t.resolvedValue).includes('[Circular:'))).toBe(true);
  });

  it('resolves fallbackValue when target token is missing', () => {
    const tokenWithFallback: FlatToken = {
      name: 'btn-bg',
      path: 'color.btn.bg',
      category: 'color',
      type: 'color',
      rawValue: '{color.missing.target}',
      fallbackValue: '#3b82f6',
      resolvedValue: '',
      isAlias: true,
      aliasTarget: 'color.missing.target',
      isDeprecated: false,
    };

    const res = resolveAliases([tokenWithFallback]);
    const found = res.tokens.find((t) => t.path === 'color.btn.bg');
    expect(found?.resolvedValue).toBe('#3b82f6');
  });
});
