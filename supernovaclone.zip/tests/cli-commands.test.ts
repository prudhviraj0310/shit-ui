import { describe, it, expect, beforeAll } from 'vitest';
import { getDb } from '../src/db/index';
import { seedDatabase } from '../src/db/seed';
import { getPulsarEngine } from '../src/core/pulsar/engine';
import { validateTokens } from '../src/core/tokens/validator';
import { TokenBranchManager } from '../src/core/tokens/branching';
import { BUILTIN_EXPORTER_MANIFESTS, executeExporterWithManifest } from '../src/core/exporters/manifest';

describe('CLI & Enterprise Exporter Integration', () => {
  let db: any;

  beforeAll(async () => {
    const res = await getDb();
    db = res.db;
    await seedDatabase();
  });

  it('contains manifests for all 10 standard enterprise exporters', () => {
    const manifests = Object.keys(BUILTIN_EXPORTER_MANIFESTS);
    expect(manifests).toContain('css');
    expect(manifests).toContain('scss');
    expect(manifests).toContain('typescript');
    expect(manifests).toContain('tailwind');
    expect(manifests).toContain('swift');
    expect(manifests).toContain('kotlin');
    expect(manifests).toContain('flutter');
    expect(manifests).toContain('style-dictionary');
    expect(manifests).toContain('android-xml');
    expect(manifests).toContain('json');
  });

  it('runs Pulsar engine on all 6 built-in templates without error', () => {
    const engine = getPulsarEngine();
    const templates = engine.listTemplates();
    expect(templates.length).toBeGreaterThanOrEqual(6);

    const testTokens = [
      {
        name: 'primary',
        path: 'color.primary',
        category: 'color',
        type: 'color',
        rawValue: '#3B82F6',
        resolvedValue: '#3B82F6',
        isAlias: false,
        isDeprecated: false,
      },
      {
        name: 'sm',
        path: 'spacing.sm',
        category: 'spacing',
        type: 'dimension',
        rawValue: '8px',
        resolvedValue: '8px',
        isAlias: false,
        isDeprecated: false,
      },
    ];

    for (const t of templates) {
      const result = engine.execute(t.id, testTokens as any);
      expect(result.success).toBe(true);
      expect(result.output.length).toBeGreaterThan(0);
      expect(result.errors.length).toBe(0);
    }
  });

  it('validates tokens and catches syntax errors', () => {
    const invalidTokens = [
      {
        name: 'bad-color',
        path: 'color.bad',
        category: 'color',
        type: 'color',
        rawValue: 'not-a-color-val',
        resolvedValue: 'not-a-color-val',
        isAlias: false,
        isDeprecated: false,
      },
    ];

    const result = validateTokens(invalidTokens as any);
    expect(result.valid).toBe(false);
    expect(result.errors.length).toBeGreaterThan(0);
  });

  it('diffs branches and identifies token parity', async () => {
    const branchManager = new TokenBranchManager(db);
    const diff = await branchManager.diffBranches('ds-nova-design', 'Draft', 'Draft');
    expect(diff.totalChanges).toBe(0);
    expect(diff.unchangedCount).toBeGreaterThan(0);
  });
});
