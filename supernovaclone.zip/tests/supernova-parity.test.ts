import { describe, it, expect, beforeEach } from 'vitest';
import { getDb } from '../src/db/index';
import { VersionManager } from '../src/core/versions/version-manager';
import { ComponentStatusManager } from '../src/core/components/status';
import { TokenBranchManager } from '../src/core/tokens/branching';
import { UniversalSearchEngine } from '../src/core/search/engine';
import { CommentsManager } from '../src/core/comments/engine';
import { ComplianceManager } from '../src/core/audit/compliance';
import { OutboundWebhookDispatcher } from '../src/core/webhooks/dispatcher';
import { seedDatabase } from '../src/db/seed';

describe('Supernova Parity Enterprise Suite', () => {
  let db: any;

  beforeEach(async () => {
    const res = await getDb(':memory:');
    db = res.db;
    await seedDatabase(db);
  });

  describe('1. Version History & State Rollback', () => {
    it('creates a release snapshot and successfully rolls back draft tokens to it', async () => {
      const vm = new VersionManager(db);

      // Create release 2.0.0
      const rel = await vm.releaseVersion({
        designSystemId: 'ds-nova-design',
        version: '2.0.0',
        title: 'Release 2.0.0 Snapshot',
        description: 'Sealed test release',
      });
      expect(rel.version.name).toBe('2.0.0');
      expect(rel.tokensCopied).toBeGreaterThan(0);

      // Rollback to 2.0.0
      const rollback = await vm.rollbackToVersion('ds-nova-design', '2.0.0');
      expect(rollback.restoredFrom.name).toBe('2.0.0');
      expect(rollback.tokensRestored).toBe(rel.tokensCopied);
    });

    it('throws error when target version does not exist', async () => {
      const vm = new VersionManager(db);
      await expect(vm.rollbackToVersion('ds-nova-design', 'non-existent-9.9.9')).rejects.toThrow();
    });
  });

  describe('2. Component Lifecycle Status Board', () => {
    it('retrieves board data grouped into lifecycle columns with metrics', async () => {
      const manager = new ComponentStatusManager(db);
      const data = await manager.getBoardData('ds-nova-design');

      expect(data.totalCount).toBeGreaterThan(0);
      expect(data.columns).toHaveProperty('backlog');
      expect(data.columns).toHaveProperty('in_progress');
      expect(data.columns).toHaveProperty('ready');
      expect(data.columns).toHaveProperty('deprecated');
      expect(data.metrics.healthScore).toBeGreaterThanOrEqual(0);
    });

    it('updates component status and creates new components', async () => {
      const manager = new ComponentStatusManager(db);
      const newComp = await manager.createComponent({
        designSystemId: 'ds-nova-design',
        name: 'Tooltip',
        category: 'feedback',
        framework: 'react',
        status: 'in_progress',
        description: 'Contextual hover tooltip',
      });

      expect(newComp.name).toBe('Tooltip');
      expect(newComp.status).toBe('in_progress');

      const updateRes = await manager.updateStatus(newComp.id, 'ready');
      expect(updateRes.status).toBe('ready');

      const board = await manager.getBoardData('ds-nova-design');
      const found = board.columns.ready.find(c => c.id === newComp.id);
      expect(found).toBeDefined();
    });
  });

  describe('3. Token Branching & Merging', () => {
    it('creates an isolated token branch forked from Draft', async () => {
      const bm = new TokenBranchManager(db);
      const result = await bm.createBranch('ds-nova-design', 'feature/typography-scale', 'Testing new scale');

      expect(result.branch.name).toBe('feature/typography-scale');
      expect(result.tokensCopied).toBeGreaterThan(0);

      const branches = await bm.listBranches('ds-nova-design');
      expect(branches.some(b => b.name === 'feature/typography-scale')).toBe(true);
    });

    it('calculates diffs between two branches accurately', async () => {
      const bm = new TokenBranchManager(db);
      await bm.createBranch('ds-nova-design', 'feature/test-diff');

      const diff = await bm.diffBranches('ds-nova-design', 'feature/test-diff', 'Draft');
      expect(diff.totalChanges).toBe(0);
      expect(diff.unchangedCount).toBeGreaterThan(0);
    });

    it('merges branch into target branch atomically', async () => {
      const bm = new TokenBranchManager(db);
      await bm.createBranch('ds-nova-design', 'feature/merge-test');

      const mergeRes = await bm.mergeBranch('ds-nova-design', 'feature/merge-test', 'Draft');
      expect(mergeRes.success).toBe(true);
      expect(mergeRes.targetBranch).toBe('Draft');
    });
  });

  describe('4. Universal Search Engine', () => {
    it('indexes and searches across tokens, components, and doc pages', async () => {
      const searchEngine = new UniversalSearchEngine(db);

      const tokenResults = await searchEngine.search('primary');
      expect(tokenResults.length).toBeGreaterThan(0);
      expect(tokenResults.some(r => r.category === 'token')).toBe(true);

      const compResults = await searchEngine.search('Button');
      expect(compResults.length).toBeGreaterThan(0);
      expect(compResults.some(r => r.category === 'component')).toBe(true);

      const defaultResults = await searchEngine.search('');
      expect(defaultResults.length).toBeGreaterThan(0);
    });
  });

  describe('5. Contextual Comments & Discussions', () => {
    it('creates comment threads, replies, and toggles resolved status', async () => {
      const cm = new CommentsManager(db);

      const thread = await cm.addComment({
        targetType: 'token',
        targetId: 'color.brand.primary',
        targetTitle: 'color.brand.primary',
        author: 'Marcus (Design)',
        body: 'Check AAA contrast rating',
      });

      expect(thread.id).toBeDefined();
      expect(thread.status).toBe('open');

      const reply = await cm.addReply(thread.id, 'Priya (Engineering)', 'Confirmed AA compliant');
      expect(reply.body).toBe('Confirmed AA compliant');

      const resolved = await cm.toggleResolve(thread.id, 'resolved');
      expect(resolved.status).toBe('resolved');

      const list = await cm.listComments();
      const found = list.find(t => t.id === thread.id);
      expect(found?.status).toBe('resolved');
      expect(found?.replies.length).toBe(1);
    });
  });

  describe('6. Compliance & Audit Dashboard', () => {
    it('generates a comprehensive compliance report with score and checklist', async () => {
      const compManager = new ComplianceManager(db);
      const report = await compManager.getReport();

      expect(report.overallScore).toBeGreaterThan(80);
      expect(report.checklist.length).toBeGreaterThanOrEqual(4);
    });

    it('exports audit logs to valid CSV and JSON formats', async () => {
      const compManager = new ComplianceManager(db);

      const jsonExport = await compManager.exportLogs('json');
      expect(jsonExport.contentType).toBe('application/json');
      expect(JSON.parse(jsonExport.data)).toBeInstanceOf(Array);

      const csvExport = await compManager.exportLogs('csv');
      expect(csvExport.contentType).toBe('text/csv');
      expect(csvExport.data).toContain('id,action,resource_type');
    });
  });

  describe('7. Outbound Webhook Subscriptions & Dispatcher', () => {
    it('registers subscriptions, signs payload with HMAC sha256, and dispatches', async () => {
      const sub = OutboundWebhookDispatcher.addSubscription({
        url: 'https://webhook.site/test-hook',
        events: ['release.published', 'tokens.updated'],
        description: 'Test Webhook',
      });

      expect(sub.id).toBeDefined();
      expect(sub.secret).toBeDefined();

      const dispatched = await OutboundWebhookDispatcher.dispatch('release.published', {
        version: '2.0.0',
        author: 'Admin',
      });

      expect(dispatched.length).toBeGreaterThan(0);
      expect(dispatched[0].signature).toMatch(/^sha256=[a-f0-9]{64}$/);

      const deleted = OutboundWebhookDispatcher.deleteSubscription(sub.id);
      expect(deleted).toBe(true);
    });
  });
});
