# Site Clone

Static offline clone of [https://supernova.io/for-ai](https://supernova.io/for-ai), captured with a headless-browser scraper (fully-rendered DOM + assets).

## View it

Open `index.html` directly in a browser, or serve it locally:

```bash
npx serve .
```

## Notes

- This is a static snapshot for personal/reference use. Interactive features that depend on the original site's live backend (cart, search, filters) will not function.
- Cloned on 2026-10-13.
