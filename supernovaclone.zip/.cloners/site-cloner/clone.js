/**
 * Site Cloner — captures a fully-rendered page (post-JS) plus every
 * CSS, JS, image, and font asset it references, and rewrites all
 * paths so the result works fully offline.
 *
 * Usage:
 *   node clone.js https://www.marinelayer.com/ ./output
 */

const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');
const { URL } = require('url');
const archiver = require('archiver');

const TARGET_URL = process.argv[2] || 'https://www.marinelayer.com/';
const OUT_DIR = path.resolve(process.argv[3] || './output');

const ASSET_DIRS = {
  css: 'assets/css',
  js: 'assets/js',
  img: 'assets/images',
  font: 'assets/fonts',
  other: 'assets/other',
};

// url -> local relative path (dedupe so the same asset isn't downloaded twice)
const downloaded = new Map();

function ensureDir(dir) {
  fs.mkdirSync(dir, { recursive: true });
}

function extForUrl(u) {
  const clean = u.split('?')[0].split('#')[0];
  const ext = path.extname(clean);
  return ext || '';
}

function categorize(u) {
  const ext = extForUrl(u).toLowerCase();
  if (ext === '.css') return 'css';
  if (ext === '.js' || ext === '.mjs') return 'js';
  if (['.woff', '.woff2', '.ttf', '.otf', '.eot'].includes(ext)) return 'font';
  if (['.png', '.jpg', '.jpeg', '.gif', '.svg', '.webp', '.avif', '.ico', '.bmp'].includes(ext)) return 'img';
  return 'other';
}

function safeName(u) {
  const clean = u.split('?')[0].split('#')[0];
  let base = path.basename(clean) || 'file';
  base = base.replace(/[^a-zA-Z0-9._-]/g, '_');
  return base;
}

// Resolves a possibly-relative URL against a base, returns null if not http(s)
function resolveUrl(raw, base) {
  if (!raw) return null;
  raw = raw.trim();
  if (raw.startsWith('data:') || raw.startsWith('blob:') || raw.startsWith('#')) return null;
  try {
    const resolved = new URL(raw, base);
    if (resolved.protocol !== 'http:' && resolved.protocol !== 'https:') return null;
    return resolved.href;
  } catch {
    return null;
  }
}

async function downloadAsset(requestCtx, assetUrl) {
  if (downloaded.has(assetUrl)) return downloaded.get(assetUrl);

  const kind = categorize(assetUrl);
  const dir = path.join(OUT_DIR, ASSET_DIRS[kind]);
  ensureDir(dir);

  // Make a unique local filename (avoid collisions between different-path same-basename files)
  let filename = safeName(assetUrl);
  let localPath = path.join(dir, filename);
  let counter = 1;
  const parsedName = path.parse(filename);
  while (fs.existsSync(localPath) && !downloaded.has(assetUrl)) {
    filename = `${parsedName.name}_${counter}${parsedName.ext}`;
    localPath = path.join(dir, filename);
    counter++;
  }

  const relPath = path.relative(OUT_DIR, localPath).split(path.sep).join('/');

  try {
    const res = await requestCtx.get(assetUrl, { timeout: 20000 });
    if (!res.ok()) {
      console.warn(`  [skip] ${res.status()} ${assetUrl}`);
      downloaded.set(assetUrl, null);
      return null;
    }
    const buf = await res.body();
    fs.writeFileSync(localPath, buf);
    downloaded.set(assetUrl, relPath);
    console.log(`  [ok]   ${assetUrl} -> ${relPath}`);

    // If it's CSS, recurse into url() / @import references inside it
    if (kind === 'css') {
      const cssText = buf.toString('utf-8');
      const rewritten = await processCss(requestCtx, cssText, assetUrl, dir);
      fs.writeFileSync(localPath, rewritten, 'utf-8');
    }

    return relPath;
  } catch (err) {
    console.warn(`  [fail] ${assetUrl}: ${err.message}`);
    downloaded.set(assetUrl, null);
    return null;
  }
}

// Finds url(...) and @import refs inside CSS text, downloads them, rewrites to local relative paths
async function processCss(requestCtx, cssText, cssUrl, cssLocalDir) {
  const urlRegex = /url\(\s*(['"]?)([^'")]+)\1\s*\)/g;
  const importRegex = /@import\s+(?:url\()?['"]?([^'")]+)['"]?\)?/g;

  const refs = new Set();
  let m;
  while ((m = urlRegex.exec(cssText))) refs.add(m[2]);
  while ((m = importRegex.exec(cssText))) refs.add(m[1]);

  let out = cssText;
  for (const ref of refs) {
    const resolved = resolveUrl(ref, cssUrl);
    if (!resolved) continue;
    const localRel = await downloadAsset(requestCtx, resolved);
    if (localRel) {
      // path relative to the CSS file's own directory, since CSS url()s are relative to the CSS file
      const relFromCss = path.relative(cssLocalDir, path.join(OUT_DIR, localRel)).split(path.sep).join('/');
      out = out.split(ref).join(relFromCss);
    }
  }
  return out;
}

async function main() {
  ensureDir(OUT_DIR);
  for (const d of Object.values(ASSET_DIRS)) ensureDir(path.join(OUT_DIR, d));

  console.log(`Launching browser...`);
  const browser = await chromium.launch();
  const context = await browser.newContext({
    viewport: { width: 1440, height: 900 },
    userAgent:
      'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36',
  });
  const page = await context.newPage();
  const requestCtx = context.request;

  console.log(`Navigating to ${TARGET_URL} ...`);
  await gotoWithRetry(page, TARGET_URL);

  // Many sites (live chat widgets, analytics, ad pixels) never go fully
  // network-idle because they keep polling in the background. Treat
  // networkidle as a nice-to-have with a short timeout, not a hard
  // requirement — domcontentloaded + the scroll pass below is enough
  // to get real content rendered.
  try {
    await page.waitForLoadState('networkidle', { timeout: 15000 });
  } catch {
    console.warn('Page did not reach full network-idle in 15s (likely background analytics/chat) — continuing anyway.');
  }

  // Trigger lazy-loaded content by scrolling through the whole page
  console.log('Scrolling to trigger lazy-loaded content...');
  await autoScroll(page);
  await page.waitForTimeout(1500);

  // Collect asset URLs straight from the rendered DOM. We grab the *raw*
  // attribute text (getAttribute), not the browser-resolved .href/.src
  // property — the DOM resolves protocol-relative ("//host/...") and
  // relative ("/path") URLs to absolute ones, and we need the literal text
  // to find the right element/attribute to rewrite.
  const assetRefs = await page.evaluate(() => {
    const refs = new Set();
    const addAttr = (el, attr) => {
      const raw = el.getAttribute(attr);
      if (raw && raw.trim()) refs.add(raw.trim());
    };

    document.querySelectorAll('link[rel="stylesheet"][href]').forEach((el) => addAttr(el, 'href'));
    document.querySelectorAll('script[src]').forEach((el) => addAttr(el, 'src'));
    document.querySelectorAll('img[src]').forEach((el) => addAttr(el, 'src'));
    document.querySelectorAll('source[src]').forEach((el) => addAttr(el, 'src'));
    document.querySelectorAll('link[rel*="icon"][href]').forEach((el) => addAttr(el, 'href'));

    // srcset attributes (img and source) can contain multiple URLs
    document.querySelectorAll('img[srcset], source[srcset]').forEach((el) => {
      el.getAttribute('srcset')
        .split(',')
        .forEach((part) => {
          const u = part.trim().split(/\s+/)[0];
          if (u) refs.add(u);
        });
    });

    // inline style="background-image:url(...)"
    document.querySelectorAll('[style*="url("]').forEach((el) => {
      const matches = el.getAttribute('style').match(/url\(([^)]+)\)/g) || [];
      matches.forEach((m) => {
        const raw = m.slice(4, -1).replace(/["']/g, '').trim();
        if (raw) refs.add(raw);
      });
    });

    return Array.from(refs);
  });

  console.log(`Found ${assetRefs.length} top-level assets. Downloading...`);
  const refToLocal = {};
  for (const rawRef of assetRefs) {
    const resolved = resolveUrl(rawRef, TARGET_URL);
    if (!resolved) continue;
    const localRel = await downloadAsset(requestCtx, resolved);
    if (localRel) refToLocal[rawRef] = localRel;
  }

  // Rewrite references by mutating the actual DOM attributes (not a text
  // search-and-replace on the serialized HTML string). Doing this via
  // string replacement is unreliable: getAttribute() returns decoded text
  // (e.g. a literal "&"), but page.content() re-serializes attributes with
  // HTML entities ("&amp;") — so any ref containing "&" (extremely common
  // in URLs with multiple query params) would silently fail to match and
  // leave a corrupted, half-rewritten URL behind. Setting attributes
  // directly and letting the browser serialize sidesteps that entirely.
  console.log('Rewriting DOM references to local paths...');
  await page.evaluate((refToLocal) => {
    const rewriteAttr = (el, attr) => {
      const raw = el.getAttribute(attr);
      if (raw && refToLocal[raw.trim()]) {
        el.setAttribute(attr, refToLocal[raw.trim()]);
        // crossorigin forces a CORS-mode fetch, which browsers refuse
        // entirely under the file:// origin ("null") — pointless once the
        // asset is local anyway, and it's the difference between the CSS
        // loading or not when someone double-clicks index.html.
        el.removeAttribute('crossorigin');
      }
    };

    document.querySelectorAll('link[rel="stylesheet"][href]').forEach((el) => rewriteAttr(el, 'href'));
    document.querySelectorAll('script[src]').forEach((el) => rewriteAttr(el, 'src'));
    document.querySelectorAll('img[src]').forEach((el) => rewriteAttr(el, 'src'));
    document.querySelectorAll('source[src]').forEach((el) => rewriteAttr(el, 'src'));
    document.querySelectorAll('link[rel*="icon"][href]').forEach((el) => rewriteAttr(el, 'href'));

    document.querySelectorAll('img[srcset], source[srcset]').forEach((el) => {
      const rewritten = el
        .getAttribute('srcset')
        .split(',')
        .map((part) => {
          const trimmed = part.trim();
          const spaceIdx = trimmed.indexOf(' ');
          const u = spaceIdx === -1 ? trimmed : trimmed.slice(0, spaceIdx);
          const descriptor = spaceIdx === -1 ? '' : trimmed.slice(spaceIdx);
          return (refToLocal[u] || u) + descriptor;
        })
        .join(', ');
      el.setAttribute('srcset', rewritten);
    });

    document.querySelectorAll('[style*="url("]').forEach((el) => {
      const style = el.getAttribute('style');
      const rewritten = style.replace(/url\(([^)]+)\)/g, (match, inner) => {
        const raw = inner.replace(/["']/g, '').trim();
        return refToLocal[raw] ? `url(${refToLocal[raw]})` : match;
      });
      el.setAttribute('style', rewritten);
    });
  }, refToLocal);

  console.log('Capturing rendered HTML...');
  const html = await page.content();
  fs.writeFileSync(path.join(OUT_DIR, 'index.html'), html, 'utf-8');
  const usesModuleScripts = /<script[^>]*type=["']module["']/i.test(html);

  await browser.close();

  // Drop in repo-friendly extras so the output folder is ready to become
  // a GitHub repo as-is (git init && git add . && git commit).
  writeRepoExtras(OUT_DIR, TARGET_URL, usesModuleScripts);

  console.log(`\nZipping output...`);
  const zipPath = `${OUT_DIR}.zip`;
  await zipDirectory(OUT_DIR, zipPath);

  console.log(`\nDone.`);
  console.log(`Folder: ${OUT_DIR}`);
  console.log(`Zip:    ${zipPath}`);
  console.log(`Serve it locally (required if the site uses <script type="module">, which browsers refuse to run over file://):`);
  console.log(`  npx serve ${OUT_DIR}`);
}

function writeRepoExtras(outDir, sourceUrl, usesModuleScripts) {
  const gitignore = `node_modules/\n.DS_Store\n`;
  fs.writeFileSync(path.join(outDir, '.gitignore'), gitignore, 'utf-8');

  const viewSection = usesModuleScripts
    ? `## View it\n\nThis site ships JavaScript as ES modules (\`<script type="module">\`). Browsers refuse to run module scripts loaded from a \`file://\` URL (a CORS restriction, not a bug in this clone) — double-clicking \`index.html\` will show an unstyled or blank page. You must serve it over HTTP:\n\n\`\`\`bash\nnpx serve .\n\`\`\`\n\nthen open the printed \`http://localhost:...\` URL.`
    : `## View it\n\nOpen \`index.html\` directly in a browser, or serve it locally:\n\n\`\`\`bash\nnpx serve .\n\`\`\``;

  const readme = `# Site Clone\n\nStatic offline clone of [${sourceUrl}](${sourceUrl}), captured with a headless-browser scraper (fully-rendered DOM + assets).\n\n${viewSection}\n\n## Notes\n\n- This is a static snapshot for personal/reference use. Interactive features that depend on the original site's live backend (cart, search, filters) will not function.\n- Cloned on ${new Date().toISOString().slice(0, 10)}.\n`;
  fs.writeFileSync(path.join(outDir, 'CLONE_README.md'), readme, 'utf-8');
}

function zipDirectory(sourceDir, outPath) {
  return new Promise((resolve, reject) => {
    const output = fs.createWriteStream(outPath);
    const archive = archiver('zip', { zlib: { level: 9 } });

    output.on('close', () => resolve());
    archive.on('error', (err) => reject(err));

    archive.pipe(output);
    archive.directory(sourceDir, false);
    archive.finalize();
  });
}

// Retries navigation on timeout — some sites are just slow/flaky on the
// first request (cold CDN edge, DNS, etc.), so a single 60s attempt can
// fail transiently even though a retry succeeds immediately after.
async function gotoWithRetry(page, url, attempts = 3) {
  let lastErr;
  for (let i = 1; i <= attempts; i++) {
    try {
      await page.goto(url, { waitUntil: 'domcontentloaded', timeout: 60000 });
      return;
    } catch (err) {
      lastErr = err;
      console.warn(`  navigation attempt ${i}/${attempts} failed: ${err.message}`);
    }
  }
  throw lastErr;
}

async function autoScroll(page) {
  await page.evaluate(async () => {
    await new Promise((resolve) => {
      let totalHeight = 0;
      const distance = 400;
      const timer = setInterval(() => {
        window.scrollBy(0, distance);
        totalHeight += distance;
        if (totalHeight >= document.body.scrollHeight - window.innerHeight - 200) {
          clearInterval(timer);
          window.scrollTo(0, 0);
          resolve();
        }
      }, 200);
    });
  });
}

main().catch((err) => {
  console.error('Fatal error:', err);
  process.exit(1);
});
