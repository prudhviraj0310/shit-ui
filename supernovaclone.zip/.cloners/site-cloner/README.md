# Site Cloner

Captures a **fully-rendered** page (after JavaScript runs) plus every CSS, JS,
image, and font it references, downloads them all locally, and rewrites every
path so the result opens and looks correct **offline**.

## Setup (run locally — your machine, not a sandbox)

```bash
mkdir site-cloner && cd site-cloner
# copy clone.js and package.json into this folder
npm install
npx playwright install chromium   # downloads the browser binary Playwright needs
```

## Run it

```bash
node clone.js https://www.marinelayer.com/ ./marinelayer-clone
```

- Arg 1: the URL to clone
- Arg 2: output folder (defaults to `./output`)

Output structure:

```
marinelayer-clone/
  index.html
  .gitignore
  CLONE_README.md
  assets/
    css/
    js/
    images/
    fonts/
    other/

marinelayer-clone.zip   <-- zipped copy of the folder above, created automatically
```

Open `marinelayer-clone/index.html` directly in a browser — no server needed.
The script also zips the whole output folder for you automatically
(`marinelayer-clone.zip`, right next to the folder) so you can download/share
it as one file.

## Turning it into a GitHub repo

The output folder already includes a `.gitignore` and a starter
`CLONE_README.md`, so it's ready to push as-is:

```bash
cd marinelayer-clone
git init
git add .
git commit -m "Initial clone"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO.git
git push -u origin main
```

If you'd rather start from the zip (e.g. on a different machine or to hand
off to someone else):

```bash
unzip marinelayer-clone.zip -d marinelayer-clone
cd marinelayer-clone
git init && git add . && git commit -m "Initial clone"
```

One thing worth deciding up front: if this repo will be **public**, keep in
mind you're publishing another company's copyrighted design/content/images
under your GitHub account. That's fine for a private repo, a portfolio case
study with attribution, or local reference — but avoid presenting a live
public clone as your own original work.

## What it does

1. Launches headless Chromium, navigates to the URL, and waits for network
   activity to settle (`networkidle`) — this ensures JS-rendered content
   (product grids, lazy images, etc.) has actually loaded.
2. Auto-scrolls the full page so lazy-loaded images fire before capture.
3. Grabs the **rendered DOM** (`page.content()`), not the raw server HTML —
   this matters a lot for JS-heavy sites like Shopify storefronts.
4. Scans the DOM for every asset reference: `<link>`, `<script src>`,
   `<img src>`, `srcset`, inline `style="background:url(...)"`.
5. Downloads each asset, and for CSS files specifically, recurses into their
   own `url(...)` and `@import` references (fonts, background images) so
   nothing nested gets missed.
6. Rewrites all URLs in the saved HTML/CSS to local relative paths.

## Known limitations (why this still won't be 100% pixel-perfect out of the box)

- **Multi-page sites**: this clones a single URL. To crawl multiple pages
  (product pages, category pages), wrap the `main()` logic in a loop over a
  list of URLs, or extract internal `<a href>` links from the DOM and queue
  them — happy to add that if you want the whole site, not just one page.
- **Interactive JS behavior** (cart drawer, search modal, filters) will not
  work locally unless the site's own JS bundles happen to work without your
  logged-in session/API calls — expect some broken interactivity even though
  the static visuals will match.
- **Fonts loaded via Google Fonts / Adobe Fonts `<link>` tags**: these get
  downloaded like any other CSS/font, but some font services block requests
  without a browser-like `Referer` header. If fonts look off, check
  `assets/fonts` — you may need to add a `Referer` header to the download
  request for that specific asset.
- **Cloudflare / bot-protection**: if the site blocks headless browsers, add
  `--headed` mode (remove `headless: true`... actually this script already
  runs headed-capable — just change `chromium.launch()` to
  `chromium.launch({ headless: false })` to visually debug what's loading).
- Respect `robots.txt` and don't hammer the server — this script does one
  page at a time with no concurrency, which is deliberately polite.

## Next steps for true pixel-perfect verification

Once you have the local clone, use a diff tool to compare it against the
live site:
- Install the **PerfectPixel** Chrome extension (free) — overlay a screenshot
  of the live site on top of your local clone at low opacity and check
  alignment down to the pixel.
- Or use Playwright's own screenshot comparison:
  `npx playwright screenshot https://www.marinelayer.com/ live.png` and
  `npx playwright screenshot file:///path/to/index.html local.png`, then
  diff them with a tool like `pixelmatch` (free, npm).
