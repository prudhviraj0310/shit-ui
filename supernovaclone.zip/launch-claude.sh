#!/usr/bin/env bash

#
# Nexus / Claude CodeCraft Launcher
# Starts the local model-mapping proxy, routes requests to claude-opus-5.5,
# and cleans up automatically on exit.
#

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROXY_PATH="$SCRIPT_DIR/scripts/claude-proxy.js"

# Check if node is installed
if ! command -v node >/dev/null 2>&1; then
  echo "Error: Node.js is required to run the CodeCraft proxy."
  exit 1
fi

# Check if claude is installed
if ! command -v claude >/dev/null 2>&1; then
  echo "Error: 'claude' CLI is not found in PATH."
  exit 1
fi

echo "🚀 Starting CodeCraft Claude Proxy..."

# Start proxy in background
node "$PROXY_PATH" &
PROXY_PID=$!

cleanup() {
  if kill -0 "$PROXY_PID" 2>/dev/null; then
    kill "$PROXY_PID" 2>/dev/null || true
  fi
}
trap cleanup EXIT INT TERM

# Wait briefly for proxy to listen on 8088
sleep 0.5

# Configure environment for Claude Code
export ANTHROPIC_MODEL="${ANTHROPIC_MODEL:-claude-opus-4.8}"
unset ANTHROPIC_AUTH_TOKEN
export ANTHROPIC_BASE_URL="http://127.0.0.1:8088"
export ANTHROPIC_API_KEY="cc_Zu0fQjwSHtigc1y7XSa8tGclSNfPUtbIoB05Vx4iBYAPNHZp"

echo "✨ Launching Claude Code connected to ${ANTHROPIC_MODEL}..."
echo "────────────────────────────────────────────────────────"

claude "$@"
