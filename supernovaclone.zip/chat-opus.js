#!/usr/bin/env node

/**
 * Direct CLI Chat with claude-opus-5.5 via CodeCraft API.
 * Supports:
 *   1. Single prompt: ./chat-opus.js "Your question here"
 *   2. Interactive mode: ./chat-opus.js
 */

import https from 'node:https';
import readline from 'node:readline';

const API_KEY = process.env.CODECRAFT_KEY || process.env.ANTHROPIC_AUTH_TOKEN || process.env.ANTHROPIC_API_KEY || 'cc_Zu0fQjwSHtigc1y7XSa8tGclSNfPUtbIoB05Vx4iBYAPNHZp';
const MODEL = process.env.ANTHROPIC_MODEL || 'claude-opus-4.8';

async function streamCompletion(messages) {
  return new Promise((resolve, reject) => {
    const payload = JSON.stringify({
      model: MODEL,
      messages,
      stream: true,
      max_tokens: 4096,
    });

    const req = https.request({
      hostname: 'codecraftapi.com',
      port: 443,
      path: '/v1/chat/completions',
      method: 'POST',
      headers: {
        'content-type': 'application/json',
        'authorization': `Bearer ${API_KEY}`,
        'content-length': Buffer.byteLength(payload),
      },
    }, (res) => {
      let fullText = '';
      let buffer = '';

      res.on('data', (chunk) => {
        buffer += chunk.toString('utf8');
        const lines = buffer.split('\n');
        buffer = lines.pop(); // keep last incomplete line

        for (const line of lines) {
          const trimmed = line.trim();
          if (!trimmed || !trimmed.startsWith('data:')) continue;
          const jsonStr = trimmed.replace(/^data:\s*/, '');
          if (jsonStr === '[DONE]') continue;

          try {
            const data = JSON.parse(jsonStr);
            const delta = data.choices?.[0]?.delta?.content || '';
            if (delta) {
              process.stdout.write(delta);
              fullText += delta;
            }
          } catch (e) {
            // Ignore parse errors on malformed chunks
          }
        }
      });

      res.on('end', () => {
        process.stdout.write('\n');
        resolve(fullText);
      });
    });

    req.on('error', (err) => {
      console.error('\n[Error]:', err.message);
      reject(err);
    });

    req.write(payload);
    req.end();
  });
}

async function main() {
  const inlinePrompt = process.argv.slice(2).join(' ').trim();

  // Support piped stdin (e.g. git diff | ./chat-opus.js "review this")
  if (!process.stdin.isTTY) {
    let piped = '';
    for await (const chunk of process.stdin) {
      piped += chunk;
    }
    const combined = inlinePrompt ? `${inlinePrompt}\n\n${piped}` : piped;
    if (combined.trim()) {
      console.log(`\n\x1b[36m[${MODEL}]:\x1b[0m`);
      await streamCompletion([{ role: 'user', content: combined.trim() }]);
      process.exit(0);
    }
  }

  if (inlinePrompt) {
    // Single prompt mode
    console.log(`\n\x1b[36m[${MODEL}]:\x1b[0m`);
    await streamCompletion([{ role: 'user', content: inlinePrompt }]);
    process.exit(0);
  }

  // Interactive REPL mode
  console.log(`\x1b[32m✔ Connected to CodeCraft (${MODEL})\x1b[0m`);
  console.log(`Type your prompt and press Enter. Type 'exit' to quit.\n`);

  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout,
  });

  const history = [];

  const promptUser = () => {
    rl.question('\x1b[1m\x1b[35mYou > \x1b[0m', async (input) => {
      const trimmed = input.trim();
      if (!trimmed) {
        promptUser();
        return;
      }
      if (['exit', 'quit', ':q'].includes(trimmed.toLowerCase())) {
        rl.close();
        process.exit(0);
      }

      history.push({ role: 'user', content: trimmed });
      console.log(`\n\x1b[36m[${MODEL}]:\x1b[0m`);

      try {
        const reply = await streamCompletion(history);
        history.push({ role: 'assistant', content: reply });
      } catch (err) {
        console.error('Failed to get response:', err.message);
      }

      console.log('');
      promptUser();
    });
  };

  promptUser();
}

main();
